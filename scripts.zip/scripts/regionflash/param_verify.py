"""check the RegionFlash parameters that diff_ref.py / plugin_cmp.py do not
cover. A: against cachesim (region-evict=beta, reinsert p and n=0, warmup,
seed). B: spellings that must give identical results (taus, region-evict
without lcs:, out/prefix, sizes, -a size vs admit=sizemax). C: seed and
interval=0 behave as documented.
usage: python3 param_verify.py [cachesim_bin regionflash_bin trace(oracleGeneral)]"""
import glob, json, os, subprocess, sys

CS, RF, TR = (sys.argv[1:4] if len(sys.argv) > 3 else
              ("/root/cs/cachesim", "/root/b/bin/cachesim", "/root/cmp/t.og"))
SSD, R, DRAM, OUT = 64 << 20, 1 << 20, 8 << 20, "/root/pverify"
TOT = """reqs req_bytes dram_hits ssd_hits misses hit_bytes miss_bytes ssd_lookups ssd_admit_objs ssd_admit_bytes
dram_evict_objs clean_skip_objs admit_reject_objs ssd_copy_lost_rewrites ssd_evict_objs ssd_evict_bytes
dead_evict_objs dead_evict_bytes regions_sealed regions_evicted repartition_seals pad_bytes
flash_region_write_bytes reinsert_objs reinsert_bytes""".split()
bad = []


def rf(name, e, extra=()):
    p = f"{OUT}/{name}"
    r = subprocess.run([RF, TR, "oracleGeneral", "RegionFlash", str(SSD), *extra, "-e",
                        f"dram-size={DRAM},region-size={R},seal-on-repartition=inactive,{e},out={p}"], capture_output=True, text=True)
    if r.returncode:
        sys.exit(f"{name}: rc {r.returncode}\n{r.stderr[-1500:]}")
    return p


def check(name, ok, detail=""):
    print(f"{name:52s} {'OK' if ok else 'DIFF'} {detail}")
    if not ok:
        bad.append(name)


def vs_cachesim(name, cs_args, e):
    d = f"{OUT}/cs_{name}"
    os.makedirs(d, exist_ok=True)
    subprocess.run([CS, "--trace", TR, "--trace-format", "oracleGeneral", "--ssd-size", str(SSD), "--region-size", str(R),
                    "--dram-size", str(DRAM), "--out", d, *cs_args], check=True, stdout=subprocess.DEVNULL)
    c = json.load(open(f"{d}/summary.json"))["result"]
    t = json.load(open(rf(name, e) + ".json"))["total"]
    diff = [f"{k}: cs {c.get(k, 0)} rf {t[k]}" for k in TOT if c.get(k, 0) != t[k]]
    check(f"A {name}", not diff, f"OHR {t['ohr']:.6f} evicted {t['regions_evicted']} reinsert {t['reinsert_objs']} " + "; ".join(diff[:3]))


def same(name, a, b):
    ja, jb = (json.load(open(x + ".json")) for x in (a, b))
    ok = ja["total"] == jb["total"] and ja["class"] == jb["class"]
    check(f"B {name}", ok, f"OHR {ja['total']['ohr']:.6f}")


os.makedirs(OUT, exist_ok=True)
H = ["--hint", "fixed:16K,64K"]
# A. against cachesim
for b in ("0", "1", "-1", "2.5"):
    vs_cachesim(f"beta_{b}", H + ["--region-evict", f"beta:beta={b}"], f"hint=fixed:16K/64K,region-evict=beta,beta={b}")
vs_cachesim("reinsert_p0.5", H + ["--reinsert", "hits:n=1,p=0.5"], "hint=fixed:16K/64K,reinsert=hits:n=1/p=0.5")
vs_cachesim("reinsert_n0_p0.3", H + ["--reinsert", "hits:n=0,p=0.3"], "hint=fixed:16K/64K,reinsert=hits:n=0/p=0.3")
vs_cachesim("reinsert_ii_p0.7", H + ["--reinsert", "hits:n=2,p=0.7,mode=ii"], "hint=fixed:16K/64K,reinsert=hits:n=2/p=0.7/mode=ii")
vs_cachesim("obj_reinsert_p0.4", ["--ssd-mode", "object", "--ssd-policy", "lru", "--reinsert", "hits:n=1,p=0.4"],
            "ssd-mode=object,ssd-algo=lru,reinsert=hits:n=1/p=0.4")
vs_cachesim("warmup_100k", H + ["--warmup", "100000"], "hint=fixed:16K/64K,warmup-req=100000")
vs_cachesim("seed7_prob", ["--admit", "prob:p=0.5", "--seed", "7"], "admit=prob:p=0.5,seed=7")
vs_cachesim("seed7_adaptsize", ["--admit", "adaptsize:interval=20000,sample=0.1", "--seed", "7"],
            "admit=adaptsize:interval=20000/sample=0.1,seed=7")
# B. spellings that must agree
same("taus=16K/64K == hint=fixed:16K/64K", rf("taus", "hint=fixed,taus=16K/64K"), rf("fixed", "hint=fixed:16K/64K"))
same("region-evict=s3fifo == lcs:s3fifo", rf("rev_plain", "region-evict=s3fifo"), rf("rev_lcs", "region-evict=lcs:s3fifo"))
same("region-evict=beta,beta=0 == lru (1 class)", rf("beta0", "region-evict=beta,beta=0"), rf("lru", "region-evict=lru"))
a, b = rf("outname", "interval=50000"), None
r = subprocess.run([RF, TR, "oracleGeneral", "RegionFlash", str(SSD), "-e",
                    f"dram-size={DRAM},region-size={R},seal-on-repartition=inactive,interval=50000,prefix={OUT}/prefixname"], capture_output=True)
fa = sorted(os.path.basename(x)[len("outname"):] for x in glob.glob(f"{OUT}/outname.*"))
fb = sorted(os.path.basename(x)[len("prefixname"):] for x in glob.glob(f"{OUT}/prefixname.*"))
check("B out= and prefix= write the same files", fa == fb and all(
    open(f"{OUT}/outname{s}", "rb").read() == open(f"{OUT}/prefixname{s}", "rb").read() for s in fa), str(fa))
same("dram-size=8MiB == 8M == 8388608 == 0.0078125G", rf("sz1", "dram-size=8MiB"), rf("sz2", "dram-size=8388608"))
same("dram-size=8M == 0.0078125G", rf("sz3", "dram-size=8M"), rf("sz4", "dram-size=0.0078125G"))
same("chunk=1.5K == chunk=1536", rf("ck1", "chunk=1.5K"), rf("ck2", "chunk=1536"))
same("-a size(<65537) == admit=sizemax:max=64K(<=)", rf("asize", "interval=0", ("-a", "size", "--admission-params", "size=65537")),
     rf("sizemax", "interval=0,admit=sizemax:max=64K"))
same("-a size == admit=all when nothing is that large", rf("asize_big", "interval=0", ("-a", "size", "--admission-params", "size=4294967296")),
     rf("all", "interval=0"))
# C. behaviour
same("seed: same seed twice -> same result", rf("s1a", "admit=prob:p=0.5,seed=3"), rf("s1b", "admit=prob:p=0.5,seed=3"))
j1, j2 = (json.load(open(rf(n, f"admit=prob:p=0.5,seed={s}") + ".json"))["total"] for n, s in (("s2a", 3), ("s2b", 4)))
check("C seed: another seed -> other coin flips", j1["admit_reject_objs"] != j2["admit_reject_objs"],
      f"rejects {j1['admit_reject_objs']} vs {j2['admit_reject_objs']}")
p = rf("noiv", "interval=0")
check("C interval=0: no interval files", not glob.glob(p + ".interval*") and os.path.exists(p + ".json"))
print(f"{'ALL OK' if not bad else 'FAIL: ' + ', '.join(bad)}")
sys.exit(1 if bad else 0)
