#!/usr/bin/env python3
"""fdp_ref.py — Python mirror of the FDP device model in
libCacheSim/cache/eviction/flash/RegionFlash.c, driven by cachesim's reference
model (tests/ref_sim.py, region mode). Same algorithm and tie-breaks as the C code:

  - n_ru = floor(N*R*(1+op)/ru_size) Reclaim Units of spr = ru_size/R region slots
  - a sealed region is written to the open RU of RUH (class % n_ruh); a host
    region's previous slot becomes invalid when it is rewritten (or at eviction
    with trim)
  - greedy GC (full RU with the fewest valid slots, lowest index on ties) when
    free RUs <= gcres; copies go to one shared GC RU (ii) or one per RUH (pi)

Usage: python fdp_ref.py [--ref PATH_TO_cachesim/tests]   (runs the experiment)
"""
import argparse
import os
import random
import sys

NONE = None


class Fdp:
    def __init__(self, N, R, ru_size, n_ruh, pi=False, op=0.07, trim=False):
        assert ru_size % R == 0
        self.R, self.spr, self.n_ruh, self.pi, self.trim = R, ru_size // R, n_ruh, pi, trim
        self.n_ru = int(N * R * (1 + op) // ru_size)
        self.n_dest = n_ruh + (n_ruh if pi else 1)
        self.gcres = n_ruh if pi else 1
        need = -(-N // self.spr) + self.n_dest + self.gcres + 1
        assert self.n_ru >= need, f"{self.n_ru} RUs < {need}: raise op"
        self.slot_reg = [NONE] * (self.n_ru * self.spr)
        self.slot_cls = [0] * (self.n_ru * self.spr)
        self.valid = [0] * self.n_ru
        self.fill = [0] * self.n_ru
        self.tag = [0] * self.n_ru
        self.free = list(range(self.n_ru - 1, -1, -1))
        self.dest = [NONE] * self.n_dest
        self.reg_slot = {}
        self.in_gc = False
        self.host = self.gc = self.erases = 0
        self.cls_host, self.cls_gc = {}, {}

    def alloc(self):
        guard = 0
        while not self.in_gc and len(self.free) <= self.gcres:
            assert guard <= self.n_ru, "GC cannot free RUs"
            self.gc_one()
            guard += 1
        assert self.free, "no free RU during GC"
        return self.free.pop()

    def kill(self, r):
        s = self.reg_slot.pop(r, NONE)
        if s is not NONE:
            self.slot_reg[s] = NONE
            self.valid[s // self.spr] -= 1

    def place(self, d, r, c):
        u = self.dest[d]
        if u is NONE:
            u = self.alloc()
            self.dest[d] = u
            self.tag[u] = d if d < self.n_ruh else (d - self.n_ruh if self.pi else self.n_ruh)
        s = u * self.spr + self.fill[u]
        self.fill[u] += 1
        self.slot_reg[s], self.slot_cls[s] = r, c
        self.valid[u] += 1
        self.reg_slot[r] = s
        if self.fill[u] == self.spr:
            self.dest[d] = NONE

    def gc_one(self):
        v = NONE
        for u in range(self.n_ru):
            if self.fill[u] == self.spr and (v is NONE or self.valid[u] < self.valid[v]):
                v = u
        assert v is not NONE and self.valid[v] < self.spr, "no reclaimable RU"
        tag = self.tag[v]
        self.in_gc = True
        for i in range(self.spr):
            s = v * self.spr + i
            r = self.slot_reg[s]
            if r is NONE:
                continue
            c = self.slot_cls[s]
            self.kill(r)
            self.place(self.n_ruh + tag if self.pi else self.n_ruh, r, c)
            self.gc += self.R
            self.cls_gc[c] = self.cls_gc.get(c, 0) + self.R
        self.in_gc = False
        self.fill[v] = 0
        self.free.append(v)
        self.erases += 1

    def host_write(self, r, c):
        self.kill(r)
        self.place(c % self.n_ruh, r, c)
        self.host += self.R
        self.cls_host[c] = self.cls_host.get(c, 0) + self.R

    def dlwa(self):
        return (self.host + self.gc) / self.host if self.host else float("nan")


def make_sim(ref_sim, cfg, fdp):
    class FdpSim(ref_sim.RefSim):
        def seal(self, g):
            super().seal(g)
            fdp.host_write(g.rid, g.cls)

        def free_region(self, g):
            if fdp.trim:
                fdp.kill(g.rid)
            super().free_region(g)
    return FdpSim(cfg)


def trace(n_req, n_obj, seed=1):
    """Zipf-like popularity; small objects (1-4 KiB) are popular, large (64-256 KiB) are cold"""
    rng = random.Random(seed)
    sizes = [rng.randint(1024, 4096) if i % 4 else rng.randint(65536, 262144) for i in range(n_obj)]
    w = [1.0 / (i + 1) ** 0.9 for i in range(n_obj)]
    order = list(range(n_obj))
    rng.shuffle(order)                       # popularity rank independent of id
    ids = rng.choices(order, weights=w, k=n_req)
    return [(i, sizes[i]) for i in ids]


def main():
    ap = argparse.ArgumentParser()
    here = os.path.dirname(os.path.abspath(__file__))
    ap.add_argument("--ref", default=os.path.normpath(os.path.join(here, "../../../../cachesim/tests")))
    ap.add_argument("--req", type=int, default=200000)
    a = ap.parse_args()
    sys.path.insert(0, a.ref)
    import ref_sim

    R, N = 1 << 19, 128
    tr = trace(a.req, 20000)
    print(f"{'region-evict':12} {'ru/R':>4} {'ruh':>3} {'iso':>3} {'trim':>4} {'OHR':>7} {'DLWA':>7}  per-class DLWA")
    for rev in ("fifo", "lru"):
        for spr, n_ruh, pi, trim in ((1, 1, False, False), (4, 1, False, False), (4, 2, False, False),
                                     (4, 2, True, False), (4, 1, False, True), (4, 2, True, True)):
            fdp = Fdp(N, R, spr * R, n_ruh, pi=pi, op=0.25, trim=trim)
            cfg = dict(mode="region", R=R, N=N, dram=0, dram_policy="lru", inclusion="cachelib",
                       region_evict=rev, taus=[16384])
            s = make_sim(ref_sim, cfg, fdp)
            for oid, size in tr:
                s.request(oid, size)
            k = s.k
            assert k["flash_region_write_bytes"] == fdp.host
            ohr = (k.get("dram_hits", 0) + k.get("ssd_hits", 0)) / k["reqs"]
            per = " ".join(f"c{c}={(fdp.cls_host[c] + fdp.cls_gc.get(c, 0)) / fdp.cls_host[c]:.3f}"
                           for c in sorted(fdp.cls_host))
            print(f"{rev:12} {spr:4} {n_ruh:3} {'pi' if pi else 'ii':>3} {int(trim):4} {ohr:7.4f} {fdp.dlwa():7.3f}  {per}")


if __name__ == "__main__":
    main()
