"""check the hint split_threshold_req (RegionFlash, counted per request).
1. thresholds: an independent model of split_threshold.h fed with every
   request of the trace (lambda = 0: no cold data needed) gives the threshold
   after each recalc; RegionFlash with interval = recalc must show the same
   class bounds at every interval end.
2. histograms: with recalc beyond the run (no recompute, no decay) the sums
   in hint_result must equal the interval files' totals: scope=all -> reqs,
   req_bytes, miss_bytes; scope=ssd -> ssd_lookups, ssd_lookup_bytes,
   miss_bytes (+ size_add per request).
argv: binary trace(oracleGeneral, uncompressed) outdir"""
import csv, json, struct, subprocess, sys

BIN, TR, OUT = sys.argv[1:4]
NB, EMA, MIN_BAND, NOSPLIT = 48, 16, 2, 5
bad = []


def bucket(s):  # floor(log2(s)), capped (sst_bucket)
    return min(max(s.bit_length() - 1, 0), NB - 1)


def p50(h):
    tot = sum(h)
    if tot == 0:
        return -1
    cum = 0
    for b, v in enumerate(h):
        cum += v
        if cum * 2 >= tot:
            return b
    return NB - 1


def recompute(cnt, byt):  # sst_recompute with lambda = 0 (mid)
    cb, bb = p50(cnt), p50(byt)
    if cb < 0 or bb < 0 or bb - cb < MIN_BAND:
        return -1
    S = 1 << ((cb + bb + 1) // 2)
    tot = sum(byt)
    large = sum(v for b, v in enumerate(byt) if (1 << b) > S)
    return -1 if tot == 0 or large * 100 < tot * NOSPLIT else S


def model(sizes, recalc):
    cnt, byt, thr = [0] * NB, [0] * NB, []
    for n, s in enumerate(sizes, 1):
        b = bucket(s)
        cnt[b] += 1
        byt[b] += s
        if n % recalc == 0:
            thr.append(recompute(cnt, byt))
            cnt = [v * (EMA - 1) // EMA for v in cnt]
            byt = [v * (EMA - 1) // EMA for v in byt]
    return thr


def run(name, e):
    p = f"{OUT}/{name}"
    r = subprocess.run([BIN, TR, "oracleGeneral", "RegionFlash", "64mb", "-e", f"{e},out={p}"],
                       capture_output=True, text=True)
    if r.returncode:
        sys.exit(f"{name}: rc {r.returncode}\n{r.stderr[-2000:]}")
    return p


raw = open(TR, "rb").read()
sizes = [s for _, _, s, _ in struct.iter_unpack("<IQIq", raw) if s > 0]  # the CLI skips size 0
B = "dram-size=8MiB,region-size=1MiB"

# 1. thresholds after each recalc
for R in (10000, 25000):
    ref = model(sizes, R)
    p = run(f"thr{R}", f"{B},interval={R},hint=split_threshold_req:recalc={R}")
    got = {}
    for row in csv.DictReader(open(p + ".interval.class.csv")):
        if row["kind"] == "interval" and row["class"] == "0":
            got[int(row["interval"])] = -1 if row["hi"] == "inf" else int(row["hi"])
    n = min(len(ref), len(got))
    diff = [(k, ref[k], got[k]) for k in range(n) if ref[k] != got[k]]
    splits = sum(t >= 0 for t in ref)
    changes = sum(ref[k] != ref[k - 1] for k in range(1, len(ref)))
    print(f"thresholds recalc={R}: {n} recalcs, {splits} split, {changes} changes, "
          f"{'MATCH' if not diff and n == len(ref) else 'DIFF'}  values={sorted(set(ref))}")
    if diff:
        bad.append(f"recalc={R}: first diffs {diff[:5]}")
    hr = json.load(open(p + ".json"))["hint_result"]
    if hr["obs"] != len(sizes):
        bad.append(f"recalc={R}: obs {hr['obs']} != {len(sizes)} requests")

# 2. histogram sums, no recompute
for name, e, keys in (
        ("sum_all", f"{B},hint=split_threshold_req:recalc=1000000000", ("reqs", "req_bytes", "misses", "miss_bytes")),
        ("sum_ssd", f"{B},hint=split_threshold_req:recalc=1000000000/scope=ssd/size_add=100",
         ("ssd_lookups", "ssd_lookup_bytes", "misses", "miss_bytes")),
        ("sum_nodram", "dram-size=0,region-size=1MiB,hint=split_threshold_req:recalc=1000000000/scope=ssd",
         ("ssd_lookups", "ssd_lookup_bytes", "misses", "miss_bytes"))):
    p = run(name, f"{e},interval=40000")
    add = 100 if "size_add=100" in e else 0
    iv = [r for r in csv.DictReader(open(p + ".interval.csv")) if r["kind"] == "interval"]
    n, nb, m, mb = (sum(int(r[k]) for r in iv) for k in keys)
    hr = json.load(open(p + ".json"))["hint_result"]
    want = {"obs": n, "count": n, "bytes": nb + add * n, "cold_bytes": mb + add * m}
    d = {k: (hr[k], v) for k, v in want.items() if hr[k] != v}
    print(f"{name}: obs {hr['obs']} bytes {hr['bytes']} cold {hr['cold_bytes']} "
          f"{'MATCH' if not d else 'DIFF ' + str(d)}")
    if d:
        bad.append(f"{name}: {d}")
print("ALL OK" if not bad else "FAIL\n  " + "\n  ".join(bad))
sys.exit(1 if bad else 0)
