#!/usr/bin/env python3
"""trace_cmp.py — cachesim vs RegionFlash on a real oracleGeneral trace (the
main experiment settings: region LRU, chunk 1M, cachelib inclusion, DRAM LRU)
for the hint / admission / reinsertion plugins; every total and per-class
counter must match exactly.

Usage (in WSL):
  python3 trace_cmp.py --trace T.oracleGeneral.zst --ssd 10395324211 \
      --dram 173255403 --R 64M,126M [--max-req N] [--jobs 8] [--out /root/tc] [case ...]
--max-req reads only the first N requests of the trace (cachesim --max-req, libCacheSim --num-req).
"""
import argparse
import csv
import json
import os
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor

TOT = """reqs req_bytes dram_hits ssd_hits misses hit_bytes miss_bytes ssd_lookups ssd_admit_objs ssd_admit_bytes
dram_evict_objs clean_skip_objs admit_reject_objs ssd_copy_lost_rewrites ssd_evict_objs ssd_evict_bytes
dead_evict_objs dead_evict_bytes regions_sealed regions_evicted repartition_seals pad_bytes
flash_region_write_bytes too_large_objs reinsert_bytes chunk_objs chunk_pieces chunk_write_aborts
chunk_loss_head chunk_loss_other chunk_orphan_bytes""".split()
CLS = {"reqs": "reqs", "req_bytes": "req_bytes", "dram_hits": "dram_hits", "ssd_lookups": "ssd_lookups",
       "ssd_hits": "ssd_hits", "hit_bytes": "hit_bytes", "miss_bytes": "miss_bytes", "admit_objs": "ssd_admit_objs",
       "admit_bytes": "ssd_admit_bytes", "evict_objs": "ssd_evict_objs", "evict_bytes": "ssd_evict_bytes",
       "dead_evict_objs": "dead_evict_objs", "dead_evict_bytes": "dead_evict_bytes"}
HY = "hyst_hold=4,hyst_band=2"
# name, hint, admit, extra cachesim args, extra RegionFlash -e (cachesim's ',' lists use '/')
CASES = [
    ("none", "none", "all", (), ""),
    ("fifo_none", "none", "all", ("--region-evict", "fifo"), ",region-evict=fifo"),
    ("fx_32K", "fixed:32K", "all", (), ""),
    ("fx_16K_64K", "fixed:16K,64K", "all", (), ""),
    ("st", "split_threshold", "all", (), ""),
    ("st_h", f"split_threshold:{HY}", "all", (), ""),
    ("rec2_h", f"st_recursive:depth=2,{HY}", "all", (), ""),
    ("sthr4_h", f"st_hitrate:hr=50%,hr_hyst=5%,{HY}", "all", (), ""),
    ("st_hr_refine", "st_hr_refine", "all", (), ""),
    ("hr_segment", "hr_segment", "all", (), ""),
    ("og2", "oracle_gdt:k=2", "all", (), ""),
    ("og4", "oracle_gdt:k=4", "all", (), ""),
    ("oracle_key_dist", "oracle_key:key=dist", "all", (), ""),
    ("key_size", "key:key=size", "all", (), ""),
    ("key_hash", "key:key=hash", "all", (), ""),
    ("key_dram", "key:key=dram,k=2", "all", (), ""),
    ("key_gap", "key:key=gap", "all", (), ""),
    ("key_freq_cms", "key:key=freq,fsrc=cms", "all", (), ""),
    ("key_sizefreq", "key:key=sizefreq,k=4,kf=2", "all", (), ""),
    ("adm_prob", "none", "prob:p=0.5", (), ""),
    ("adm_seen", "split_threshold", "seen", (), ""),
    ("adm_tinylfu", "split_threshold", "tinylfu", (), ""),
    ("adm_cachesack", "split_threshold", "cachesack", (), ""),
    ("adm_adaptsize", "none", "adaptsize", (), ""),
    ("reinsert_pi", "split_threshold", "all", ("--reinsert", "hits:n=1"), ",reinsert=hits:n=1"),
    ("reinsert_ii", "split_threshold", "all", ("--reinsert", "hits:n=1,mode=ii"), ",reinsert=hits:n=1/mode=ii"),
]


def run(a, rbin, R, case):
    name, hint, admit, xcs, xrf = case
    d = f"{a.out}/R{R}/{name}"
    os.makedirs(d, exist_ok=True)
    cs = [a.cachesim, "--trace", a.trace, "--trace-format", "oracleGeneral", "--ssd-size", str(a.ssd),
          "--region-size", R, "--dram-size", str(a.dram), "--ssd-mode", "region", "--chunk", "1M",
          "--region-evict", "lru", "--inclusion", "cachelib", "--hint", hint, "--admit", admit, "--out", d, *xcs]
    if a.max_req:
        cs += ["--max-req", str(a.max_req)]
    e = (f"dram-size={a.dram},dram-algo=lru,region-size={R},region-evict=lru,chunk=1M,inclusion=cachelib,seal-on-repartition=inactive,"
         f"hint={hint.replace(',', '/')},admit={admit.replace(',', '/')},out={d}/rf{xrf}")
    rf = [rbin, a.trace, "oracleGeneral", "RegionFlash", str(a.ssd), "-e", e]
    if a.max_req:
        rf += ["--num-req", str(a.max_req)]
    for cmd, log in ((cs, "cs.log"), (rf, "rf.log")):
        with open(f"{d}/{log}", "w") as f:
            if subprocess.run(cmd, stdout=f, stderr=subprocess.STDOUT).returncode:
                return f"R={R:5s} {name:16s} FAILED ({log})"
    sj = json.load(open(f"{d}/summary.json"))
    ct = sj["result"]
    cc = {int(r["cls"]): r for r in csv.DictReader(open(f"{d}/class_summary.csv"))}
    rj = json.load(open(f"{d}/rf.json"))
    bad = [f"{k}: cs {ct.get(k, 0)} rf {rj['total'][k]}" for k in TOT if ct.get(k, 0) != rj["total"][k]]
    for c in rj["class"]:
        r = cc.get(c["class"])
        for ck, rk in CLS.items():
            cv = int(float(r[ck])) if r else 0
            if cv != c[rk]:
                bad.append(f"class {c['class']} {rk}: cs {cv} rf {c[rk]}")
    head = (f"R={R:5s} {name:16s} k={len(rj['class']):2d} OHR cs {ct['ohr']:.6f} rf {rj['total']['ohr']:.6f} "
            f"evicted {rj['total']['regions_evicted']} {'MATCH' if not bad else 'DIFF ' + str(len(bad))}")
    return "\n".join([head] + ["    " + b for b in bad[:6]])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--trace", required=True)
    ap.add_argument("--ssd", type=int, required=True)
    ap.add_argument("--dram", type=int, required=True)
    ap.add_argument("--R", default="64M")
    ap.add_argument("--cachesim", default="/root/cs/cachesim")
    ap.add_argument("--regionflash", default="/root/b/bin/cachesim")
    ap.add_argument("--out", default="/root/tc")
    ap.add_argument("--jobs", type=int, default=8)
    ap.add_argument("--max-req", type=int, default=0)
    ap.add_argument("cases", nargs="*")
    a = ap.parse_args()
    cases = [c for c in CASES if not a.cases or c[0] in a.cases]
    work = [(R, c) for R in a.R.split(",") for c in cases]
    with ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(lambda w: run(a, a.regionflash, *w), work))
    for r in res:
        print(r, flush=True)
    ok = sum(" MATCH" in r for r in res)
    print(f"{ok}/{len(res)} match")
    sys.exit(0 if ok == len(res) else 1)


if __name__ == "__main__":
    main()
