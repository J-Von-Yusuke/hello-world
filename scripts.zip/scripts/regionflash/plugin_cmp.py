"""Run cachesim and RegionFlash on the same oracleGeneral trace for each hint /
admit config; compare total and per-class counters exactly."""
import csv, json, os, subprocess, sys

CS, RF, TR = "/root/cs/cachesim", "/root/b/bin/cachesim", "/root/cmp/t.og"
SSD, R, DRAM = 64 << 20, 1 << 20, 8 << 20
TOT = """reqs req_bytes dram_hits ssd_hits misses hit_bytes miss_bytes ssd_lookups ssd_admit_objs ssd_admit_bytes
dram_evict_objs clean_skip_objs admit_reject_objs ssd_copy_lost_rewrites ssd_evict_objs ssd_evict_bytes
dead_evict_objs dead_evict_bytes oracle_never_bytes oracle_reused_bytes regions_sealed regions_evicted
repartition_seals pad_bytes flash_region_write_bytes too_large_objs""".split()
CLS = {"reqs": "reqs", "req_bytes": "req_bytes", "dram_hits": "dram_hits", "ssd_lookups": "ssd_lookups",
       "ssd_hits": "ssd_hits", "hit_bytes": "hit_bytes", "miss_bytes": "miss_bytes", "admit_objs": "ssd_admit_objs",
       "admit_bytes": "ssd_admit_bytes", "evict_objs": "ssd_evict_objs", "evict_bytes": "ssd_evict_bytes",
       "dead_evict_objs": "dead_evict_objs", "dead_evict_bytes": "dead_evict_bytes"}


def run(name, hint="none", admit="all", extra_cs=(), extra_rf=""):
    d = f"/root/cmp/r_{name}"
    os.makedirs(d, exist_ok=True)
    subprocess.run([CS, "--trace", TR, "--trace-format", "oracleGeneral", "--ssd-size", str(SSD), "--region-size", str(R),
                    "--dram-size", str(DRAM), "--hint", hint, "--admit", admit, "--out", d, *extra_cs],
                   check=True, stdout=subprocess.DEVNULL)
    sj = json.load(open(f"{d}/summary.json"))
    cs_tot = sj["result"]
    cs_cls = {int(r["cls"]): r for r in csv.DictReader(open(f"{d}/class_summary.csv"))}
    e = (f"dram-size={DRAM},dram-algo=lru,region-size={R},seal-on-repartition=inactive,hint={hint.replace(',', '/')},"
         f"admit={admit.replace(',', '/')},out={d}/rf{extra_rf}")
    subprocess.run([RF, TR, "oracleGeneral", "RegionFlash", str(SSD), "-e", e], check=True,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    rj = json.load(open(f"{d}/rf.json"))
    bad = [f"{k}: cs {cs_tot[k]} rf {rj['total'][k]}" for k in TOT if cs_tot[k] != rj["total"][k]]
    for c in rj["class"]:
        r = cs_cls.get(c["class"])
        for ck, rk in CLS.items():
            cv = int(float(r[ck])) if r else 0
            if cv != c[rk]:
                bad.append(f"class {c['class']} {rk}: cs {cv} rf {c[rk]}")
    print(f"{name:28s} k={len(rj['class']):2d} OHR cs {cs_tot['ohr']:.6f} rf {rj['total']['ohr']:.6f} "
          f"{'MATCH' if not bad else 'DIFF ' + str(len(bad))}", flush=True)
    for b in bad[:6]:
        print("   ", b)
    return not bad


cases = [
    ("none", "none", "all"),
    ("fixed", "fixed:16K,64K", "all"),
    ("split_threshold", "split_threshold:recalc=20000", "all"),
    ("st_recursive", "st_recursive:depth=2,recalc=20000", "all"),
    ("st_hr_refine", "st_hr_refine:recalc=20000,min_obs=20", "all"),
    ("hr_segment", "hr_segment:recalc=20000,min_obs=20", "all"),
    ("st_hitrate", "st_hitrate:recalc=20000,hr_window=20000", "all"),
    ("profile", "profile:path=/root/cmp/r_fixed/sizebin_profile.csv,method=qbytes,k=3", "all"),
    ("key_size", "key:key=size,recalc=20000", "all"),
    ("key_hash", "key:key=hash", "all"),
    ("key_dram", "key:key=dram,k=2,recalc=20000", "all"),
    ("key_gap", "key:key=gap,recalc=20000", "all"),
    ("key_freq_cms", "key:key=freq,fsrc=cms,fmem=64K,fwin=50000,recalc=20000", "all"),
    ("key_sizefreq", "key:key=sizefreq,k=4,kf=2,recalc=20000", "all"),
    ("oracle_gdt", "oracle_gdt:k=4,recalc=20000", "all"),
    ("oracle_key_dist", "oracle_key:key=dist,recalc=20000", "all"),
    ("oracle_keyinfo", "oracle_keyinfo:window=50000", "all"),
    ("adm_prob", "none", "prob:p=0.5"),
    ("adm_sizemax", "fixed:16K,64K", "sizemax:max=64K"),
    ("adm_sizeexp", "fixed:16K,64K", "sizeexp:c=32K"),
    ("adm_seen", "fixed:16K,64K", "seen:m=50000"),
    ("adm_cachesack", "fixed:16K,64K", "cachesack:interval=20000"),
    ("adm_tinylfu", "fixed:16K,64K", "tinylfu:width=65536,window=50000"),
    ("adm_adaptsize", "fixed:16K,64K", "adaptsize:interval=20000,sample=0.1"),
    ("adm_oracle_opt_pass1", "none", "oracle_opt:log=/root/cmp/look.bin"),
    ("adm_oracle_opt_pass2", "fixed:16K,64K", "oracle_opt:episodes=/root/cmp/look.bin"),
    ("seen_split_threshold", "split_threshold:recalc=20000", "seen:m=50000"),
    ("seen_nodram", "fixed:16K,64K", "seen:m=50000", ("--dram-size", "0"), ",dram-size=0"),
    ("st_reinsert_reclass", "split_threshold:recalc=20000", "all",
     ("--reinsert", "hits:n=1,class=reclassify,hint_on_reinsert=yes"),
     ",reinsert=hits:n=1/class=reclassify/hint_on_reinsert=yes"),
    ("obj_key_dram_tinylfu", "key:key=dram,k=2,recalc=20000", "tinylfu:width=65536,window=50000",
     ("--ssd-mode", "object", "--ssd-policy", "lru"), ",ssd-mode=object,ssd-algo=lru"),
]
ok = sum(run(*c) for c in cases if not sys.argv[1:] or c[0] in sys.argv[1:])
print(f"{ok}/{len(cases) if not sys.argv[1:] else len(sys.argv) - 1} match")
