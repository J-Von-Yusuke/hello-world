"""oracleGeneral trace: <uint32 t, uint64 id, uint32 size, int64 next(1-based, -1 none)>"""
import random, struct, sys
out, n, nobj, seed = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
rng = random.Random(seed)
w = [1 / (i + 1) ** 0.9 for i in range(nobj)]
size = {i: max(1, int(rng.lognormvariate(9.5, 1.6))) % (900 * 1024) + 1 for i in range(nobj)}
ids = rng.choices(range(nobj), weights=w, k=n)
nxt, last = [-1] * n, {}
for k in range(n - 1, -1, -1):
    nxt[k] = last.get(ids[k], -1)
    last[ids[k]] = k + 1  # 1-based index of this request
with open(out, "wb") as f:
    for k, i in enumerate(ids):
        f.write(struct.pack("<IQIq", k + 1, i + 1, size[i], nxt[k]))
