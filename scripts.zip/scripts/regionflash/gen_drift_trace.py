"""a trace whose size mix drifts, so a per-request SplitThreshold moves:
phase 0 small-only (narrow band: no split), then a large tail that grows,
then the small sizes shift up, then large only (narrow again). Zipf-like
popularity inside each phase. oracleGeneral, uncompressed; next access -2.
argv: out n  (st_req_check.py checks split_threshold_req on it)"""
import random, struct, sys

out, n = sys.argv[1], int(sys.argv[2])
rnd = random.Random(7)
phases = [  # (small sizes, large sizes, share of large requests)
    ((1 << 10, 1 << 12), (1 << 18, 1 << 19), 0.0),
    ((1 << 10, 1 << 12), (1 << 18, 1 << 20), 0.05),
    ((1 << 10, 1 << 12), (1 << 18, 1 << 20), 0.25),
    ((1 << 13, 1 << 15), (1 << 18, 1 << 20), 0.25),
    ((1 << 13, 1 << 15), (1 << 16, 1 << 17), 0.0),
]
nobj = 20000
with open(out, "wb") as f:
    for t in range(n):
        ph = t * len(phases) // n
        sm, lg, pl = phases[ph]
        large = rnd.random() < pl
        rank = int(nobj ** rnd.random())  # ~ 1/rank popularity
        oid = (ph * 4 + large * 2 + 1) * 10 ** 6 + rank  # new objects per phase
        r = random.Random(oid)
        lo, hi = lg if large else sm
        size = r.randint(lo, hi)
        f.write(struct.pack("<IQIq", t, oid, size, -2))
