#!/usr/bin/env python3
"""diff_ref.py — differential test of RegionFlash (C, libCacheSim) against
cachesim's independent reference model tests/ref_sim.py, plus the FDP mirror in
fdp_ref.py. Random small traces and configs; every counter the reference model
keeps must match the C run's <out>.json "total" exactly.

Usage (after building libCacheSim):
  python diff_ref.py --bin _build/bin/cachesim [--n 300] [--seed 1]
"""
import argparse
import json
import os
import random
import subprocess
import sys
import tempfile

here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, here)
import fdp_ref  # noqa: E402

# every counter ref_sim.py keeps in region mode without reinsertion / stream merge
REF_KEYS = """reqs req_bytes size_change_misses dram_hits hit_bytes ssd_hits misses miss_bytes
dram_evict_objs clean_skip_objs ssd_copy_lost_rewrites too_large_objs ssd_admit_objs ssd_admit_bytes
ssd_evict_objs ssd_evict_bytes dead_evict_objs pad_bytes regions_sealed flash_region_write_bytes
regions_evicted chunk_objs chunk_pieces chunk_write_aborts chunk_loss_head chunk_loss_other
chunk_orphan_bytes reinsert_bytes""".split()


def rand_case(rng):
    R = rng.choice([4096, 10000])
    taus = rng.choice([[], [R // 4], [R // 8, R // 2]])
    chunk = rng.choice([0, 0, R // 3])
    N = rng.randint(len(taus) + 3, 12)
    cfg = dict(mode="region", R=R, N=N, dram=rng.choice([0, 0, 2 * R]),
               dram_policy=rng.choice(["lru", "fifo"]),
               inclusion=rng.choice(["cachelib", "exclusive", "inclusive"]),
               region_evict=rng.choice(["fifo", "lru"]), taus=taus, chunk=chunk)
    cfg["c_dram"] = rng.choice(["dram-policy", "dram-algo"])           # same thing, two spellings
    fdp = None
    if rng.random() < 0.25:                                                   # ssd-mode=object = ref ideal
        cfg.update(mode="ideal", ssd=rng.randint(R // 2, 8 * R), ssd_policy=rng.choice(["fifo", "lru"]), chunk=0)
    elif rng.random() < 0.5:
        spr, ruh, pi = rng.choice([1, 2, 3, 4]), rng.choice([1, 2]), rng.random() < 0.5
        cfg["region_evict"] = rng.choice(["fifo", "lru", "lru"])                  # LRU makes device GC copy
        N = cfg["N"] = rng.randint(12, 40)                                         # many RUs: copies, not just erases
        need = -(-N // spr) + ruh + (ruh if pi else 1) + (ruh if pi else 1) + 1   # RUs fdp_init requires
        op = (need * spr + rng.randint(0, spr)) / N - 1 + 1e-9                # smallest OP that passes, + slack
        fdp = dict(spr=spr, ruh=ruh, pi=pi, trim=rng.random() < 0.5, op=op)
    if rng.random() < 0.4:                                                    # --reinsert hits:...
        region = cfg["mode"] == "region"
        cfg.update(re_on=True, re_n=rng.choice([1, 2]), re_max_size=rng.choice([0, 0, R // 4]),
                   re_frac=rng.choice([0.25, 0.5, 1.0]), re_mode=rng.choice(["pi", "ii"]) if region else "pi")
        if cfg["re_mode"] == "ii":
            cfg["N"] = max(cfg["N"], len(taus) + 4)                           # one more OPEN region: the hot class
    cfg["c_rev"] = cfg["region_evict"]
    if cfg["region_evict"] == "fifo" and rng.random() < 0.5:
        cfg["c_rev"] = "lcs:fifo"                                             # libCacheSim FIFO over regions
    n_obj, sizes, tr = rng.randint(50, 400) if fdp else rng.randint(5, 60), {}, []
    for _ in range(rng.randint(200, 8000 if fdp else 3000)):
        i = rng.randint(1, n_obj)
        if i not in sizes or rng.random() < 0.03:          # size change
            sizes[i] = rng.choice([0, rng.randint(1, R // 4), rng.randint(1, 3 * R // 2)])
        tr.append((i, sizes[i]))
    return cfg, fdp, tr


def run_c(binary, cfg, fdp, tr, tmp):
    trace = os.path.join(tmp, "t.csv")
    with open(trace, "w") as f:
        for t, (i, s) in enumerate(tr):   # the CLI drops size-0 requests; ref_sim reads 0 as 1
            f.write(f"{t + 1},{i},{max(s, 1)}\n")
    e = [f"dram-size={cfg['dram']}", f"{cfg['c_dram']}={cfg['dram_policy']}", f"inclusion={cfg['inclusion']}",
         f"out={os.path.join(tmp, 'o')}"]
    if cfg["mode"] == "ideal":
        e += ["ssd-mode=object", f"ssd-algo={cfg['ssd_policy']}"]
    else:
        e += [f"region-size={cfg['R']}", f"region-evict={cfg['c_rev']}", f"chunk={cfg['chunk']}"]
    if cfg.get("re_on"):
        e += [f"reinsert=hits:n={cfg['re_n']}/max_size={cfg['re_max_size']}/max_frac={cfg['re_frac']}/mode={cfg['re_mode']}"]
    if cfg["taus"]:
        e += ["hint=fixed", "taus=" + "/".join(map(str, cfg["taus"]))]
    if fdp:
        e += [f"ru-size={fdp['spr'] * cfg['R']}", f"ruh={fdp['ruh']}", f"fdp-iso={'pi' if fdp['pi'] else 'ii'}",
              f"fdp-op={fdp['op']}", f"fdp-trim={int(fdp['trim'])}"]
    subprocess.run([binary, trace, "csv", "RegionFlash", str(cfg["ssd"] if cfg["mode"] == "ideal" else cfg["N"] * cfg["R"]),
                    "-t", "time-col=1,obj-id-col=2,obj-size-col=3,has-header=false,obj-id-is-num=true",
                    "-e", ",".join(e)], check=True, capture_output=True, cwd=tmp)
    with open(os.path.join(tmp, "o.json")) as f:
        return json.load(f)["total"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bin", required=True)
    ap.add_argument("--ref", default=os.path.normpath(os.path.join(here, "../../../../cachesim/tests")))
    ap.add_argument("--n", type=int, default=300)
    ap.add_argument("--seed", type=int, default=1)
    a = ap.parse_args()
    sys.path.insert(0, a.ref)
    import ref_sim

    binary, rng, bad = os.path.abspath(a.bin), random.Random(a.seed), 0
    for case in range(a.n):
        cfg, fdpc, tr = rand_case(rng)
        fdp = fdp_ref.Fdp(cfg["N"], cfg["R"], fdpc["spr"] * cfg["R"], fdpc["ruh"], fdpc["pi"],
                          fdpc["op"], fdpc["trim"]) if fdpc else None
        sim = fdp_ref.make_sim(ref_sim, cfg, fdp) if fdp else ref_sim.RefSim(cfg)
        for i, s in tr:
            sim.request(i, s)
        want = {k: sim.k.get(k, 0) for k in REF_KEYS}
        if fdp:
            want["fdp_gc_copy_bytes"] = fdp.gc
            want["nand_write_bytes"] = fdp.host + fdp.gc
        with tempfile.TemporaryDirectory() as tmp:
            try:
                got = run_c(binary, cfg, fdpc, tr, tmp)
            except subprocess.CalledProcessError as err:
                bad += 1
                print(f"case {case}: C FAILED {cfg} fdp={fdpc}: {err.stderr.decode(errors='replace').strip()[-300:]}")
                continue
        diff = {k: (v, got.get(k)) for k, v in want.items() if got.get(k) != v}
        if diff:
            bad += 1
            print(f"case {case}: MISMATCH {cfg} fdp={fdpc} {diff}")
    print(f"{a.n - bad}/{a.n} cases match")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
