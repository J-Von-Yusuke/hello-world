#include "./mrcProfiler.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <memory>
#include <ostream>
#include <set>
#include <string>
#include <unordered_map>
#include <vector>

#include "../dataStructure/minvaluemap.hpp"
#include "../dataStructure/splaytree.hpp"
#include "libCacheSim/const.h"

/* the number of distinct 64-bit hash values (2^64), used to convert between
 * hash values and sampling rates. UINT64_MAX itself cannot be represented
 * exactly as a double, so using it in floating point arithmetic silently
 * rounds to this value and warns under -Wimplicit-const-int-float-conversion */
static constexpr double kHashSpaceSize = 18446744073709551616.0;

/* log2 of the hash table size for the miniature caches MINISIM simulates. The
 * caches are small, so a smaller table than cachesim's is appropriate. */
static constexpr int kMiniSimHashPower = 20;

/* whether a reader fills in req->next_access_vtime, which the Belady policies
 * need; every other reader leaves it at -2.
 *
 * Most oracle formats carry it unconditionally, so the trace type alone
 * answers for them. The generic binary reader is the exception: it populates
 * the field only when the caller points next_access_vtime_field at the right
 * column, so a BIN_TRACE has to be asked rather than assumed. That is a
 * library-only configuration today — no CLI exposes the field — but the
 * profiler is part of the library, so a caller can set it up. */
static bool reader_has_next_access_vtime(const reader_t *reader) {
  switch (reader->trace_type) {
    case ORACLE_GENERAL_TRACE:
    case LCS_TRACE:
    case ORACLE_SIM_TWR_TRACE:
    case ORACLE_SYS_TWR_TRACE:
    case ORACLE_SIM_TWRNS_TRACE:
    case ORACLE_SYS_TWRNS_TRACE:
      return true;
    case BIN_TRACE:
      return reader->init_params.next_access_vtime_field > 0;
    default:
      return false;
  }
}

mrcProfiler::MRCProfilerBase *mrcProfiler::create_mrc_profiler(
    mrc_profiler_e type, reader_t *reader, std::string output_path,
    const mrc_profiler_params_t &params) {
  switch (type) {
    case mrc_profiler_e::SHARDS_PROFILER:
      return new MRCProfilerSHARDS(reader, output_path, params);
    case mrc_profiler_e::MINISIM_PROFILER:
      return new MRCProfilerMINISIM(reader, output_path, params);
    default:
      ERROR("unknown profiler type %d\n", type);
      exit(1);
  }
}

void mrcProfiler::MRCProfilerBase::print(const char *output_path) {
  if (!has_run_) {
    ERROR("MRCProfiler has not been run\n");
    return;
  }

  FILE *outfp = stdout;
  bool open_output_file = false;
  if (output_path != nullptr && strlen(output_path) != 0) {
    outfp = fopen(output_path, "w");
    open_output_file = true;
    if (outfp == nullptr) {
      WARN("failed to open file %s\n", output_path);
      outfp = stdout;
      open_output_file = false;
    }
  }

  fprintf(outfp, "profiler: %s\n", profiler_name_);
  fprintf(outfp, "trace: %s\n", reader_->trace_path);
  fprintf(outfp, "cache_algorithm: %s\n", params_.cache_algorithm_str);
  fprintf(outfp, "n_req: %ld\n", n_req_);
  fprintf(outfp, "sum_obj_size_req: %ld\n", sum_obj_size_req);

  if (params_.profile_wss_ratio.size() != 0) {
    fprintf(outfp, "wss_ratio\t");
  }
  fprintf(outfp, "cache_size\tmiss_rate\tbyte_miss_rate\n");
  for (size_t i = 0; i < mrc_size_vec.size(); i++) {
    if (params_.profile_wss_ratio.size() != 0) {
      fprintf(outfp, "%lf\t", params_.profile_wss_ratio[i]);
    }
    double miss_rate = 1 - (double)hit_cnt_vec[i] / (n_req_);
    double byte_miss_rate = 1 - (double)hit_size_vec[i] / (sum_obj_size_req);

    // clip to [0, 1]
    miss_rate = miss_rate > 1 ? 1 : (miss_rate < 0 ? 0 : miss_rate);
    byte_miss_rate =
        byte_miss_rate > 1 ? 1 : (byte_miss_rate < 0 ? 0 : byte_miss_rate);
    fprintf(outfp, "%ldB\t%lf\t%lf\n", mrc_size_vec[i], miss_rate,
            byte_miss_rate);
  }

  if (open_output_file) {
    fclose(outfp);
  }
}

void mrcProfiler::MRCProfilerSHARDS::run() {
  if (has_run_) return;

  if (params_.shards_params.enable_fix_size) {
    fixed_sample_size_run();
  } else {
    fixed_sample_rate_run();
  }

  has_run_ = true;
}

void mrcProfiler::MRCProfilerSHARDS::fixed_sample_rate_run() {
  // 1. init
  request_t *req = new_request();
  double sample_rate = params_.shards_params.sample_rate;
  std::vector<double> local_hit_cnt_vec(mrc_size_vec.size(), 0);
  std::vector<double> local_hit_size_vec(mrc_size_vec.size(), 0);
  uint64_t sample_max;
  if (sample_rate >= 1) {
    INFO("sample_rate is 1, no need to sample\n");
    sample_max = UINT64_MAX;
  } else {
    /* parse_params restricts sample_rate to (0, 1], so the product here is
     * exact and stays below 2^64 */
    sample_max = static_cast<uint64_t>(kHashSpaceSize * sample_rate);
  }
  double sampled_cnt = 0, sampled_size = 0;
  int64_t current_time = 0;
  robin_hood::unordered_map<obj_id_t, int64_t> last_access_time_map;
  SplayTree<int64_t, uint64_t> rd_tree;

  // 2. go through the trace
  read_one_req(reader_, req);
  /* going through the trace */
  do {
    DEBUG_ASSERT(req->obj_size != 0);
    n_req_ += 1;
    sum_obj_size_req += req->obj_size;

    uint64_t hash_value = get_hash_value_int_64_with_salt(
        req->obj_id, params_.shards_params.salt);
    current_time += 1;
    if (hash_value <= sample_max) {
      sampled_cnt += 1.0 / sample_rate;
      sampled_size += 1.0 * req->obj_size / sample_rate;

      if (last_access_time_map.count(req->obj_id)) {
        int64_t last_access_time = last_access_time_map[req->obj_id];
        size_t stack_distance =
            rd_tree.getDistance(last_access_time) / sample_rate;

        last_access_time_map[req->obj_id] = current_time;

        // update tree
        rd_tree.erase(last_access_time);
        rd_tree.insert(current_time, req->obj_size);

        // find bucket to increase hit cnt and hit size
        auto it = std::lower_bound(mrc_size_vec.begin(), mrc_size_vec.end(),
                                   stack_distance);

        if (it != mrc_size_vec.end()) {
          // update hit cnt and hit size
          int idx = std::distance(mrc_size_vec.begin(), it);
          local_hit_cnt_vec[idx] += 1.0 / sample_rate;
          local_hit_size_vec[idx] += 1.0 * req->obj_size / sample_rate;
        }

      } else {
        last_access_time_map[req->obj_id] = current_time;
        // update the tree
        rd_tree.insert(current_time, req->obj_size);
      }
    }

    read_one_req(reader_, req);
  } while (req->valid);

  // 3. adjust the hit cnt and hit size
  local_hit_cnt_vec[0] += n_req_ - sampled_cnt;
  local_hit_size_vec[0] += sum_obj_size_req - sampled_size;

  free_request(req);

  // 4. calculate the mrc
  int64_t accu_hit_cnt = 0, accu_hit_size = 0;
  for (size_t i = 0; i < mrc_size_vec.size(); i++) {
    accu_hit_cnt += local_hit_cnt_vec[i];
    accu_hit_size += local_hit_size_vec[i];
    hit_cnt_vec[i] = accu_hit_cnt;
    hit_size_vec[i] = accu_hit_size;
  }
}

void mrcProfiler::MRCProfilerSHARDS::fixed_sample_size_run() {
  // 1. init
  request_t *req = new_request();
  double sample_rate = 1.0;
  std::vector<double> local_hit_cnt_vec(mrc_size_vec.size(), 0);
  std::vector<double> local_hit_size_vec(mrc_size_vec.size(), 0);
  double sampled_cnt = 0, sampled_size = 0;
  int64_t current_time = 0;
  int64_t max_to_keep = params_.shards_params.sample_size;

  MinValueMap<int64_t, uint64_t> min_value_map(max_to_keep);
  robin_hood::unordered_map<obj_id_t, int64_t> last_access_time_map;
  SplayTree<int64_t, uint64_t> rd_tree;

  // 2. go through the trace
  read_one_req(reader_, req);
  /* going through the trace */
  do {
    DEBUG_ASSERT(req->obj_size != 0);
    n_req_ += 1;
    sum_obj_size_req += req->obj_size;

    uint64_t hash_value = get_hash_value_int_64_with_salt(
        req->obj_id, params_.shards_params.salt);

    current_time += 1;
    if (!min_value_map.full() || hash_value < min_value_map.get_max_value() ||
        last_access_time_map.count(req->obj_id)) {
      // this is a sampled req

      if (!last_access_time_map.count(req->obj_id)) {
        bool poped = false;
        int64_t poped_id = min_value_map.insert(req->obj_id, hash_value, poped);
        if (poped) {
          // this is a sampled req
          int64_t poped_id_access_time = last_access_time_map[poped_id];
          rd_tree.erase(poped_id_access_time);
          last_access_time_map.erase(poped_id);
        }
      }

      if (!min_value_map.full()) {
        sample_rate = 1.0;  // still 100% sample rate
      } else {
        sample_rate = min_value_map.get_max_value() * 1.0 /
                      kHashSpaceSize;  // adjust the sample rate
      }

      sampled_cnt += 1.0 / sample_rate;
      sampled_size += 1.0 * req->obj_size / sample_rate;

      if (last_access_time_map.count(req->obj_id)) {
        int64_t last_acc_time = last_access_time_map[req->obj_id];
        int64_t stack_distance =
            rd_tree.getDistance(last_acc_time) * 1.0 / sample_rate;

        last_access_time_map[req->obj_id] = current_time;

        rd_tree.erase(last_acc_time);
        rd_tree.insert(current_time, req->obj_size);

        // find bucket to increase hit cnt and hit size
        auto it = std::lower_bound(mrc_size_vec.begin(), mrc_size_vec.end(),
                                   stack_distance);

        if (it != mrc_size_vec.end()) {
          // update hit cnt and hit size
          int idx = std::distance(mrc_size_vec.begin(), it);
          local_hit_cnt_vec[idx] += 1.0 / sample_rate;
          local_hit_size_vec[idx] += req->obj_size * 1.0 / sample_rate;
        }
      } else {
        last_access_time_map[req->obj_id] = current_time;
        rd_tree.insert(current_time, req->obj_size);
      }
    }

    read_one_req(reader_, req);
  } while (req->valid);

  // 3. adjust the hit cnt and hit size
  local_hit_cnt_vec[0] += n_req_ - sampled_cnt;
  local_hit_size_vec[0] += sum_obj_size_req - sampled_size;

  free_request(req);

  // 4. calculate the mrc
  int64_t accu_hit_cnt = 0, accu_hit_size = 0;
  for (size_t i = 0; i < mrc_size_vec.size(); i++) {
    accu_hit_cnt += local_hit_cnt_vec[i];
    accu_hit_size += local_hit_size_vec[i];
    hit_cnt_vec[i] = accu_hit_cnt;
    hit_size_vec[i] = accu_hit_size;
  }
}

void mrcProfiler::MRCProfilerMINISIM::run() {
  has_run_ = true;

  request_t *req = new_request();
  double sample_rate = params_.minisim_params.sample_rate;
  double sampled_cnt = 0, sampled_size = 0;
  sampler_t *sampler = nullptr;
  if (sample_rate > 0.5) {
    INFO("sample_rate is too large, do not sample\n");
    /* the whole trace is replayed, so the miniature caches have to be
     * full-sized; leaving the requested rate in place would scale them down
     * while every request still reached them, reporting the miss ratios of
     * smaller caches than were asked for */
    sample_rate = 1.0;
  } else {
    sampler = create_spatial_sampler(sample_rate);
    set_spatial_sampler_salt(sampler,
                             10000019);  // TODO: salt can be changed by params

    /* the sampler keeps one object in sampling_ratio_inv, an integer, so it can
     * only represent rates of the form 1/n: create_spatial_sampler truncates
     * 1/0.3 to 3 and then keeps a third. Sizing the caches by the rate that was
     * asked for rather than the one in force makes them too small by that
     * ratio -- 10% at 0.3 -- and the curve is reported against the size that
     * was asked for, so the error is invisible in the output. Take the rate the
     * sampler actually applies. */
    double effective_rate = 1.0 / sampler->sampling_ratio_inv;
    if (effective_rate != sample_rate) {
      INFO("sample rate %.6f is not of the form 1/n, using %.6f\n", sample_rate,
           effective_rate);
      sample_rate = effective_rate;
    }
  }

  // 1. obtain the n_req_, sum_obj_size_req, sampled_cnt and sampled_size
  read_one_req(reader_, req);
  do {
    DEBUG_ASSERT(req->obj_size != 0);
    n_req_ += 1;
    sum_obj_size_req += req->obj_size;
    if (sampler == nullptr || sampler->sample(sampler, req)) {
      sampled_cnt += 1;
      sampled_size += req->obj_size;
    }

    read_one_req(reader_, req);
  } while (req->valid);
  // 2. set spatial sampling to the reader
  reset_reader(reader_);
  reader_->init_params.sampler = sampler;
  reader_->sampler = sampler;

  /* Belady and BeladySize read next_access_vtime, which ordinary readers leave
   * at -2, so on any other trace they would produce a plausible-looking but
   * meaningless curve rather than failing. cachesim checks this before building
   * the cache; do the same here. */
  if (strcasecmp(params_.cache_algorithm_str, "belady") == 0 ||
      strcasecmp(params_.cache_algorithm_str, "beladySize") == 0) {
    if (!reader_has_next_access_vtime(reader_)) {
      ERROR(
          "%s needs future information, which %s traces do not carry; use an "
          "oracle format such as oracleGeneral or lcs, or convert with "
          "./bin/traceConv\n",
          params_.cache_algorithm_str, g_trace_type_name[reader_->trace_type]);
    }
  }

  /* BeladySize picks its victim by drawing samples from the hash table, so an
   * oversized table costs memory and leaves the sampler probing empty buckets.
   * cachesim shrinks it by 8 before constructing the cache, landing on 16;
   * the miniature caches are built straight from the registry and would
   * otherwise keep a 1M-slot table each, so the floor below puts them on 16
   * too. Hyperbolic gets the same treatment for a different reason:
   * Hyperbolic_init shrinks its own table as well, so cachesim ends up two
   * reductions down, and starting from the same 16 is what makes an unsampled
   * hyperbolic run reproduce cachesim to four decimals rather than land beside
   * it. */
  /* The table stays small even when sampling is off and MINISIM replays the
   * whole trace, rather than growing to the hashpower cachesim would use.
   * MINISIM builds one cache per profile point and holds them all at once, so
   * the table is paid for once per point: at the default --size=0.01,1,100
   * that is 100 of them, and cachesim's 24 would be 128MiB each. Measured on
   * cloudPhysicsIO, that peaks at 12.8GiB and was OOM-killed on one run;
   * hashpower 20 peaks at 0.8GiB and finishes 27x faster. --size accepts up to
   * MAX_MRC_PROFILE_POINTS points, so the ceiling is higher still.
   *
   * What the smaller table costs: policies that draw eviction candidates
   * through the hash mask can land slightly off a cachesim run at the same
   * size. Measured at 100MB on cloudPhysicsIO.oracleGeneral, five runs each,
   * the only reproducible gap is randomTwo -- 0.8215 here against cachesim's
   * 0.8220. lru, fifo, arc, s3fifo, sieve, twoq, lfu, clock, gdsf, hyperbolic
   * and randomLRU agree to four decimals. random and lecar disagree by a
   * comparable amount, but they seed from the clock and move between runs on
   * both sides, so no table size makes those two match. Closing randomTwo's
   * gap would need simulate_with_multi_caches to build each cache when a
   * thread picks it up instead of all of them up front -- a change to the
   * simulator, not to this profiler. */
  int minisim_hashpower = kMiniSimHashPower;
  if (strcasecmp(params_.cache_algorithm_str, "hyperbolic") == 0) {
    minisim_hashpower = MAX(minisim_hashpower - 8, 16);
  }
  if (strcasecmp(params_.cache_algorithm_str, "beladySize") == 0) {
    minisim_hashpower = MAX(minisim_hashpower - 8, 16);

    /* BeladySize scores a candidate with next_access_vtime - cache->n_req.
     * next_access_vtime counts requests in the full trace, but once the
     * sampler drops requests, n_req counts only the ones that survived, so the
     * two are in different units and the reuse distance comes out inflated.
     * Belady is unaffected because it uses next_access_vtime as an ordering
     * and never takes a difference. Measured on cloudPhysicsIO at a 100MB
     * cache: at sample rate 0.5 BeladySize is off by 0.0126 against the
     * unsampled miss ratio, where Belady is off by 0.0003 and LRU by 0.0023.
     * Warn rather than refuse -- the curve is still in the right region, and
     * remapping future times into sampled virtual time is a change to the
     * sampler that belongs to the maintainers, not a silent correction here. */
    if (sampler != nullptr) {
      WARN(
          "beladySize scores candidates by reuse distance, which spatial "
          "sampling distorts because next_access_vtime stays in full-trace "
          "request numbers; the curve is approximate beyond the usual sampling "
          "error. Use --profiler-params=FIX_RATE,1,<threads> for an exact "
          "run, or belady, which is not affected.\n");
    }
  }

  // 3. run the simulate_with_multi_caches
  cache_t *caches[MAX_MRC_PROFILE_POINTS];
  for (size_t i = 0; i < params_.profile_size.size(); i++) {
    size_t _cache_size = mrc_size_vec[i] * sample_rate;
    /* step 1 above already counted the trace, so hand the count on rather
     * than leaving an algorithm with a fraction-of-the-trace parameter to
     * fall back to a fixed default. It is sampled_cnt and not n_req_
     * because spatial sampling drops requests before they reach the cache,
     * so sampled_cnt is what cache->n_req will actually climb to. */
    common_cache_params_t cc_params = {
        .cache_size = _cache_size,
        .default_ttl = 0,
        .hashpower = minisim_hashpower,
        .consider_obj_metadata = false,
        .n_total_req = static_cast<int64_t>(sampled_cnt)};
    caches[i] = create_cache_using_plugin(params_.cache_algorithm_str,
                                          cc_params, nullptr);
  }
  result = simulate_with_multi_caches(
      reader_, caches, mrc_size_vec.size(), NULL, 0, 0,
      params_.minisim_params.thread_num, true, true);

  // 4. adjust hit cnt and hit size
  for (size_t i = 0; i < mrc_size_vec.size(); i++) {
    if (sampler) {
      hit_cnt_vec[i] =
          n_req_ - result[i].n_miss * reader_->sampler->sampling_ratio_inv;
      hit_size_vec[i] =
          sum_obj_size_req -
          result[i].n_miss_byte * reader_->sampler->sampling_ratio_inv;
    } else {
      hit_cnt_vec[i] = n_req_ - result[i].n_miss;
      hit_size_vec[i] = sum_obj_size_req - result[i].n_miss_byte;
    }
  }
  // clean up
  my_free(sizeof(cache_stat_t) * mrc_size_vec.size(), result);
  free_request(req);
}
