//
//  cachesim_glue.c — what cachesim's hint providers and admission policies
//  (cachesim/: unmodified copies of cachesim src/, see re-DESIGN.md §2) need
//  from the rest of cachesim: the registry of these two plugin kinds, and the
//  hint log (hint_events.csv etc.), which RegionFlash does not write; and the
//  adapter that runs the hint providers behind RegionFlash's interface.
//  A new plugin: copy its file into cachesim/, add it to CMakeLists.txt and
//  one line here.
//

#include "regionflash_hint.h"

extern const admission_ops_t adm_all_ops, adm_prob_ops, adm_sizemax_ops,
    adm_sizeexp_ops, adm_seen_ops, adm_adaptsize_ops, adm_cachesack_ops,
    adm_oracle_opt_ops, adm_tinylfu_ops;
extern const hint_ops_t hint_none_ops, hint_fixed_ops, hint_profile_ops,
    hint_split_threshold_ops, hint_st_recursive_ops, hint_st_hr_refine_ops,
    hint_hr_segment_ops, hint_st_hitrate_ops, hint_oracle_gdt_ops,
    hint_key_ops, hint_oracle_key_ops, hint_oracle_keyinfo_ops;

const admission_ops_t *ADMISSIONS[] = {
    &adm_all_ops,       &adm_prob_ops,      &adm_sizemax_ops,
    &adm_sizeexp_ops,   &adm_seen_ops,      &adm_adaptsize_ops,
    &adm_cachesack_ops, &adm_oracle_opt_ops, &adm_tinylfu_ops, NULL};
const hint_ops_t *HINTS[] = {
    &hint_none_ops,         &hint_fixed_ops,        &hint_profile_ops,
    &hint_split_threshold_ops, &hint_st_recursive_ops, &hint_st_hr_refine_ops,
    &hint_hr_segment_ops,   &hint_st_hitrate_ops,   &hint_oracle_gdt_ops,
    &hint_key_ops,          &hint_oracle_key_ops,   &hint_oracle_keyinfo_ops,
    NULL};

void hint_log_event(hint_log_t *lg, uint64_t t, uint64_t obs, uint32_t epoch,
                    int changed, const int64_t *taus, uint32_t ntau,
                    const uint8_t *map, const int64_t st[6], double sse_cur,
                    double sse_new, const char *note) {}
void hint_log_hr(hint_log_t *lg, uint64_t seq, uint64_t t, int bucket,
                 double lookups, double hits, double rate, int valid,
                 int hr_class, int cls) {}
void hint_log_attach_stats(hint_log_t *lg, const struct hint_stats *hs,
                           int stat, int weight, double min_obs,
                           double eps_log) {}

/* cachesim's hint providers behind RegionFlash's interface (regionflash_hint.h):
 * on_insert = on_admit, on_find with a hit = on_ssd_hit, on_evict =
 * on_ssd_evict, on_get = on_request then on_access. Sizes saturate at
 * UINT32_MAX (cachesim's are uint32_t) */
struct rf_hint {
  const hint_ops_t *o;
  hint_t *h;
};

static uint32_t u32(uint64_t s) { return s > UINT32_MAX ? UINT32_MAX : (uint32_t)s; }

static void cs_destroy(rf_hint_t *x) {
  x->o->destroy(x->h);
  free(x);
}
static void cs_get(rf_hint_t *x, const rf_hint_ev_t *e) {
  if (x->o->on_request) x->o->on_request(x->h, e->t, u32(e->size), e->outcome);
  if (x->o->on_access) x->o->on_access(x->h, e->t, e->id, u32(e->size), e->outcome);
}
static void cs_find(rf_hint_t *x, const rf_hint_ev_t *e) {
  if (e->outcome == HINT_SSD_HIT) x->o->on_ssd_hit(x->h, e->t, u32(e->size), e->cls);
}
static uint32_t cs_insert(rf_hint_t *x, const rf_hint_ev_t *e) {
  hint_admit_t a = {e->t, e->id, u32(e->size), e->source, e->dram_hits, e->next_dist};
  return x->o->on_admit(x->h, &a);
}
static void cs_evict(rf_hint_t *x, const rf_hint_ev_t *e) {
  x->o->on_ssd_evict(x->h, e->t, u32(e->size), e->cls, e->freq, e->residence);
}
static uint32_t cs_epoch(const rf_hint_t *x) { return x->o->epoch(x->h); }
static uint32_t cs_bounds(const rf_hint_t *x, int64_t *tau, uint32_t max) {
  return x->o->bounds(x->h, tau, max);
}
static uint32_t cs_classes(const rf_hint_t *x, uint8_t *cls, uint32_t max) {
  return x->o->classes ? x->o->classes(x->h, cls, max) : 0;
}
static uint32_t cs_max_classes(const rf_hint_t *x) { return x->o->max_classes(x->h); }
static void cs_report(rf_hint_t *x, FILE *f) {
  if (x->o->report) x->o->report(x->h, f); else fputs("null", f);
}

const rf_hint_ops_t rf_hint_cachesim_ops = {
    "cachesim", NULL,     NULL,    cs_destroy, cs_get,         cs_find,  cs_insert,
    cs_evict,   cs_epoch, cs_bounds, cs_classes, cs_max_classes, cs_report};

rf_hint_t *rf_hint_cachesim(const hint_ops_t *o, const param_vals_t *v,
                            const hint_env_t *env) {
  rf_hint_t *x = xcalloc(1, sizeof(*x));
  x->o = o;
  if (o->create(&x->h, v, env) != 0) {
    free(x);
    return NULL;
  }
  return x;
}
