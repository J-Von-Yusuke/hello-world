//
//  regionflash_stats.h — what RegionFlash measures per object-size bin, for
//  hint providers that compare the recent past with the whole run.
//
//  Size bins are powers of two up to uint32's limit: bin 0 holds sizes <= 1,
//  bin b (1..32) holds (2^(b-1), 2^b], and bin 32 ends at 2^32 - 1 (larger
//  sizes count in bin 32 too). The upper end is inclusive, as in the hint's
//  "class = |{ tau : size > tau }|" rule, so a power-of-two bound never cuts a
//  bin. The size is the whole object's, also when it is written piece-wise.
//
//  Three views of the same counters:
//    cum  - since the warm-up ended (what the final report counts)
//    cur  - the interval in progress (from the last interval boundary)
//    last - the last completed interval (zeros before the first one ends)
//  An interval is `interval=N` requests (0: one interval for the whole run).
//
//  A hint provider calls regionflash_size_view() inside its callbacks
//  (on_get, on_insert, ...; regionflash_hint.h): it answers for the
//  RegionFlash running in this thread. Outside RegionFlash, use
//  regionflash_size_view_of(cache).
//

#ifndef REGIONFLASH_STATS_H
#define REGIONFLASH_STATS_H

#include <math.h>
#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

struct cache;

#define RF_SB_N 33

#define RF_SB_CTRS(X)                                                    \
  X(reqs) X(req_bytes) X(misses) X(miss_bytes) X(dram_hits)              \
  X(dram_hit_bytes) X(ssd_lookups) X(ssd_lookup_bytes) X(ssd_hits)       \
  X(ssd_hit_bytes) X(ssd_admit_objs) X(ssd_admit_bytes)

typedef struct {
#define X(n) uint64_t n;
  RF_SB_CTRS(X)
#undef X
} rf_sb_ctr_t;

typedef struct {
  uint64_t t;           // requests so far
  uint64_t interval;    // interval length in requests, 0: none
  uint64_t n_interval;  // completed intervals
  bool measuring;       // the warm-up is over
  const rf_sb_ctr_t *cum, *cur, *last;  // [RF_SB_N] each
} rf_size_view_t;

/* the bin of an object size, and its bounds (lo, hi] */
static inline uint32_t rf_size_bin(uint64_t s) {
  if (s <= 1) return 0;
  uint32_t b = 64 - (uint32_t)__builtin_clzll(s - 1);  // ceil(log2(s))
  return b > RF_SB_N - 1 ? RF_SB_N - 1 : b;
}
static inline uint64_t rf_size_bin_hi(uint32_t b) {
  return b >= RF_SB_N - 1 ? UINT32_MAX : (uint64_t)1 << b;
}
static inline uint64_t rf_size_bin_lo(uint32_t b) {  // exclusive
  return b == 0 ? 0 : rf_size_bin_hi(b - 1);
}

/* object miss ratio, byte miss ratio; NAN without requests */
static inline double rf_sb_omr(const rf_sb_ctr_t *c) {
  return c->reqs ? (double)c->misses / (double)c->reqs : NAN;
}
static inline double rf_sb_bmr(const rf_sb_ctr_t *c) {
  return c->req_bytes ? (double)c->miss_bytes / (double)c->req_bytes : NAN;
}

/* true and *v filled when called inside RegionFlash's get() (hint callbacks) */
bool regionflash_size_view(rf_size_view_t *v);
/* the same for a given RegionFlash cache; false if it is not one */
bool regionflash_size_view_of(const struct cache *cache, rf_size_view_t *v);

#ifdef __cplusplus
}
#endif

#endif /* REGIONFLASH_STATS_H */
