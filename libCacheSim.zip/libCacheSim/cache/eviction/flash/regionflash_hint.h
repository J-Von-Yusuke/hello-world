//
//  regionflash_hint.h — RegionFlash's hint interface: a hint provider sees
//  the cache's operations and gives each SSD write its class (write stream,
//  RUH = class mod ruh).
//
//  One callback per cache operation. Within a request they come in this
//  order (an operation the request does not make is skipped):
//
//    on_find    the SSD lookup of a request DRAM missed: hit or miss
//    on_insert  each SSD write the request causes (a DRAM victim, a miss
//               without DRAM, a reinsertion): returns the object's class
//    on_evict   each object the request's writes push out of the SSD (not
//               invalidations, not reinsertions); interleaved with on_insert
//    on_get     the request itself, once it is served, with its outcome
//
//  on_get and on_find count requests; on_insert and on_evict count objects.
//  Sizes are always the whole object's, also when it is written piece-wise.
//
//  cachesim's hint providers (cachesim/plugin.h, unmodified) run behind this
//  interface (cachesim_glue.c): on_admit = on_insert, on_ssd_evict =
//  on_evict, on_ssd_hit = on_find with a hit, on_request and on_access =
//  on_get. A new provider is written against this file (hint/ has examples)
//  and listed in RF_HINTS (RegionFlash.c); regionflash_stats.h lets it
//  compare the interval in progress with the whole run.
//

#ifndef REGIONFLASH_HINT_H
#define REGIONFLASH_HINT_H

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wpedantic"  // unsigned __int128 in rng.h
#include "cachesim/plugin.h"
#pragma GCC diagnostic pop

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
  uint64_t t;          // request number, from 0 (the warm-up included)
  uint64_t id, size;   // the object; size in bytes
  uint32_t cls;        // its class: the one it was written with; never
                       // written, the class its size maps to (as P.class.csv)
  uint8_t outcome;     // on_get: HINT_MISS | HINT_DRAM_HIT | HINT_SSD_HIT;
                       // on_find: HINT_MISS | HINT_SSD_HIT
  uint8_t source;      // on_insert: SRC_DRAM_EVICT | SRC_MISS | SRC_REINSERT
  uint8_t dram_hits;   // on_insert: DRAM hits since it entered DRAM
  uint32_t freq;       // on_evict: SSD hits since it was written, + 1
  uint64_t residence;  // on_evict: requests since it was written
  int64_t next_dist;   // on_insert, oracle: requests until its next access,
                       // -1: none, -2: unknown
} rf_hint_ev_t;

typedef struct rf_hint rf_hint_t;  // each provider defines struct rf_hint

typedef struct {
  const char *name;
  const param_spec_t *params;  // hint=NAME:k=v/k=v (cachesim/params.h)
  int (*create)(rf_hint_t **h, const param_vals_t *v, const hint_env_t *env);
  void (*destroy)(rf_hint_t *h);
  /* cache operations; NULL if not used, except on_insert */
  void (*on_get)(rf_hint_t *h, const rf_hint_ev_t *e);
  void (*on_find)(rf_hint_t *h, const rf_hint_ev_t *e);
  uint32_t (*on_insert)(rf_hint_t *h, const rf_hint_ev_t *e);  // < max_classes
  void (*on_evict)(rf_hint_t *h, const rf_hint_ev_t *e);
  /* the partition: size intervals (tau_{i-1}, tau_i] and their classes,
   * read again when epoch() changed after on_insert or on_get */
  uint32_t (*epoch)(const rf_hint_t *h);
  uint32_t (*bounds)(const rf_hint_t *h, int64_t *tau_out, uint32_t max);
  uint32_t (*classes)(const rf_hint_t *h, uint8_t *cls_out, uint32_t max);
  // classes: NULL or 0 returned: interval i -> class i
  uint32_t (*max_classes)(const rf_hint_t *h);
  void (*report)(rf_hint_t *h, FILE *f);  // one JSON value: P.json hint_result
} rf_hint_ops_t;

/* cachesim_glue.c: a cachesim provider behind this interface */
extern const rf_hint_ops_t rf_hint_cachesim_ops;
rf_hint_t *rf_hint_cachesim(const hint_ops_t *o, const param_vals_t *v,
                            const hint_env_t *env);

#ifdef __cplusplus
}
#endif

#endif /* REGIONFLASH_HINT_H */
