/* hint_hitrate.c — st_hitrate: split_threshold の改良版（サイズ分類 × サイズ帯別ヒット率）。
 *
 * サイズ分類 sc（size=st: split_threshold の τ / size=fixed: tau リスト / size=none: 1 分類）と、
 * 2 のべき乗のサイズ帯（log2 バケット b、48 本）ごとに測ったヒット率の分類 hc[b]（hr リストで区切る）から
 *   セル = sc × (hr の分類数) + hc[b]
 * を作り、merge 規則で写したものを分類番号として返す。分類番号はセル番号そのもの（セルの意味は時刻によらず固定）。
 *
 * ヒット率（hr_metric）: ssd = SSD 参照（DRAM ミス）のうちの SSD ヒット率 / all = 全要求のヒット率（DRAM を含む）。
 * 集計（hr_mode）: hr_window 要求ごとに更新し、cum = 開始からの累積、window = 直前の hr_window 要求、
 *   ema = 区間ごとの参照数とヒット数の指数移動平均の比（A ← (1−α)A + α·区間値）。
 * 参照数（cum は累積、window / ema は 1 区間あたり）が hr_min_obs 未満のバケットは hr_default の分類。
 * hc[b] = |{ j : rate_b ≥ hr_j }|（境界ちょうどは上の分類）。hr_hyst = m > 0 なら、前回も有効だったバケットは
 *   rate が [hr_{c−1} − m, hr_c + m) にある間は前回の分類 c のまま（境界付近の行き来を抑えるヒステリシス）。
 *
 * merge=hot: サイズ分類 c ≥ 1 のうちヒット率分類 ≥ merge_level のセルを、まとめ先 d（smallest = 0 / next = c−1）の
 *   同じヒット率分類のセルへ写す。d にそのセルがなければ（今どのサイズも当てはまらなければ）、d で使われている
 *   最も高いヒット率分類のセルへ写す。d が丸ごと空なら写さない。 */
#include "../plugin.h"
#include "st_wrap.h"
#include "hint_stats.h"

#define MAXHR 16
#define MAXSZ 64
enum { SZ_ST, SZ_FIXED, SZ_NONE };
enum { HR_CUM, HR_WINDOW, HR_EMA };

struct hint {
    int size_src, metric_all, mode, def_high, merge, merge_next;
    stw_t w; int64_t st_last[6];
    int64_t ftau[MAXSZ]; uint32_t nf;
    double hrb[MAXHR]; uint32_t nhr, merge_level;
    uint64_t period, nreq, nupd; double alpha, min_obs, hyst;
    double cl[HS_NB], ch[HS_NB], al[HS_NB], ah[HS_NB], rate[HS_NB], look[HS_NB], hit[HS_NB];
    uint8_t valid[HS_NB], hc[HS_NB];
    uint32_t nsz_max;
    int64_t stau[MAXSZ]; uint32_t ns;
    uint8_t tgt[MAXSZ * MAXHR];
    int64_t iv[HINT_MAX_IV]; uint8_t ivc[HINT_MAX_IV + 1]; uint32_t niv, ep;
    hint_log_t *log;
};

static const param_spec_t P[] = {
    {"size", P_ENUM, "st", "st|fixed|none", "サイズ分類: split_threshold / tau リスト / なし"},
    {"tau", P_LIST, "", NULL, "size=fixed の境界（例 1024,2048,10000）"},
    {"hr", P_LIST, "20%,40%,60%,80%", NULL, "ヒット率の境界（昇順、0〜100%。空なら 1 分類）"},
    {"hr_metric", P_ENUM, "ssd", "ssd|all", "ssd: SSD 参照のうちの SSD ヒット率 / all: 全要求のヒット率"},
    {"hr_mode", P_ENUM, "ema", "cum|window|ema", "累積 / 直前の区間 / 指数移動平均"},
    {"hr_window", P_UINT, "100000", NULL, "ヒット率の更新間隔（要求数）"},
    {"hr_alpha", P_DOUBLE, "0.3", NULL, "ema: 新しい区間の重み（0 < α ≤ 1）"},
    {"hr_min_obs", P_DOUBLE, "100", NULL, "参照数がこれ未満のバケットはヒット率なし"},
    {"hr_default", P_ENUM, "low", "low|high", "ヒット率なしのバケットの分類（最低 / 最高）"},
    {"hr_hyst", P_DOUBLE, "0", NULL, "ヒット率分類のヒステリシス幅（例 5%。0 = 無効）"},
    {"merge", P_ENUM, "none", "none|hot", "高ヒット率の大サイズ分類を小サイズ分類へまとめる"},
    {"merge_level", P_INT, "-1", NULL, "まとめるヒット率分類の下限（-1 = 最上位だけ）"},
    {"merge_to", P_ENUM, "smallest", "smallest|next", "まとめ先: 最小のサイズ分類 / 1 つ小さいサイズ分類"},
    ST_PARAM_SPECS, {NULL}};

static int i64cmp(const void *a, const void *b) { int64_t x = *(const int64_t *)a, y = *(const int64_t *)b; return (x > y) - (x < y); }

static uint32_t size_class(const hint_t *h, int64_t s) { uint32_t c = 0; while (c < h->ns && s > h->stau[c]) c++; return c; }
static uint32_t cell_of(const hint_t *h, int64_t s) { return size_class(h, s) * h->nhr + h->hc[hs_bucket(s < 1 ? 1 : (uint64_t)s)]; }

/* 現在のサイズ分類・ヒット率分類・merge から、区間（bounds）と区間ごとの分類を作り直す */
static void rebuild(hint_t *h, uint64_t t, uint64_t obs, const char *note) {
    h->ns = 0;
    if (h->size_src == SZ_ST && h->w.thr >= 0) h->stau[h->ns++] = h->w.thr - (int64_t)h->w.add;
    if (h->size_src == SZ_FIXED) { memcpy(h->stau, h->ftau, h->nf * sizeof(int64_t)); h->ns = h->nf; }
    /* 分類が変わりうる点: サイズ分類の τ と、バケットの境目 2^b − 1（s > 2^b − 1 ⇔ s ≥ 2^b） */
    int64_t bp[MAXSZ + HS_NB]; uint32_t n = 0;
    for (uint32_t i = 0; i < h->ns; i++) bp[n++] = h->stau[i];
    for (int b = 1; b < HS_NB; b++) bp[n++] = ((int64_t)1 << b) - 1;
    qsort(bp, n, sizeof(int64_t), i64cmp);
    uint32_t m = 0;
    for (uint32_t i = 0; i < n; i++) if (!m || bp[i] != bp[m - 1]) bp[m++] = bp[i];
    n = m;
    /* 区間 i = (bp[i−1], bp[i]]。代表点で（merge 前の）セルを求め、使われているセルを記録する */
    uint32_t cell[MAXSZ + HS_NB + 1]; uint8_t pop[MAXSZ * MAXHR] = {0};
    for (uint32_t i = 0; i <= n; i++) {
        int64_t rep = i == 0 ? (bp[0] >= 1 ? 1 : bp[0]) : bp[i - 1] + 1;
        cell[i] = cell_of(h, rep); pop[cell[i]] = 1;
    }
    uint32_t ncell = h->nsz_max * h->nhr;
    for (uint32_t c = 0; c < ncell; c++) h->tgt[c] = (uint8_t)c;
    if (h->merge)
        for (uint32_t c = 1; c <= h->ns; c++)
            for (uint32_t r = h->merge_level; r < h->nhr; r++) {
                uint32_t me = c * h->nhr + r, d = h->merge_next ? c - 1 : 0;
                if (!pop[me]) continue;
                if (pop[d * h->nhr + r]) { h->tgt[me] = h->tgt[d * h->nhr + r]; continue; }
                for (int rr = (int)h->nhr - 1; rr >= 0; rr--)          /* d で使われている最も高いヒット率分類 */
                    if (pop[d * h->nhr + (uint32_t)rr]) { h->tgt[me] = h->tgt[d * h->nhr + (uint32_t)rr]; break; }
            }
    /* 写した分類が同じ隣接区間はつなぐ */
    int64_t iv[HINT_MAX_IV]; uint8_t ivc[HINT_MAX_IV + 1]; uint32_t niv = 0;
    ivc[0] = h->tgt[cell[0]];
    for (uint32_t i = 1; i <= n; i++) {
        uint8_t c = h->tgt[cell[i]];
        if (c == ivc[niv]) continue;
        iv[niv++] = bp[i - 1]; ivc[niv] = c;
    }
    int changed = niv != h->niv || memcmp(iv, h->iv, niv * sizeof(int64_t)) || memcmp(ivc, h->ivc, niv + 1);
    if (changed) { h->ep++; h->niv = niv; memcpy(h->iv, iv, niv * sizeof(int64_t)); memcpy(h->ivc, ivc, niv + 1); }
    hint_log_event(h->log, t, obs, h->ep, changed, h->iv, h->niv, h->ivc, h->st_last, NAN, NAN, note);
}

static int create(hint_t **hp, const param_vals_t *v, const hint_env_t *env) {
    hint_t *h = xcalloc(1, sizeof(*h));
    const char *sz = pv_str(v, "size");
    h->size_src = !strcmp(sz, "st") ? SZ_ST : !strcmp(sz, "fixed") ? SZ_FIXED : SZ_NONE;
    stw_init(&h->w, v);
    double a[MAXSZ];
    h->nf = (uint32_t)pv_list(v, "tau", a, MAXSZ - 1);
    if (h->size_src != SZ_FIXED && h->nf) die("st_hitrate: tau= is only used with size=fixed");
    for (uint32_t i = 0; i < h->nf; i++) {
        h->ftau[i] = (int64_t)a[i];
        if (i && h->ftau[i] <= h->ftau[i - 1]) die("st_hitrate: tau must be strictly increasing");
    }
    h->nsz_max = h->size_src == SZ_ST ? 2 : h->size_src == SZ_FIXED ? h->nf + 1 : 1;
    uint32_t nb = (uint32_t)pv_list(v, "hr", h->hrb, MAXHR - 1);
    for (uint32_t i = 0; i < nb; i++)
        if (h->hrb[i] < 0 || h->hrb[i] > 1 || (i && h->hrb[i] <= h->hrb[i - 1]))
            die("st_hitrate: hr must be strictly increasing values in [0, 1] (e.g. hr=20%%,40%%,60%%,80%%)");
    h->nhr = nb + 1;
    if (h->nsz_max * h->nhr > env->k_max)
        die("st_hitrate: %u size classes x %u hit-rate classes = %u > k_max %u", h->nsz_max, h->nhr, h->nsz_max * h->nhr, env->k_max);
    h->metric_all = !strcmp(pv_str(v, "hr_metric"), "all");
    const char *md = pv_str(v, "hr_mode");
    h->mode = !strcmp(md, "cum") ? HR_CUM : !strcmp(md, "window") ? HR_WINDOW : HR_EMA;
    h->period = (uint64_t)pv_int(v, "hr_window"); h->alpha = pv_dbl(v, "hr_alpha"); h->min_obs = pv_dbl(v, "hr_min_obs");
    h->hyst = pv_dbl(v, "hr_hyst");
    if (h->hyst < 0 || h->hyst >= 1) die("st_hitrate: hr_hyst must be in [0, 1)");
    if (!h->period) die("st_hitrate: hr_window must be > 0");
    if (!(h->alpha > 0 && h->alpha <= 1)) die("st_hitrate: hr_alpha must be in (0, 1]");
    h->def_high = !strcmp(pv_str(v, "hr_default"), "high");
    h->merge = !strcmp(pv_str(v, "merge"), "hot");
    h->merge_next = !strcmp(pv_str(v, "merge_to"), "next");
    int64_t ml = pv_int(v, "merge_level");
    h->merge_level = ml < 0 ? h->nhr - 1 : (uint32_t)ml;
    if (h->merge_level >= h->nhr) die("st_hitrate: merge_level must be < number of hit-rate classes (%u)", h->nhr);
    for (int b = 0; b < HS_NB; b++) { h->hc[b] = (uint8_t)(h->def_high ? h->nhr - 1 : 0); h->rate[b] = NAN; }
    for (int i = 0; i < 6; i++) h->st_last[i] = -1;
    h->log = env->log;
    rebuild(h, 0, 0, "init");
    *hp = h;
    return 0;
}
static void destroy(hint_t *h) { free(h); }

static void update_hr(hint_t *h, uint64_t t) {
    for (int b = 0; b < HS_NB; b++) {
        double L, H;
        if (h->mode == HR_CUM) { h->al[b] += h->cl[b]; h->ah[b] += h->ch[b]; L = h->al[b]; H = h->ah[b]; }
        else if (h->mode == HR_WINDOW) { L = h->cl[b]; H = h->ch[b]; }
        else {
            if (!h->nupd) { h->al[b] = h->cl[b]; h->ah[b] = h->ch[b]; }
            else { h->al[b] = (1 - h->alpha) * h->al[b] + h->alpha * h->cl[b]; h->ah[b] = (1 - h->alpha) * h->ah[b] + h->alpha * h->ch[b]; }
            L = h->al[b]; H = h->ah[b];
        }
        h->look[b] = L; h->hit[b] = H;
        int was = h->valid[b]; uint32_t old = h->hc[b];
        h->valid[b] = L > 0 && L >= h->min_obs;
        h->rate[b] = h->valid[b] ? H / L : NAN;
        uint32_t c = 0;
        if (h->valid[b]) while (c < h->nhr - 1 && h->rate[b] >= h->hrb[c]) c++;
        else c = h->def_high ? h->nhr - 1 : 0;
        if (h->hyst > 0 && was && h->valid[b] && c != old                      /* 前回の分類の帯（幅を広げたもの）の中なら据え置く */
            && (old == 0 || h->rate[b] >= h->hrb[old - 1] - h->hyst) && (old == h->nhr - 1 || h->rate[b] < h->hrb[old] + h->hyst)) c = old;
        h->hc[b] = (uint8_t)c;
        h->cl[b] = h->ch[b] = 0;
    }
    h->nupd++;
    rebuild(h, t, h->nreq, "hr");
    for (int b = 0; b < HS_NB; b++)
        if (h->look[b] > 0)
            hint_log_hr(h->log, h->nupd, t, b, h->look[b], h->hit[b], h->rate[b], h->valid[b], h->hc[b],
                        h->tgt[cell_of(h, b ? (int64_t)1 << b : 1)]);
}

static uint32_t on_admit(hint_t *h, const hint_admit_t *a) {
    if (h->size_src == SZ_ST) {
        int64_t st[6];
        if (stw_admit(&h->w, (uint64_t)a->size + h->w.add, st)) { memcpy(h->st_last, st, sizeof st); rebuild(h, a->t, h->w.s.n_obs, "st"); }
    }
    return h->tgt[cell_of(h, a->size)];
}
static void on_request(hint_t *h, uint64_t t, uint32_t size, int outcome) {
    int b = hs_bucket(size);
    if (h->metric_all) { h->cl[b] += 1; h->ch[b] += outcome != HINT_MISS; }
    else if (outcome != HINT_DRAM_HIT) { h->cl[b] += 1; h->ch[b] += outcome == HINT_SSD_HIT; }
    if (++h->nreq % h->period == 0) update_hr(h, t);
}
static void on_hit(hint_t *h, uint64_t t, uint32_t s, uint32_t c) { (void)h; (void)t; (void)s; (void)c; }
static void on_evict(hint_t *h, uint64_t t, uint32_t s, uint32_t c, uint32_t freq, uint64_t r) {
    (void)t; (void)c; (void)r;
    if (h->size_src == SZ_ST) sst_on_evict(&h->w.s, (uint64_t)s + h->w.add, freq);
}
static uint32_t epoch(const hint_t *h) { return h->ep; }
static uint32_t maxc(const hint_t *h) { return h->nsz_max * h->nhr; }
static uint32_t bounds(const hint_t *h, int64_t *out, uint32_t max) {
    uint32_t n = h->niv < max ? h->niv : max;
    memcpy(out, h->iv, n * sizeof(int64_t));
    return n;
}
static uint32_t classes(const hint_t *h, uint8_t *out, uint32_t max) {
    uint32_t n = h->niv + 1 < max ? h->niv + 1 : max;
    memcpy(out, h->ivc, n);
    return n;
}

const hint_ops_t hint_st_hitrate_ops = {"st_hitrate", P, create, destroy, on_admit, on_hit, on_evict, epoch, bounds,
                                        maxc, classes, on_request, NULL, NULL};
