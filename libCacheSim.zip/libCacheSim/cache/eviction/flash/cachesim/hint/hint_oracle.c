/* hint_oracle.c — oracle_gdt（§9.10）: 配置だけで達成できる性能の参照点（SIZE_SEPARATION_THEORY P13）。
 * 受け入れ時に、次のアクセスまでの距離 d（元のトレースの要求数。hint_admit_t.next_dist）で分類する。
 * metric=bytetime では d × サイズ（次のヒットまでに占める「バイト × 時間」。ヒット密度の逆数）で分類する。
 *   次のアクセスがないもの → 最後の分類 k−1（one-hit wonder・用済みのバイトの溜まり場）
 *   あるもの → log2(d) のバケットを、受け入れバイトの重みで k−1 等分した分類 0..k−2（d が短いほど小さい番号）
 * 等分の境界は recalc 回の受け入れごとに作り直し、ヒストグラムは split_threshold と同じ整数減衰で忘れる。
 * 分類はサイズの区間ではないので bounds は 0 個（要求の分類別集計は分類 0 にまとまる）。エポックは変えない。 */
#include "../plugin.h"

#define NB 64
struct hint { uint32_t k; int bt; uint64_t recalc, den, n; uint64_t hb[NB]; int cut[KMAX_LIMIT]; };
static const param_spec_t P[] = {
    {"k", P_UINT, "4", NULL, "分類数（2 以上。最後の 1 つは次のアクセスなし）"},
    {"metric", P_ENUM, "dist", "dist|bytetime", "分ける量: 次のアクセスまでの距離 / 距離 × サイズ"},
    {"recalc", P_UINT, "100000", NULL, "境界の再計算の間隔（受け入れ数）"},
    {"ema_den", P_UINT, "16", NULL, "減衰 v ← v×(ema_den−1)/ema_den"}, {NULL}};

static int create(hint_t **hp, const param_vals_t *v, const hint_env_t *env) {
    hint_t *h = xcalloc(1, sizeof(*h));
    h->k = (uint32_t)pv_int(v, "k"); h->bt = !strcmp(pv_str(v, "metric"), "bytetime"); h->recalc = (uint64_t)pv_int(v, "recalc"); h->den = (uint64_t)pv_int(v, "ema_den");
    if (h->k < 2 || h->k > env->k_max) die("oracle_gdt: k must be in [2, k_max = %u]", env->k_max);
    if (!h->recalc || h->den < 1) die("oracle_gdt: recalc must be > 0 and ema_den >= 1");
    for (uint32_t j = 0; j + 1 < h->k; j++) h->cut[j] = NB;     /* 境界なし: 次のアクセスがあれば分類 0 */
    *hp = h;
    return 0;
}
static void destroy(hint_t *h) { free(h); }

/* バケット b 以下の累積バイトが全体の (j+1)/(k−1) に達する最小の b を、分類 j の上端にする */
static void recompute(hint_t *h) {
    uint64_t tot = 0, cum = 0;
    for (int b = 0; b < NB; b++) tot += h->hb[b];
    if (!tot) return;
    uint32_t m = h->k - 1, j = 0;
    for (int b = 0; b < NB && j + 1 < m; b++) {
        cum += h->hb[b];
        while (j + 1 < m && cum * m >= tot * (j + 1)) h->cut[j++] = b;
    }
    while (j + 1 < m) h->cut[j++] = NB;
    for (int b = 0; b < NB; b++) h->hb[b] = h->hb[b] * (h->den - 1) / h->den;
}

static uint32_t on_admit(hint_t *h, const hint_admit_t *a) {
    if (a->next_dist == -2) die("oracle_gdt needs next-access information in the trace (oracleGeneral or a next-access column)");
    if (a->next_dist == -1) return h->k - 1;
    uint64_t key = (uint64_t)(a->next_dist > 0 ? a->next_dist : 1) * (h->bt ? (uint64_t)(a->size ? a->size : 1) : 1);
    int b = ilog2_u64(key);
    h->hb[b] += a->size;
    if (++h->n % h->recalc == 0) recompute(h);
    uint32_t c = 0;
    while (c + 2 < h->k && b > h->cut[c]) c++;
    return c;
}
static void on_hit(hint_t *h, uint64_t t, uint32_t s, uint32_t c) { (void)h; (void)t; (void)s; (void)c; }
static void on_evict(hint_t *h, uint64_t t, uint32_t s, uint32_t c, uint32_t f, uint64_t r) { (void)h; (void)t; (void)s; (void)c; (void)f; (void)r; }
static uint32_t epoch(const hint_t *h) { (void)h; return 0; }
static uint32_t maxc(const hint_t *h) { return h->k; }
static uint32_t bounds(const hint_t *h, int64_t *out, uint32_t max) { (void)h; (void)out; (void)max; return 0; }

const hint_ops_t hint_oracle_gdt_ops = {"oracle_gdt", P, create, destroy, on_admit, on_hit, on_evict, epoch, bounds, maxc, NULL, NULL, NULL, NULL};
