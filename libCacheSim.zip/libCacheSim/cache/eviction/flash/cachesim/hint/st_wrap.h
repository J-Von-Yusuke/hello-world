/* st_wrap.h — 研究者の split_threshold.h を改変せずに包む共通部（§9.4）。
 * recalc と ema_den が C 版の既定値（SST_RECALC_OBS, SST_EMA_DEN）なら sst_tick をそのまま呼ぶ。
 * 既定値以外のときだけ、sst_tick と同じ手順（n_obs 加算 → 倍数なら sst_recompute → 整数減衰）を引数で行う。
 * ヒステリシス（§9.4、v0.2.5）: C 版が出した閾値（候補）を、採用中の閾値 thr にすぐには反映しない。
 *   hyst_band: 採用中の値から hyst_band オクターブ未満しか動かない候補は無視する（不感帯）。
 *   hyst_hold: 同じ向き（上げる / 下げる / 無分割にする / 分割を始める）の候補が hyst_hold 回続けて出たら、最新の候補を採用する。
 *   既定（hold = 1、band = 0）では候補をそのまま採用し、従来と完全に一致する。 */
#ifndef ST_WRAP_H
#define ST_WRAP_H
#include "st_range.h"
#include "../params.h"

#define ST_PARAM_SPECS \
    {"lambda", P_INT, "0", NULL, "λ×256（0 = mid（既定）, 256 = min_rule = C 版の既定）"}, \
    {"min_band", P_INT, "2", NULL, "狭帯ゲート（オクターブ）"}, \
    {"no_split_pct", P_INT, "5", NULL, "大 pool ゲート（%）"}, \
    {"recalc", P_UINT, "100000", NULL, "再計算の間隔（受け入れ数）"}, \
    {"ema_den", P_UINT, "16", NULL, "減衰 v ← v×(ema_den−1)/ema_den"}, \
    {"size_add", P_UINT, "0", NULL, "各オブジェクトに足すバイト（Navy の serializedSize 近似）"}, \
    {"hyst_hold", P_UINT, "1", NULL, "ヒステリシス: 同じ向きの候補がこの回数続いたら採用（1 = 即時）"}, \
    {"hyst_band", P_UINT, "0", NULL, "ヒステリシス: 採用中の閾値からこのオクターブ未満の変化は無視（0 = 無効）"}

typedef struct {
    split_thresh_t s; uint64_t recalc, ema_den, add;
    int64_t thr;                        /* 採用中の閾値（< 0 は無分割）。分類にはこちらを使う */
    uint32_t hold, band, pend_n; int pend_dir, started;   /* started: 最初の再計算の候補はすぐ採用する（「まだ情報がない」は無分割の判断ではない） */
} stw_t;

static inline void stw_init(stw_t *w, const param_vals_t *v) {
    sst_init(&w->s, (int)pv_int(v, "lambda"));
    w->s.min_band_oct = (int)pv_int(v, "min_band");
    w->s.nosplit_pct = (int)pv_int(v, "no_split_pct");
    w->recalc = (uint64_t)pv_int(v, "recalc"); w->ema_den = (uint64_t)pv_int(v, "ema_den");
    w->add = (uint64_t)pv_int(v, "size_add");
    w->thr = -1; w->hold = (uint32_t)pv_int(v, "hyst_hold"); w->band = (uint32_t)pv_int(v, "hyst_band");
    w->pend_n = 0; w->pend_dir = 0; w->started = 0;
    if (!w->recalc || w->ema_den < 1) die("split_threshold: recalc must be > 0 and ema_den >= 1");
    if (!w->hold) die("split_threshold: hyst_hold must be >= 1");
}
/* 再計算のたびに、候補 s.threshold を採用するかを決める */
static inline void stw_hyst(stw_t *w) {
    int64_t c = w->s.threshold, a = w->thr;
    int dir;
    if (!w->started) { w->started = 1; w->thr = c; return; }
    if (c == a) { w->pend_n = 0; return; }
    if (c >= 0 && a >= 0) {
        int d = ilog2_u64((uint64_t)c) - ilog2_u64((uint64_t)a);
        if ((uint32_t)(d < 0 ? -d : d) < w->band) { w->pend_n = 0; return; }   /* 不感帯 */
        dir = d > 0 ? 1 : 2;
    } else dir = c < 0 ? 3 : 4;                                               /* 無分割へ / 分割を始める */
    w->pend_n = dir == w->pend_dir ? w->pend_n + 1 : 1;
    w->pend_dir = dir;
    if (w->pend_n >= w->hold) { w->thr = c; w->pend_n = 0; }
}
/* onAdmit(s)（＝ sst_on_admit ＋ tick）。再計算したら 1 を返し、st[6] に再計算時の候補値を入れる */
static inline int stw_admit(stw_t *w, uint64_t sz, int64_t st[6]) {
    int will = (w->s.n_obs + 1) % w->recalc == 0;
    sst_on_admit(&w->s, sz);
    if (will) {                     /* 再計算が見るのと同じ（減衰前の）ヒストグラムで候補値を取る */
        sst_candidates_t c; sst_get_candidates(&w->s, &c);
        st[1] = c.count_p50; st[2] = c.byte_p50; st[3] = c.cold_byte_p50; st[4] = c.mid; st[5] = c.min_rule;
    }
    if (w->recalc == SST_RECALC_OBS && w->ema_den == SST_EMA_DEN) sst_tick(&w->s);
    else if (++w->s.n_obs % w->recalc == 0) {
        sst_recompute(&w->s);
        for (int b = 0; b < SST_NBUCKET; b++) {
            w->s.count[b]      = w->s.count[b]      * (w->ema_den - 1) / w->ema_den;
            w->s.all_bytes[b]  = w->s.all_bytes[b]  * (w->ema_den - 1) / w->ema_den;
            w->s.cold_bytes[b] = w->s.cold_bytes[b] * (w->ema_den - 1) / w->ema_den;
        }
    }
    if (will) { st[0] = w->s.threshold; stw_hyst(w); }
    return will;
}
#endif
