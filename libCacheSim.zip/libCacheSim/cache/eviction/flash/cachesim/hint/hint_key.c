/* hint_key.c — 配置の鍵の比較（§9.11、v0.2.6）。
 * key: 書き込み時に分かる鍵 X で分類する。X は hash（id のハッシュ。無作為な分割の対照）・size（log2 サイズ）・
 *   dram（DRAM でのヒット数）・gap（直前 2 回の要求の間隔）・age（最後の要求からの経過時間）・freq（これまでの要求回数）。
 *   hash 以外は log2 のバケットにし、受け入れの重み（weight=bytes ならバイト、count なら回数）で k 等分した境界で分ける
 *   （oracle_gdt と同じ規則。鍵どうしで境界の作り方をそろえ、鍵の情報だけを比べる）。履歴のない物は最後のバケット。
 *   q=f1,f2,… を与えると等分の代わりに累積の重みの割合 f で切る（分位点）。thr=v1,v2,… を与えると鍵の生の値
 *   （size: バイト、dram: DRAM ヒット数 + 1、freq: 要求回数、gap・age: 要求数）を固定の閾値で切る（fixed と同じく区間 (v_{i−1}, v_i]。v を超えると上の分類。k = 閾値の数 + 1）。
 *   sizefreq はサイズと要求回数を別々に同じ規則で k ÷ kf 個・kf 個に分け、その組（サイズの分類 × kf + 回数の分類）を分類にする
 *   （回数側は fthr・fq。与えればそれで kf が決まる）。
 *   gap・age は全要求を on_access で見て、物ごとの直前 2 回の時刻と回数を幽霊表に持つ（サイズが変われば捨てる）。
 *   回数は fsrc で取り方を選ぶ: ghost（幽霊表の正確な回数）・dram（DRAM 段での参照回数 = DRAM ヒット数 + 1。追加の記憶なし）・
 *   cms（4 行 8 ビットの Count-Min スケッチ、fmem バイト。fwin 要求ごとに半減）・bloom（2 つの Bloom フィルタ A・B、各 fmem/2 バイト。
 *   A にあれば B に入れ、なければ A に入れる。B にあれば 2 回以上 = 回数 2、なければ 1。fwin 要求ごとに両方を消す）。
 * oracle_key: 未来の情報で分ける（E2）。dist（次のアクセスまでの距離）・rate（受け入れから W 要求のあいだの参照回数）・
 *   dens（rate ÷ サイズ）・live（もう一度参照されるか）・wlive（W のあいだに参照されるか）。境界の規則は key と同じ。
 *   rate・dens・wlive は 2 パス: 1 パス目（log=PATH）で全要求の (id, サイズ) の混ぜ値の列を書き、2 パス目（events=PATH）で
 *   物ごとの次の参照の添字の鎖を作り、受け入れの時刻 t と次のアクセスまでの距離 d から t + d を起点に鎖をたどって数える。
 *   起点の混ぜ値が受け入れた物と一致しなかった数を report の mismatch に書く（0 であること）。
 * oracle_keyinfo: 分類はしない（常に 0）。受け入れのたびに、各鍵 X と将来の値 Y（次のアクセスまでの距離 d、
 *   または d × サイズ）の同時度数を数え、相互情報量 I(X; Y)、H(Y)、窓ごとの I のばらつき、k 個の連続した区間に
 *   まとめたときに保てる割合 I_k / I（最適な区切りを動的計画で求める）を report に書く。未来の情報を使うので oracle_。
 *   events と W を与えると、率 λ̂ = W のあいだの参照回数（L = log2(回数 + 1)）と正規化した位相 φ = d × (回数 + 1) ÷ W
 *   （64 倍して log2 のバケット。次のアクセスなしは別のバケット）を作り、I(X; L) と I(X; φ | L) = I(X; L, φ) − I(X; L) を書く。
 * 分類はサイズの区間ではないので bounds は 0 個、エポックは変えない（oracle_gdt と同じ）。 */
#include "../plugin.h"
#include "../hashmap.h"

#define NB 64                                         /* X のバケット */
#define NY 65                                         /* Y のバケット（最後 = 次のアクセスなし） */
#define NL 16                                         /* 率のバケット */
#define NP 64                                         /* 位相のバケット（最後 = 次のアクセスなし） */
#define CAP 4096                                      /* 窓の参照回数の上限（鎖をたどる長さ） */
enum { X_HASH, X_SIZE, X_DRAM, X_GAP, X_AGE, X_FREQ, NX, X_SF = NX };          /* X_SF は key だけ（oracle_keyinfo は測らない） */
enum { O_DIST = 16, O_RATE, O_DENS, O_LIVE, O_WLIVE };
enum { F_GHOST, F_DRAM, F_CMS, F_BLOOM };
static const char *XN[NX] = {"hash", "size", "dram", "gap", "age", "freq"};
static const char *ON[] = {"dist", "rate", "dens", "live", "wlive"};
typedef struct { uint64_t id, last, prev; uint32_t cnt, size; } gh_t;
struct hint {
    int info, key, wbytes; uint32_t k; uint64_t recalc, den, n, window, nw;
    double hb[NB], hb2[NB]; int cut[KMAX_LIMIT], cut2[KMAX_LIMIT]; uint32_t kf;  /* key: 重みと境界（2 は sizefreq の回数側） */
    double thr[KMAX_LIMIT], fthr[KMAX_LIMIT], q[KMAX_LIMIT], fq[KMAX_LIMIT]; int nthr, nfthr, nq, nfq;
    hmap_t g; gh_t *gh; uint64_t gn, gcap; int ghost;
    int fsrc; uint8_t *sk; uint64_t skw, fwin, nacc;  /* 近似の回数（cms: 4 × skw、bloom: 2 × skw バイト） */
    FILE *log; uint64_t *ev; uint32_t *nxt; uint64_t nev, W, mismatch, walks;   /* oracle の 2 パス */
    double *jt, *jw, *jr;                             /* info: 度数 [2][NX][NY][NB]（全体・今の窓）、[NX][NL][NP][NB] */
    double wsum[2][NX], wsq[2][NX]; uint64_t nwin;
};
#define JIX(y, x, yy, xx) ((((size_t)(y) * NX + (x)) * NY + (yy)) * NB + (xx))
#define RIX(x, l, p, b) ((((size_t)(x) * NL + (l)) * NP + (p)) * NB + (b))

static const param_spec_t P_KEY[] = {
    {"key", P_ENUM, "size", "hash|size|dram|gap|age|freq|sizefreq", "分ける鍵"},
    {"k", P_UINT, "4", NULL, "分類数（2 以上。thr を与えれば閾値の数 + 1）"},
    {"kf", P_UINT, "2", NULL, "sizefreq: 回数の分類数（k を割り切ること。fthr・fq を与えればその数 + 1）"},
    {"weight", P_ENUM, "bytes", "bytes|count", "境界を等分する重み"},
    {"recalc", P_UINT, "100000", NULL, "境界の再計算の間隔（受け入れ数）"},
    {"ema_den", P_UINT, "16", NULL, "減衰 v ← v×(ema_den−1)/ema_den"},
    {"fsrc", P_ENUM, "ghost", "ghost|dram|cms|bloom", "freq・sizefreq: 回数の取り方"},
    {"fmem", P_BYTES, "16M", NULL, "fsrc=cms・bloom の記憶量"},
    {"fwin", P_UINT, "10000000", NULL, "fsrc=cms: 半減 / bloom: 消去の間隔（要求数）"},
    {"q", P_LIST, "", NULL, "累積の重みの割合で切る（昇順。例 30%）"},
    {"fq", P_LIST, "", NULL, "sizefreq の回数側の q"},
    {"thr", P_LIST, "", NULL, "鍵の生の値の固定の閾値（昇順。K/M/G 可）"},
    {"fthr", P_LIST, "", NULL, "sizefreq の回数側の thr"}, {NULL}};
static const param_spec_t P_OKEY[] = {
    {"key", P_ENUM, "rate", "dist|rate|dens|live|wlive", "分ける将来の値"},
    {"k", P_UINT, "4", NULL, "分類数（live・wlive は 2）"},
    {"weight", P_ENUM, "bytes", "bytes|count", "境界を等分する重み"},
    {"recalc", P_UINT, "100000", NULL, "境界の再計算の間隔（受け入れ数）"},
    {"ema_den", P_UINT, "16", NULL, "減衰 v ← v×(ema_den−1)/ema_den"},
    {"W", P_UINT, "0", NULL, "rate・dens・wlive の窓（要求数）"},
    {"log", P_STRING, "", NULL, "1 パス目: 全要求の列を書くファイル（分類は常に 0）"},
    {"events", P_STRING, "", NULL, "2 パス目: 1 パス目のファイル"},
    {"q", P_LIST, "", NULL, "累積の重みの割合で切る（昇順）"}, {NULL}};
static const param_spec_t P_INFO[] = {
    {"window", P_UINT, "1000000", NULL, "I のばらつきを測る窓（受け入れ数）"},
    {"W", P_UINT, "0", NULL, "率の窓（要求数。events と併せて使う）"},
    {"events", P_STRING, "", NULL, "oracle_key:log= で書いた全要求の列"}, {NULL}};
static const char MAGIC[8] = {'C', 'S', 'A', 'C', 'C', '0', '0', '1'};

static uint64_t evkey(uint64_t id, uint32_t size) { return splitmix64(id ^ ((uint64_t)size * 0x9E3779B97F4A7C15ULL)); }
/* 1 パス目の列を読み、物ごとに次の参照の添字（なし = UINT32_MAX）を作る */
static void load_events(hint_t *h, const char *path) {
    FILE *f = fopen(path, "rb");
    char mg[8];
    if (!f || fread(mg, 1, 8, f) != 8 || memcmp(mg, MAGIC, 8)) die("oracle_key: cannot read event log %s", path);
    if (fseek(f, 0, SEEK_END)) die("oracle_key: cannot seek %s", path);
    h->nev = ((uint64_t)ftell(f) - 8) / 8;
    if (h->nev >= UINT32_MAX) die("oracle_key: too many requests in %s", path);
    fseek(f, 8, SEEK_SET);
    h->ev = xmalloc(h->nev * 8 + 8); h->nxt = xmalloc(h->nev * 4 + 4);
    if (fread(h->ev, 8, h->nev, f) != h->nev) die("oracle_key: short read %s", path);
    fclose(f);
    hmap_t m; hm_init(&m, 1 << 20);
    for (uint64_t i = h->nev; i-- > 0;) {
        uint64_t *p = hm_get(&m, h->ev[i]);
        h->nxt[i] = p ? (uint32_t)*p : UINT32_MAX;
        hm_put(&m, h->ev[i], i);
    }
    hm_free(&m);
}
/* 受け入れの時刻 t から W 要求のあいだの参照回数（次のアクセスまでの距離 nd を起点にする） */
static uint64_t wcount(hint_t *h, const hint_admit_t *a) {
    if (a->next_dist < 0) return 0;
    uint64_t j = a->t + (uint64_t)a->next_dist, c = 0;
    if (j >= h->nev) return 0;
    if (h->ev[j] != evkey(a->id, a->size)) { h->mismatch++; return 0; }
    for (uint32_t i = (uint32_t)j; i != UINT32_MAX && i <= a->t + h->W && c < CAP; i = h->nxt[i]) c++;
    h->walks += c;
    return c;
}

static void set_list(const param_vals_t *v, const char *key, double *out, int *n) { *n = pv_list(v, key, out, KMAX_LIMIT - 1); }
static void common_create(hint_t *h, const param_vals_t *v) {
    h->k = (uint32_t)pv_int(v, "k"); h->wbytes = !strcmp(pv_str(v, "weight"), "bytes");
    h->recalc = (uint64_t)pv_int(v, "recalc"); h->den = (uint64_t)pv_int(v, "ema_den");
    set_list(v, "q", h->q, &h->nq);
    if (!h->recalc || h->den < 1) die("key: recalc must be > 0 and ema_den >= 1");
    for (uint32_t j = 0; j < KMAX_LIMIT; j++) h->cut[j] = h->cut2[j] = NB;
}
static int key_create(hint_t **hp, const param_vals_t *v, const hint_env_t *env) {
    hint_t *h = xcalloc(1, sizeof(*h));
    const char *k = pv_str(v, "key");
    if (!strcmp(k, "sizefreq")) h->key = X_SF; else for (h->key = 0; strcmp(XN[h->key], k); h->key++) {}
    common_create(h, v);
    h->kf = (uint32_t)pv_int(v, "kf");
    set_list(v, "thr", h->thr, &h->nthr); set_list(v, "fthr", h->fthr, &h->nfthr); set_list(v, "fq", h->fq, &h->nfq);
    if (h->nthr && h->nq) die("key: give thr or q, not both");
    if (h->key == X_SF) {
        uint32_t ks = h->nthr ? (uint32_t)h->nthr + 1 : h->nq ? (uint32_t)h->nq + 1 : h->k / (h->kf ? h->kf : 1);
        if (h->nfthr || h->nfq) h->kf = (uint32_t)(h->nfthr ? h->nfthr : h->nfq) + 1;
        if (h->nthr || h->nq) h->k = ks * h->kf;
        if (h->kf < 2 || h->k % h->kf || h->k / h->kf < 2) die("key: sizefreq needs kf >= 2, k divisible by kf and k / kf >= 2");
    } else if (h->nthr || h->nq) h->k = (uint32_t)(h->nthr ? h->nthr : h->nq) + 1;
    if (h->nthr && h->key == X_HASH) die("key: hash has no thresholds");
    if (h->k < 2 || h->k > env->k_max) die("key: k must be in [2, k_max = %u]", env->k_max);
    const char *fs = pv_str(v, "fsrc");
    h->fsrc = !strcmp(fs, "ghost") ? F_GHOST : !strcmp(fs, "dram") ? F_DRAM : !strcmp(fs, "cms") ? F_CMS : F_BLOOM;
    h->fwin = (uint64_t)pv_int(v, "fwin");
    int usesf = h->key == X_FREQ || h->key == X_SF;
    if (usesf && (h->fsrc == F_CMS || h->fsrc == F_BLOOM)) {
        uint64_t m = (uint64_t)pv_int(v, "fmem");
        h->skw = m / (h->fsrc == F_CMS ? 4 : 2);
        if (h->skw < 64 || !h->fwin) die("key: fmem must be >= 256 bytes and fwin > 0");
        if (h->fsrc == F_BLOOM) h->skw &= ~7ULL;
        h->sk = xcalloc(h->fsrc == F_CMS ? 4 : 2, h->skw);
    }
    h->ghost = h->key == X_GAP || h->key == X_AGE || (usesf && h->fsrc == F_GHOST);
    if (h->ghost) hm_init(&h->g, 1024);
    *hp = h;
    return 0;
}
static int okey_create(hint_t **hp, const param_vals_t *v, const hint_env_t *env) {
    hint_t *h = xcalloc(1, sizeof(*h));
    const char *k = pv_str(v, "key");
    for (h->key = 0; strcmp(ON[h->key], k); h->key++) {}
    h->key += O_DIST;
    common_create(h, v);
    if (h->nq) h->k = (uint32_t)h->nq + 1;
    if (h->key == O_LIVE || h->key == O_WLIVE) h->k = 2;
    h->W = (uint64_t)pv_int(v, "W");
    const char *lp = pv_str(v, "log"), *ep = pv_str(v, "events");
    int need = h->key == O_RATE || h->key == O_DENS || h->key == O_WLIVE;
    if (*lp) { h->log = fopen(lp, "wb"); if (!h->log || fwrite(MAGIC, 1, 8, h->log) != 8) die("oracle_key: cannot write %s", lp); h->k = 1; }
    else if (need) {
        if (!*ep || !h->W) die("oracle_key: key=%s needs events=PATH (from a log= run) and W > 0", k);
        load_events(h, ep);
    }
    if (!h->log && (h->k < 2 || h->k > env->k_max)) die("oracle_key: k must be in [2, k_max = %u]", env->k_max);
    *hp = h;
    return 0;
}
static int info_create(hint_t **hp, const param_vals_t *v, const hint_env_t *env) {
    (void)env;
    hint_t *h = xcalloc(1, sizeof(*h));
    h->info = 1; h->ghost = 1; h->window = (uint64_t)pv_int(v, "window"); h->W = (uint64_t)pv_int(v, "W");
    if (!h->window) die("oracle_keyinfo: window must be > 0");
    hm_init(&h->g, 1024);
    h->jt = xcalloc((size_t)2 * NX * NY * NB, 8); h->jw = xcalloc((size_t)2 * NX * NY * NB, 8);
    const char *ep = pv_str(v, "events");
    if (*ep) {
        if (!h->W) die("oracle_keyinfo: events needs W > 0");
        load_events(h, ep);
        h->jr = xcalloc((size_t)NX * NL * NP * NB, 8);
    }
    *hp = h;
    return 0;
}
static void destroy(hint_t *h) {
    if (h->ghost) hm_free(&h->g);
    if (h->log) fclose(h->log);
    free(h->gh); free(h->jt); free(h->jw); free(h->jr); free(h->sk); free(h->ev); free(h->nxt); free(h);
}

static uint64_t skh(uint64_t id, int r) { return splitmix64(id + 0x9E3779B97F4A7C15ULL * (uint64_t)(r + 1)); }
static int bl_has(const hint_t *h, int f, uint64_t id) {
    const uint8_t *b = h->sk + (size_t)f * h->skw;
    for (int r = 0; r < 3; r++) { uint64_t x = skh(id, r) % (h->skw * 8); if (!(b[x >> 3] >> (x & 7) & 1)) return 0; }
    return 1;
}
static void bl_put(hint_t *h, int f, uint64_t id) {
    uint8_t *b = h->sk + (size_t)f * h->skw;
    for (int r = 0; r < 3; r++) { uint64_t x = skh(id, r) % (h->skw * 8); b[x >> 3] |= (uint8_t)(1u << (x & 7)); }
}
static uint32_t cms_get(const hint_t *h, uint64_t id) {
    uint32_t m = 255;
    for (int r = 0; r < 4; r++) { uint8_t c = h->sk[(size_t)r * h->skw + skh(id, r) % h->skw]; if (c < m) m = c; }
    return m;
}
static void on_access(hint_t *h, uint64_t t, uint64_t id, uint32_t size, int outcome) {
    (void)outcome;
    if (h->log) { uint64_t e = evkey(id, size); if (fwrite(&e, 8, 1, h->log) != 1) die("oracle_key: write failed"); }
    if (h->sk) {
        if (h->fsrc == F_CMS) for (int r = 0; r < 4; r++) { uint8_t *c = &h->sk[(size_t)r * h->skw + skh(id, r) % h->skw]; if (*c < 255) (*c)++; }
        else bl_put(h, bl_has(h, 0, id) ? 1 : 0, id);
        if (++h->nacc % h->fwin == 0) {
            if (h->fsrc == F_CMS) for (uint64_t i = 0; i < 4 * h->skw; i++) h->sk[i] >>= 1;
            else memset(h->sk, 0, 2 * h->skw);
        }
    }
    if (!h->ghost) return;
    uint64_t *p = hm_get(&h->g, id);
    gh_t *x;
    if (p) x = &h->gh[*p];
    else { GROW(h->gh, h->gcap, h->gn + 1); x = &h->gh[h->gn]; *x = (gh_t){id, 0, 0, 0, size}; hm_put(&h->g, id, h->gn++); }
    if (x->size != size) { x->last = x->prev = 0; x->cnt = 0; x->size = size; }   /* サイズが変われば別の物 */
    x->prev = x->last; x->last = t + 1; x->cnt++;                                  /* 0 を「なし」に使う */
}
static int lg(uint64_t v) { int b = ilog2_u64(v ? v : 1); return b < NB - 1 ? b : NB - 2; }
static int vb(uint64_t v) { if (v == UINT64_MAX) return NB - 1; int b = v ? 1 + ilog2_u64(v) : 0; return b < NB - 1 ? b : NB - 2; }
static const gh_t *ghost_of(const hint_t *h, const hint_admit_t *a) {
    uint64_t *p = hm_get(&h->g, a->id);
    const gh_t *x = p ? &h->gh[*p] : NULL;
    return x && x->size == a->size && x->last ? x : NULL;
}
/* 回数（fsrc による）。0 = 履歴なし */
static uint64_t fval(const hint_t *h, const hint_admit_t *a) {
    if (h->fsrc == F_DRAM) return (uint64_t)a->dram_hits + 1;
    if (h->fsrc == F_CMS) return cms_get(h, a->id);
    if (h->fsrc == F_BLOOM) return bl_has(h, 1, a->id) ? 2 : 1;
    const gh_t *x = ghost_of(h, a);
    return x ? x->cnt : 0;
}
/* 鍵の生の値（thr と比べる）。履歴のない物は UINT64_MAX */
static uint64_t rawv(hint_t *h, int key, const hint_admit_t *a) {
    if (key == X_SIZE) return a->size;
    if (key == X_DRAM) return (uint64_t)a->dram_hits + 1;
    if (key == X_FREQ) { uint64_t f = fval(h, a); return f ? f : UINT64_MAX; }
    if (key >= O_DIST) {
        if (key == O_DIST) return a->next_dist < 0 ? UINT64_MAX : (uint64_t)a->next_dist;
        if (key == O_LIVE) return a->next_dist >= 0;
        uint64_t c = wcount(h, a);
        return key == O_RATE ? c : key == O_WLIVE ? c > 0 : (c << 40) / (a->size ? a->size : 1);
    }
    const gh_t *x = ghost_of(h, a);
    if (!x) return UINT64_MAX;
    return key == X_AGE ? a->t + 1 - x->last + 1 : x->prev ? x->last - x->prev + 1 : UINT64_MAX;
}
/* 鍵 X のバケット。履歴のない物は最後のバケット NB−1 */
static int xbucket(hint_t *h, int key, const hint_admit_t *a) {
    if (key == X_HASH) return (int)(splitmix64(a->id ^ 0x6b65796b6579ULL) >> 58);
    if (key == X_SIZE) return lg(a->size);
    if (key == X_DRAM) return lg((uint64_t)a->dram_hits + 1);
    if (key >= O_DIST) return vb(rawv(h, key, a));
    if (key == X_FREQ && h->fsrc != F_GHOST) return lg(fval(h, a));
    const gh_t *x = ghost_of(h, a);
    if (!x) return NB - 1;
    if (key == X_AGE) return lg(a->t + 1 - x->last + 1);
    if (key == X_FREQ) return lg(x->cnt);
    return x->prev ? lg(x->last - x->prev + 1) : NB - 1;                            /* X_GAP */
}

/* 重みの境界。累積の重みの割合が f[j]（q がなければ (j+1)/k の k 等分）に達したバケットで切る。ただし 1 つのバケットに
 * 重みが集まっても分類が潰れないよう、空でないバケットをどの分類にも 1 つ以上残す（空でないバケットが k 個未満なら、
 * その数の分類にする）。履歴のない物（最後のバケット）が多い鍵では、それが 1 つの分類になる */
static void cuts(double *hb, int *cut, uint32_t k, uint64_t den, const double *f, int nf) {
    int nb[NB], m = 0;
    double tot = 0, cum = 0;
    for (int b = 0; b < NB; b++) if (hb[b] > 0) { nb[m++] = b; tot += hb[b]; }
    if (!(tot > 0)) return;
    uint32_t j = 0;
    int prev = -1;
    for (int i = 0; i < m && j + 1 < k; i++) {
        cum += hb[nb[i]];
        int left = m - 1 - i;                                   /* この後に残る空でないバケット */
        while (j + 1 < k && i > prev && left >= (int)(k - 1 - j) &&
               ((nf ? cum >= tot * f[j] : cum * k >= tot * (j + 1)) || left == (int)(k - 1 - j))) {
            cut[j++] = nb[i]; prev = i;
        }
    }
    while (j + 1 < k) cut[j++] = NB;
    for (int b = 0; b < NB; b++) hb[b] = hb[b] * (double)(den - 1) / (double)den;
}
static void recompute(hint_t *h) {
    if (h->key != X_SF) { cuts(h->hb, h->cut, h->k, h->den, h->q, h->nq); return; }
    cuts(h->hb, h->cut, h->k / h->kf, h->den, h->q, h->nq); cuts(h->hb2, h->cut2, h->kf, h->den, h->fq, h->nfq);
}
static uint32_t cls_of(const int *cut, uint32_t k, int b) { uint32_t c = 0; while (c + 1 < k && b > cut[c]) c++; return c; }
static uint32_t cls_thr(const double *thr, int n, uint64_t v) { uint32_t c = 0; while ((int)c < n && (double)v > thr[c]) c++; return c; }

/* 度数 c[ny][NB]（行 = Y）から I(X; Y) と H(Y)（ビット） */
static double mi_g(const double *c, int ny, double *hy) {
    double n = 0, px[NB] = {0}, I = 0, H = 0;
    for (int y = 0; y < ny; y++) for (int x = 0; x < NB; x++) { px[x] += c[y * NB + x]; n += c[y * NB + x]; }
    if (!(n > 0)) { if (hy) *hy = 0; return 0; }
    for (int y = 0; y < ny; y++) {
        double py = 0;
        for (int x = 0; x < NB; x++) py += c[y * NB + x];
        if (!(py > 0)) continue;
        H -= py / n * log2(py / n);
        for (int x = 0; x < NB; x++) { double v = c[y * NB + x]; if (v > 0) I += v / n * log2(v * n / (px[x] * py)); }
    }
    if (hy) *hy = H;
    return I;
}
static double mi(const double *c, double *hy) { return mi_g(c, NY, hy); }
/* X のバケットを k 個の連続した区間にまとめたときの最大の I（動的計画。O(k · NB² · NY)） */
static double mi_k(const double *c, int k) {
    double n = 0, py[NY] = {0}, pre[NY][NB + 1];
    for (int y = 0; y < NY; y++) { pre[y][0] = 0; for (int x = 0; x < NB; x++) pre[y][x + 1] = pre[y][x] + c[y * NB + x]; py[y] = pre[y][NB]; n += py[y]; }
    if (!(n > 0)) return 0;
    double f[NB + 1][NB + 1], dp[KMAX_LIMIT + 1][NB + 1];
    for (int l = 0; l <= NB; l++) for (int r = l + 1; r <= NB; r++) {          /* 区間 [l, r) の寄与 */
        double ng = 0, s = 0;
        for (int y = 0; y < NY; y++) ng += pre[y][r] - pre[y][l];
        for (int y = 0; y < NY; y++) { double v = pre[y][r] - pre[y][l]; if (v > 0) s += v / n * log2(v * n / (ng * py[y])); }
        f[l][r] = s;
    }
    for (int r = 0; r <= NB; r++) dp[1][r] = r ? f[0][r] : 0;
    for (int j = 2; j <= k; j++)
        for (int r = 0; r <= NB; r++) {
            dp[j][r] = dp[j - 1][r];
            for (int l = 1; l < r; l++) if (dp[j - 1][l] + f[l][r] > dp[j][r]) dp[j][r] = dp[j - 1][l] + f[l][r];
        }
    return dp[k][NB];
}

static void end_window(hint_t *h) {
    for (int y = 0; y < 2; y++)
        for (int x = 0; x < NX; x++) {
            double I = mi(&h->jw[JIX(y, x, 0, 0)], NULL);
            h->wsum[y][x] += I; h->wsq[y][x] += I * I;
        }
    h->nwin++; memset(h->jw, 0, (size_t)2 * NX * NY * NB * 8); h->nw = 0;
}

static uint32_t on_admit(hint_t *h, const hint_admit_t *a) {
    if (h->info) {
        if (a->next_dist == -2) die("oracle_keyinfo needs next-access information in the trace (oracleGeneral or a next-access column)");
        uint64_t d = (uint64_t)(a->next_dist > 0 ? a->next_dist : 1);
        int y0 = a->next_dist == -1 ? NY - 1 : ilog2_u64(d), y1 = a->next_dist == -1 ? NY - 1 : ilog2_u64(d * (uint64_t)(a->size ? a->size : 1));
        if (y1 > NY - 2) y1 = NY - 2;
        int l = 0, p = 0;
        if (h->jr) {
            uint64_t c = wcount(h, a);
            l = ilog2_u64(c + 1);
            if (a->next_dist < 0) p = NP - 1;
            else { p = vb((uint64_t)a->next_dist * (c + 1) * 64 / h->W); if (p > NP - 2) p = NP - 2; }
        }
        for (int x = 0; x < NX; x++) {
            int b = xbucket(h, x, a);
            h->jt[JIX(0, x, y0, b)] += 1; h->jw[JIX(0, x, y0, b)] += 1;
            h->jt[JIX(1, x, y1, b)] += 1; h->jw[JIX(1, x, y1, b)] += 1;
            if (h->jr) h->jr[RIX(x, l, p, b)] += 1;
        }
        h->n++;
        if (++h->nw >= h->window) end_window(h);
        return 0;
    }
    if (h->log) return 0;
    if (h->key >= O_DIST && a->next_dist == -2) die("oracle_key needs next-access information in the trace");
    if (h->key == X_HASH) return (uint32_t)(splitmix64(a->id ^ 0x6b65796b6579ULL) % h->k);
    double w = h->wbytes ? (double)a->size : 1;
    if (h->key == X_SF) {
        uint32_t ks = h->k / h->kf, cs, cf;
        if (h->nthr) cs = cls_thr(h->thr, h->nthr, a->size);
        else { int bs = xbucket(h, X_SIZE, a); h->hb[bs] += w; cs = cls_of(h->cut, ks, bs); }
        if (h->nfthr) cf = cls_thr(h->fthr, h->nfthr, rawv(h, X_FREQ, a));
        else { int bf = xbucket(h, X_FREQ, a); h->hb2[bf] += w; cf = cls_of(h->cut2, h->kf, bf); }
        if (++h->n % h->recalc == 0) recompute(h);
        return cs * h->kf + cf;
    }
    if (h->nthr) return cls_thr(h->thr, h->nthr, rawv(h, h->key, a));
    int b = xbucket(h, h->key, a);
    h->hb[b] += w;
    if (++h->n % h->recalc == 0) recompute(h);
    return cls_of(h->cut, h->k, b);
}
static void on_hit(hint_t *h, uint64_t t, uint32_t s, uint32_t c) { (void)h; (void)t; (void)s; (void)c; }
static void on_evict(hint_t *h, uint64_t t, uint32_t s, uint32_t c, uint32_t f, uint64_t r) { (void)h; (void)t; (void)s; (void)c; (void)f; (void)r; }
static uint32_t epoch(const hint_t *h) { (void)h; return 0; }
static uint32_t maxc(const hint_t *h) { return h->info ? 1 : h->k; }
static uint32_t bounds(const hint_t *h, int64_t *out, uint32_t max) { (void)h; (void)out; (void)max; return 0; }

static void put_cuts(FILE *f, const char *name, const int *cut, uint32_t k) {
    fprintf(f, ", \"%s\": [", name);
    for (uint32_t j = 0; j + 1 < k; j++) fprintf(f, "%s%d", j ? ", " : "", cut[j]);
    fputs("]", f);
}
static void report(hint_t *h, FILE *f) {
    if (!h->info) {
        int sf = h->key == X_SF;
        uint32_t ks = sf ? h->k / h->kf : h->k;
        const char *kn = h->key >= O_DIST ? ON[h->key - O_DIST] : sf ? "sizefreq" : XN[h->key];
        fprintf(f, "{ \"name\": \"%s\", \"key\": \"%s\", \"k\": %u, \"ghost_objs\": %lu, \"sketch_bytes\": %lu",
                h->key >= O_DIST ? "oracle_key" : "key", kn, h->k, (unsigned long)h->gn,
                (unsigned long)(h->sk ? h->skw * (h->fsrc == F_CMS ? 4 : 2) : 0));
        if (h->key >= O_DIST) fprintf(f, ", \"events\": %lu, \"mismatch\": %lu, \"walk_steps\": %lu", (unsigned long)h->nev,
                                      (unsigned long)h->mismatch, (unsigned long)h->walks);
        put_cuts(f, "cut", h->cut, h->nthr ? 1 : ks);
        if (sf) put_cuts(f, "cut_freq", h->cut2, h->nfthr ? 1 : h->kf);
        fputs(" }", f);
        return;
    }
    if (h->nw) end_window(h);
    static const char *YN[2] = {"dist", "bytetime"};
    fprintf(f, "{ \"name\": \"oracle_keyinfo\", \"admissions\": %lu, \"windows\": %lu, \"ghost_objs\": %lu",
            (unsigned long)h->n, (unsigned long)h->nwin, (unsigned long)h->gn);
    for (int y = 0; y < 2; y++) {
        double H, I0 = mi(&h->jt[JIX(y, X_HASH, 0, 0)], &H);
        (void)I0;
        fprintf(f, ", \"%s\": { \"H\": %.6f", YN[y], H);
        for (int x = 0; x < NX; x++) {
            const double *c = &h->jt[JIX(y, x, 0, 0)];
            double I = mi(c, NULL), m = h->nwin ? h->wsum[y][x] / (double)h->nwin : 0;
            double sd = h->nwin > 1 ? sqrt(fmax(0, h->wsq[y][x] / (double)h->nwin - m * m)) : 0;
            fprintf(f, ", \"%s\": { \"I\": %.6f, \"I_over_H\": %.6f, \"win_mean\": %.6f, \"win_sd\": %.6f", XN[x], I, H > 0 ? I / H : 0, m, sd);
            if (x != X_HASH) fprintf(f, ", \"I2_over_I\": %.6f, \"I4_over_I\": %.6f", I > 0 ? mi_k(c, 2) / I : 0, I > 0 ? mi_k(c, 4) / I : 0);
            fputs(" }", f);
        }
        fputs(" }", f);
    }
    if (h->jr) {                                      /* 率 L と位相 φ への分解 */
        static double cl[NL * NB];
        fprintf(f, ", \"rate_phase\": { \"W\": %lu, \"mismatch\": %lu", (unsigned long)h->W, (unsigned long)h->mismatch);
        for (int x = 0; x < NX; x++) {
            const double *c = &h->jr[RIX(x, 0, 0, 0)];
            memset(cl, 0, sizeof cl);
            for (int l = 0; l < NL; l++) for (int p = 0; p < NP; p++) for (int b = 0; b < NB; b++) cl[l * NB + b] += c[((size_t)l * NP + p) * NB + b];
            double HL, HLP, IL = mi_g(cl, NL, &HL), ILP = mi_g(c, NL * NP, &HLP);
            fprintf(f, ", \"%s\": { \"I_L\": %.6f, \"I_LP\": %.6f, \"I_P_given_L\": %.6f, \"H_L\": %.6f, \"H_LP\": %.6f }", XN[x], IL, ILP, ILP - IL, HL, HLP);
        }
        fputs(" }", f);
    }
    fputs(" }", f);
}

const hint_ops_t hint_key_ops = {"key", P_KEY, key_create, destroy, on_admit, on_hit, on_evict, epoch, bounds, maxc, NULL, NULL, on_access, report};
const hint_ops_t hint_oracle_key_ops = {"oracle_key", P_OKEY, okey_create, destroy, on_admit, on_hit, on_evict, epoch, bounds, maxc,
                                        NULL, NULL, on_access, report};
const hint_ops_t hint_oracle_keyinfo_ops = {"oracle_keyinfo", P_INFO, info_create, destroy, on_admit, on_hit, on_evict, epoch, bounds, maxc,
                                            NULL, NULL, on_access, report};
