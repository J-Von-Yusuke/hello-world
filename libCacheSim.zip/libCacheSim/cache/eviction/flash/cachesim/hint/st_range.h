/* st_range.h — SplitThreshold の規則を「バケット範囲 [l, r] 内のヒストグラムだけ」で評価する（§9.7）。
 * 研究者の split_threshold.h は改変せず、その構造体を読み取り専用で使う。
 * l = 0, r = 47 のとき sst_recompute と同じ sB を返す（狭帯ゲート・λ 補間・大 pool ゲートを同じ式で）。 */
#ifndef ST_RANGE_H
#define ST_RANGE_H
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wmisleading-indentation"
#include "split_threshold.h"
#pragma GCC diagnostic pop

static inline int st_p50_range(const uint64_t *h, int l, int r) {
    uint64_t tot = 0, cum = 0;
    for (int b = l; b <= r; b++) tot += h[b];
    if (tot == 0) return -1;
    for (int b = l; b <= r; b++) { cum += h[b]; if (cum * 2 >= tot) return b; }
    return r;
}

/* 範囲内での分割バケット sB（τ = 2^sB）。無分割なら -1 */
static inline int st_range_rule(const split_thresh_t *s, int l, int r) {
    if (l > r) return -1;
    int cb = st_p50_range(s->count, l, r), bb = st_p50_range(s->all_bytes, l, r);
    if (cb < 0 || bb < 0 || bb - cb < s->min_band_oct) return -1;
    int mid_b = (cb + bb + 1) / 2, kb = st_p50_range(s->cold_bytes, l, r), min_b = bb;
    if (kb >= 0 && kb < bb) min_b = kb;
    int S_b = mid_b + ((min_b - mid_b) * s->lambda_x256 + 128) / 256;   /* C の 0 方向切り捨て（§9.4 3.） */
    if (S_b < 0) S_b = 0;
    if (S_b >= SST_NBUCKET) S_b = SST_NBUCKET - 1;
    uint64_t tot = 0, large = 0;
    for (int b = l; b <= r; b++) { tot += s->all_bytes[b]; if (b > S_b) large += s->all_bytes[b]; }
    if (tot == 0 || large * 100 < tot * (uint64_t)s->nosplit_pct) return -1;
    return S_b;
}

/* 最上位の閾値 thr（sst の threshold。< 0 は無分割）から、幅優先で再帰分割した τ（2^sB の形）を返す。
 * 小側の範囲 = [l, sB−1]、大側 = [sB, r]（poolOf の「s > 2^sB」に合わせ、バケット sB は大側に数える）。
 * 分類数は 2^depth と kmax の小さい方まで。戻り値 = τ の個数（昇順に並べて返す）。 */
static inline int st_split_taus(const split_thresh_t *s, int64_t thr, int depth, int kmax, int64_t *taus) {
    if (thr < 0 || kmax < 2 || depth < 1) return 0;
    int n = 0, ql[128], qr[128], qd[128], qh = 0, qt = 0;
    int sb = ilog2_u64((uint64_t)thr);
    taus[n++] = thr;
    ql[qt] = 0; qr[qt] = sb - 1; qd[qt++] = 1;
    ql[qt] = sb; qr[qt] = SST_NBUCKET - 1; qd[qt++] = 1;
    while (qh < qt && n + 1 < kmax) {
        int l = ql[qh], r = qr[qh], d = qd[qh++];
        if (d >= depth) continue;
        int b = st_range_rule(s, l, r);
        if (b < 0) continue;
        int dup = 0;                                    /* b = l（大側の下端）だと既存の τ と重なる */
        for (int i = 0; i < n; i++) dup |= taus[i] == ((int64_t)1 << b);
        if (dup) continue;
        taus[n++] = (int64_t)1 << b;
        if (qt + 2 <= 128) { ql[qt] = l; qr[qt] = b - 1; qd[qt++] = d + 1; ql[qt] = b; qr[qt] = r; qd[qt++] = d + 1; }
    }
    for (int i = 1; i < n; i++)                         /* 挿入ソート（n ≤ 64） */
        for (int j = i; j > 0 && taus[j - 1] > taus[j]; j--) { int64_t x = taus[j]; taus[j] = taus[j - 1]; taus[j - 1] = x; }
    return n;
}
#endif
