/* segment.h — 重み付き 1 次元最適分割（§9.6）。B ≤ 48 なので O(B² j) の素直な動的計画法 */
#ifndef SEGMENT_H
#define SEGMENT_H
#include "hint_stats.h"

typedef struct {
    int l, r, jmax;
    double sse[HS_NB + 1];                 /* sse[j]（j = 1..jmax、実現不能なら INFINITY） */
    int start[HS_NB + 1][HS_NB + 1];       /* start[j][i] = j 区間分割の i 番目の区間の先頭バケット */
} seg_t;

/* 無効バケットは w = 0 で渡す（区間の連続性だけ保つ） */
void   seg_run(const double *x, const double *w, int l, int r, int jmax, double min_share, seg_t *o);
int    seg_elbow(const seg_t *o, double eps);            /* 肘の規則で選んだ区間数 */
double seg_sse_cuts(const double *x, const double *w, int l, int r, const int *cuts, int ncut);
#endif
