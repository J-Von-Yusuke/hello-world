/* hint_refine.c — st_hr_refine（提案）と hr_segment（比較）（§9.7）。
 * st_hr_refine: split_threshold の粗い境界 τ_ST を残し、小 pool（バケット < sB）と大 pool（≥ sB）の
 *               それぞれをバケット別 SSD ヒット統計の最適分割（§9.6）で細分する。
 * hr_segment  : τ_ST を使わず、全範囲を同じ最適分割で分ける。
 * 安定化: 新しい細分は「現在の細分を同じ統計で評価した SSE × (1 − hyst)」以下に下がり、かつ直前の変更から
 *         dwell 回以上の再計算が経っているときだけ採用。τ_ST が変わったときは無条件に作り直す。 */
#include "../plugin.h"
#include "st_wrap.h"
#include "hint_stats.h"
#include "segment.h"

struct hint {
    int use_st, stat, weight, dwell, nosplit_refine;
    stw_t w; hint_stats_t hs;
    double min_obs, min_share, eps, hyst, eps_log;
    uint32_t kmax, n, ep; uint64_t recalc, ema_den, obs, nrec; int64_t last_change, st_thr;
    int cuts[HS_NB], ncut;                 /* 細分の切れ目（区間の先頭バケット。τ = 2^b − 1） */
    int64_t taus[KMAX_LIMIT]; hint_log_t *log;
};
#define SEG_PARAM_SPECS(KDEF) \
    {"k_max", P_UINT, KDEF, NULL, "分類数の上限（--k-max 以下）"}, \
    {"stat", P_ENUM, "hd", "hd|reuse|useful", "分割に使う派生統計"}, \
    {"weight", P_ENUM, "bytes", "bytes|count", "重み"}, \
    {"min_obs", P_DOUBLE, "200", NULL, "admit_n・evict_n がこれ未満のバケットは無効"}, \
    {"min_share", P_DOUBLE, "0.02", NULL, "各区間の重みの下限（範囲全体比）"}, \
    {"eps", P_DOUBLE, "0.05", NULL, "肘の規則の閾値"}, \
    {"hyst", P_DOUBLE, "0.05", NULL, "採用に必要な SSE の相対改善"}, \
    {"dwell", P_UINT, "2", NULL, "変更間に挟む再計算回数"}, \
    {"eps_log", P_DOUBLE, "1e-12", NULL, "log(stat + eps_log)"}
static const param_spec_t P_REF[] = {SEG_PARAM_SPECS("4"),
    {"refine_when_nosplit", P_ENUM, "no", "no|yes", "split_threshold が無分割のときも細分するか"}, ST_PARAM_SPECS, {NULL}};
static const param_spec_t P_SEG[] = {SEG_PARAM_SPECS("4"),
    {"recalc", P_UINT, "100000", NULL, "再計算の間隔（受け入れ数）"},
    {"ema_den", P_UINT, "16", NULL, "減衰 (ema_den−1)/ema_den"}, {NULL}};

static int mk(hint_t **h, const param_vals_t *v, const hint_env_t *env, int use_st) {
    hint_t *x = xcalloc(1, sizeof(*x));
    x->use_st = use_st; x->log = env->log;
    x->kmax = (uint32_t)pv_int(v, "k_max");
    if (x->kmax < 1 || x->kmax > env->k_max) die("%s: k_max=%u must be in [1, --k-max=%u]", v->name, x->kmax, env->k_max);
    if (use_st && x->kmax < 2) die("st_hr_refine: k_max must be >= 2");
    x->stat = hs_parse_stat(pv_str(v, "stat")); x->weight = hs_parse_weight(pv_str(v, "weight"));
    x->min_obs = pv_dbl(v, "min_obs"); x->min_share = pv_dbl(v, "min_share"); x->eps = pv_dbl(v, "eps");
    x->hyst = pv_dbl(v, "hyst"); x->dwell = (int)pv_int(v, "dwell"); x->eps_log = pv_dbl(v, "eps_log");
    if (use_st) {
        stw_init(&x->w, v);
        x->nosplit_refine = !strcmp(pv_str(v, "refine_when_nosplit"), "yes");
        x->ema_den = x->w.ema_den;
    } else {
        x->recalc = (uint64_t)pv_int(v, "recalc"); x->ema_den = (uint64_t)pv_int(v, "ema_den");
        if (!x->recalc || !x->ema_den) die("hr_segment: recalc and ema_den must be > 0");
    }
    x->st_thr = -1; x->last_change = INT64_MIN / 2;
    hint_log_attach_stats(env->log, &x->hs, x->stat, x->weight, x->min_obs, x->eps_log);
    *h = x;
    return 0;
}
static int ref_create(hint_t **h, const param_vals_t *v, const hint_env_t *env) { return mk(h, v, env, 1); }
static int seg_create(hint_t **h, const param_vals_t *v, const hint_env_t *env) { return mk(h, v, env, 0); }
static void destroy(hint_t *h) { free(h); }

static void recompute(hint_t *h, uint64_t t, int64_t st[6]) {
    int L[2], R[2], nr = 0, budget = 0, st_changed = 0;
    if (h->use_st) {
        int64_t thr = h->w.thr;
        st_changed = thr != h->st_thr; h->st_thr = thr;
        if (thr >= 0) { int sb = ilog2_u64((uint64_t)thr); L[0] = 0; R[0] = sb - 1; L[1] = sb; R[1] = HS_NB - 1; nr = 2; budget = (int)h->kmax - 2; }
        else if (h->nosplit_refine) { L[0] = 0; R[0] = HS_NB - 1; nr = 1; budget = (int)h->kmax - 1; }
    } else { L[0] = 0; R[0] = HS_NB - 1; nr = 1; budget = (int)h->kmax - 1; }

    double statv[HS_NB], x[HS_NB], w[HS_NB]; uint8_t valid[HS_NB];
    hs_derive(&h->hs, h->stat, h->weight, h->min_obs, h->eps_log, statv, x, w, valid);
    static seg_t sg[2]; int tl[2], tr[2], j[2];
    for (int i = 0; i < nr; i++) {               /* 重みのある端まで範囲を詰める */
        tl[i] = L[i]; tr[i] = R[i];
        while (tl[i] <= tr[i] && w[tl[i]] <= 0) tl[i]++;
        while (tr[i] >= tl[i] && w[tr[i]] <= 0) tr[i]--;
        seg_run(x, w, tl[i], tr[i], budget + 1, h->min_share, &sg[i]);
        j[i] = sg[i].jmax ? 1 : 0;
    }
    for (; budget > 0; budget--) {               /* SSE の減り幅が最大の範囲に 1 区間ずつ足す（肘の規則つき） */
        int bi = -1; double best = -1;
        for (int i = 0; i < nr; i++) {
            const seg_t *s = &sg[i];
            if (!j[i] || j[i] >= s->jmax || !(s->sse[1] > 0) || s->sse[j[i] + 1] == INFINITY) continue;
            double red = s->sse[j[i]] - s->sse[j[i] + 1];
            if (red / s->sse[1] >= h->eps && red > best) { best = red; bi = i; }
        }
        if (bi < 0) break;
        j[bi]++;
    }
    int nc[HS_NB], nnc = 0, cc[HS_NB], ncc;
    double sse_new = 0, sse_cur = 0;
    for (int i = 0; i < nr; i++) {
        if (!j[i]) continue;
        sse_new += sg[i].sse[j[i]];
        for (int k = 1; k < j[i]; k++) nc[nnc++] = sg[i].start[j[i]][k];
        ncc = 0;
        for (int k = 0; k < h->ncut; k++) if (h->cuts[k] > tl[i] && h->cuts[k] <= tr[i]) cc[ncc++] = h->cuts[k];
        sse_cur += seg_sse_cuts(x, w, tl[i], tr[i], cc, ncc);
    }
    int differ = nnc != h->ncut || memcmp(nc, h->cuts, (size_t)nnc * sizeof(int));
    const char *note = "hold";
    if (differ && (st_changed || ((int64_t)h->nrec - h->last_change >= h->dwell && sse_new <= (1 - h->hyst) * sse_cur))) {
        memcpy(h->cuts, nc, (size_t)nnc * sizeof(int)); h->ncut = nnc; h->last_change = (int64_t)h->nrec;
        note = st_changed ? "st_changed" : "adopt";
    } else if (!differ) note = "same";
    else if (!nr) note = "nosplit";

    int64_t nt[KMAX_LIMIT]; uint32_t n = 0;
    if (h->use_st && h->st_thr >= 0) nt[n++] = h->st_thr - (int64_t)h->w.add;
    for (int k = 0; k < h->ncut; k++) nt[n++] = ((int64_t)1 << h->cuts[k]) - 1;
    for (uint32_t a = 1; a < n; a++)
        for (uint32_t b = a; b > 0 && nt[b - 1] > nt[b]; b--) { int64_t q = nt[b]; nt[b] = nt[b - 1]; nt[b - 1] = q; }
    int changed = n != h->n || memcmp(nt, h->taus, n * sizeof(int64_t));
    if (changed) { h->ep++; h->n = n; memcpy(h->taus, nt, n * sizeof(int64_t)); }
    hint_log_event(h->log, t, h->use_st ? h->w.s.n_obs : h->obs, h->ep, changed, h->taus, h->n, NULL, st, sse_cur, sse_new, note);
    h->nrec++;
    hs_decay(&h->hs, (double)(h->ema_den - 1) / (double)h->ema_den);
}

static uint32_t on_admit(hint_t *h, const hint_admit_t *a) {
    hs_admit(&h->hs, a->size);
    int64_t st[6] = {-1, -1, -1, -1, -1, -1};
    if (h->use_st) { if (stw_admit(&h->w, (uint64_t)a->size + h->w.add, st)) recompute(h, a->t, st); }
    else if (++h->obs % h->recalc == 0) recompute(h, a->t, st);
    return class_of_taus(h->taus, h->n, a->size);
}
static void on_hit(hint_t *h, uint64_t t, uint32_t s, uint32_t c) { (void)t; (void)c; hs_hit(&h->hs, s); }
static void on_evict(hint_t *h, uint64_t t, uint32_t s, uint32_t c, uint32_t freq, uint64_t res) {
    (void)t; (void)c;
    hs_evict(&h->hs, s, freq, res);
    if (h->use_st) sst_on_evict(&h->w.s, (uint64_t)s + h->w.add, freq);
}
static uint32_t epoch(const hint_t *h) { return h->ep; }
static uint32_t maxc(const hint_t *h) { return h->kmax; }
static uint32_t bounds(const hint_t *h, int64_t *out, uint32_t max) {
    uint32_t n = h->n < max ? h->n : max;
    memcpy(out, h->taus, n * sizeof(int64_t));
    return n;
}

const hint_ops_t hint_st_hr_refine_ops = {"st_hr_refine", P_REF, ref_create, destroy, on_admit, on_hit, on_evict, epoch, bounds, maxc, NULL, NULL, NULL, NULL};
const hint_ops_t hint_hr_segment_ops   = {"hr_segment",   P_SEG, seg_create, destroy, on_admit, on_hit, on_evict, epoch, bounds, maxc, NULL, NULL, NULL, NULL};
