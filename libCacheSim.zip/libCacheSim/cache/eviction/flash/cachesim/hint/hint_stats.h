/* hint_stats.h — バケット別の SSD ヒット統計（§9.5）。バケットは split_threshold と同じ log2（48 本） */
#ifndef HINT_STATS_H
#define HINT_STATS_H
#include "../common.h"

#define HS_NB 48
typedef struct hint_stats {
    double admit_n[HS_NB], admit_bytes[HS_NB], hit_n[HS_NB], hit_bytes[HS_NB];
    double evict_n[HS_NB], evict_bytes[HS_NB], cold_n[HS_NB], cold_bytes[HS_NB], res_sum[HS_NB];
} hint_stats_t;

enum { HS_HD, HS_REUSE, HS_USEFUL };
enum { HS_W_BYTES, HS_W_COUNT };

static inline int hs_bucket(uint64_t s) { int b = ilog2_u64(s ? s : 1); return b > HS_NB - 1 ? HS_NB - 1 : b; }
void hs_admit(hint_stats_t *h, uint32_t s);
void hs_hit(hint_stats_t *h, uint32_t s);
void hs_evict(hint_stats_t *h, uint32_t s, uint32_t freq, uint64_t res);
void hs_decay(hint_stats_t *h, double f);
/* 派生統計: stat[b]、分割に使う x[b]、重み w[b]、有効フラグ valid[b]（無効なら w = 0） */
void hs_derive(const hint_stats_t *h, int stat, int weight, double min_obs, double eps_log,
               double *statv, double *x, double *w, uint8_t *valid);
int  hs_parse_stat(const char *s);
int  hs_parse_weight(const char *s);
#endif
