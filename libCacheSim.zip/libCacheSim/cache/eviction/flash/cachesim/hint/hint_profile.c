/* hint_profile.c — 前の実行の sizebin_profile.csv から静的に τ を決める（§9.3、2 パス）。
 * 分布は SSD 受け入れ（admit_*）を使う。受け入れが 0 の場合だけ全要求（raw_*）で代用する。
 * ビン [lo, hi) の右端で切るとき τ = hi − 1（s > τ ⇔ s ≥ hi）。
 * stseg / hrseg はビンを log2 バケット（lo のバケット）に寄せてから適用する。 */
#include "../plugin.h"
#include "st_wrap.h"
#include "hint_stats.h"
#include "segment.h"

struct hint { int64_t taus[KMAX_LIMIT]; uint32_t n; };
static const param_spec_t P[] = {
    {"path", P_STRING, "", NULL, "sizebin_profile.csv のパス"},
    {"method", P_ENUM, "qbytes", "qcount|qbytes|geo|stseg|hrseg", "分割方法"},
    {"k", P_UINT, "2", NULL, "分類数（hrseg では上限）"},
    {"stat", P_ENUM, "hd", "hd|reuse|useful", "hrseg の派生統計"},
    {"weight", P_ENUM, "bytes", "bytes|count", "hrseg の重み"},
    {"min_obs", P_DOUBLE, "200", NULL, "hrseg の有効バケット条件"},
    {"min_share", P_DOUBLE, "0.02", NULL, "hrseg の区間重みの下限"},
    {"eps", P_DOUBLE, "0.05", NULL, "hrseg の肘の閾値"},
    {"eps_log", P_DOUBLE, "1e-12", NULL, "hrseg の log(stat + eps_log)"},
    {"lambda", P_INT, "0", NULL, "stseg の λ×256"},
    {"min_band", P_INT, "2", NULL, "stseg の狭帯ゲート"},
    {"no_split_pct", P_INT, "5", NULL, "stseg の大 pool ゲート"}, {NULL}};

enum { C_LO, C_HI, C_RAWN, C_RAWB, C_AN, C_AB, C_SH, C_SHB, C_EN, C_EB, C_CN, C_CB, C_RES, NCOL };
static const char *COLS[NCOL] = {"lo", "hi", "raw_reqs", "raw_bytes", "admit_objs", "admit_bytes", "ssd_hits",
                                 "ssd_hit_bytes", "evict_objs", "evict_bytes", "cold_objs", "cold_bytes", "res_sum"};

static int create(hint_t **h, const param_vals_t *v, const hint_env_t *env) {
    hint_t *x = xcalloc(1, sizeof(*x));
    const char *path = pv_str(v, "path"), *m = pv_str(v, "method");
    uint32_t k = (uint32_t)pv_int(v, "k");
    if (k < 1 || k > env->k_max) die("profile: k=%u must be in [1, --k-max=%u]", k, env->k_max);
    FILE *f = fopen(path, "r");
    if (!f) die("profile: cannot open '%s'", path);
    char line[8192]; int idx[NCOL];
    double (*rows)[NCOL] = NULL; size_t nr = 0, cap = 0;
    if (!fgets(line, sizeof line, f)) die("profile: empty file %s", path);
    for (int c = 0; c < NCOL; c++) {
        idx[c] = -1; int i = 0;
        char *dup = xstrdup(line), *save = NULL;
        for (char *t = strtok_r(dup, ",\r\n", &save); t; t = strtok_r(NULL, ",\r\n", &save), i++)
            if (!strcmp(t, COLS[c])) idx[c] = i;
        free(dup);
        if (idx[c] < 0) die("profile: column '%s' missing in %s", COLS[c], path);
    }
    while (fgets(line, sizeof line, f)) {
        GROW(rows, cap, nr + 1);
        int i = 0; char *save = NULL;
        double vals[64] = {0};
        for (char *t = strtok_r(line, ",\r\n", &save); t && i < 64; t = strtok_r(NULL, ",\r\n", &save)) vals[i++] = strtod(t, NULL);
        for (int c = 0; c < NCOL; c++) rows[nr][c] = vals[idx[c]];
        nr++;
    }
    fclose(f);
    double tot_n = 0;
    for (size_t r = 0; r < nr; r++) tot_n += rows[r][C_AN];
    int un = tot_n > 0 ? C_AN : C_RAWN, ub = tot_n > 0 ? C_AB : C_RAWB;

    int64_t t[KMAX_LIMIT]; uint32_t n = 0;
    if (!strcmp(m, "qcount") || !strcmp(m, "qbytes")) {
        int col = m[1] == 'c' ? un : ub; double tot = 0, cum = 0; uint32_t j = 1;
        size_t last = 0;
        for (size_t r = 0; r < nr; r++) { tot += rows[r][col]; if (rows[r][col] > 0) last = r; }
        for (size_t r = 0; r < nr && j < k && tot > 0; r++) {
            cum += rows[r][col];
            if (r < last && cum >= tot * j / k) {
                int64_t tau = (int64_t)rows[r][C_HI] - 1;
                if (!n || tau > t[n - 1]) t[n++] = tau;
                while (j < k && cum >= tot * j / k) j++;
            }
        }
    } else if (!strcmp(m, "geo")) {
        double lo = -1, hi = -1;
        for (size_t r = 0; r < nr; r++) if (rows[r][un] > 0) { if (lo < 0) lo = rows[r][C_LO] > 0 ? rows[r][C_LO] : 1; hi = rows[r][C_HI] - 1; }
        for (uint32_t j = 1; j < k && lo > 0 && hi > lo; j++) {
            int64_t tau = (int64_t)floor(lo * pow(hi / lo, (double)j / k));
            if (!n || tau > t[n - 1]) t[n++] = tau;
        }
    } else if (!strcmp(m, "stseg")) {
        split_thresh_t s;
        sst_init(&s, (int)pv_int(v, "lambda"));
        s.min_band_oct = (int)pv_int(v, "min_band"); s.nosplit_pct = (int)pv_int(v, "no_split_pct");
        for (size_t r = 0; r < nr; r++) {
            int b = sst_bucket((uint64_t)(rows[r][C_LO] > 1 ? rows[r][C_LO] : 1));
            s.count[b] += (uint64_t)rows[r][un]; s.all_bytes[b] += (uint64_t)rows[r][ub]; s.cold_bytes[b] += (uint64_t)rows[r][C_CB];
        }
        sst_recompute(&s);
        n = (uint32_t)st_split_taus(&s, s.threshold, 64, (int)k, t);
    } else {                                                  /* hrseg */
        hint_stats_t hs; memset(&hs, 0, sizeof hs);
        for (size_t r = 0; r < nr; r++) {
            int b = hs_bucket((uint64_t)(rows[r][C_LO] > 1 ? rows[r][C_LO] : 1));
            hs.admit_n[b] += rows[r][C_AN]; hs.admit_bytes[b] += rows[r][C_AB]; hs.hit_n[b] += rows[r][C_SH];
            hs.hit_bytes[b] += rows[r][C_SHB]; hs.evict_n[b] += rows[r][C_EN]; hs.evict_bytes[b] += rows[r][C_EB];
            hs.cold_n[b] += rows[r][C_CN]; hs.cold_bytes[b] += rows[r][C_CB]; hs.res_sum[b] += rows[r][C_RES];
        }
        double sv[HS_NB], xx[HS_NB], w[HS_NB]; uint8_t val[HS_NB]; seg_t sg;
        hs_derive(&hs, hs_parse_stat(pv_str(v, "stat")), hs_parse_weight(pv_str(v, "weight")), pv_dbl(v, "min_obs"),
                  pv_dbl(v, "eps_log"), sv, xx, w, val);
        int l = 0, r = HS_NB - 1;
        while (l <= r && w[l] <= 0) l++;
        while (r >= l && w[r] <= 0) r--;
        seg_run(xx, w, l, r, (int)k, pv_dbl(v, "min_share"), &sg);
        int j = seg_elbow(&sg, pv_dbl(v, "eps"));
        for (int i = 1; i < j; i++) t[n++] = ((int64_t)1 << sg.start[j][i]) - 1;
    }
    free(rows);
    memcpy(x->taus, t, n * sizeof(int64_t)); x->n = n;
    int64_t st[6] = {-1, -1, -1, -1, -1, -1};
    hint_log_event(env->log, 0, 0, 0, 1, x->taus, x->n, NULL, st, NAN, NAN, "profile");
    *h = x;
    return 0;
}
static void destroy(hint_t *h) { free(h); }
static uint32_t on_admit(hint_t *h, const hint_admit_t *a) { return class_of_taus(h->taus, h->n, a->size); }
static void on_hit(hint_t *h, uint64_t t, uint32_t s, uint32_t c) { (void)h; (void)t; (void)s; (void)c; }
static void on_evict(hint_t *h, uint64_t t, uint32_t s, uint32_t c, uint32_t f, uint64_t r) { (void)h; (void)t; (void)s; (void)c; (void)f; (void)r; }
static uint32_t epoch(const hint_t *h) { (void)h; return 0; }
static uint32_t maxc(const hint_t *h) { return h->n + 1; }
static uint32_t bounds(const hint_t *h, int64_t *out, uint32_t max) {
    uint32_t n = h->n < max ? h->n : max;
    memcpy(out, h->taus, n * sizeof(int64_t));
    return n;
}

const hint_ops_t hint_profile_ops = {"profile", P, create, destroy, on_admit, on_hit, on_evict, epoch, bounds, maxc, NULL, NULL, NULL, NULL};
