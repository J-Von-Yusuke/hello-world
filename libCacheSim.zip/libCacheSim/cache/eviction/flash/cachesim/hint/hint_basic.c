/* hint_basic.c — none（常に 0）と fixed（τ を直接指定）（§9.2）。エポックは 0 のまま */
#include "../plugin.h"

struct hint { int64_t taus[KMAX_LIMIT]; uint32_t n; };
static const param_spec_t P_NONE[] = {{NULL}};
static const param_spec_t P_FIXED[] = {{"tau", P_LIST, "", NULL, "境界 τ（昇順。fixed:1024,2048,10000 のように書ける。K/M/G 可）"}, {NULL}};

static int none_create(hint_t **h, const param_vals_t *v, const hint_env_t *env) { (void)v; (void)env; *h = xcalloc(1, sizeof(hint_t)); return 0; }
static int fixed_create(hint_t **h, const param_vals_t *v, const hint_env_t *env) {
    hint_t *x = xcalloc(1, sizeof(*x));
    double a[KMAX_LIMIT];
    x->n = (uint32_t)pv_list(v, "tau", a, KMAX_LIMIT);
    if (x->n + 1 > env->k_max) die("fixed: %u taus give %u classes > k_max %u", x->n, x->n + 1, env->k_max);
    for (uint32_t i = 0; i < x->n; i++) {
        x->taus[i] = (int64_t)a[i];
        if (i && x->taus[i] <= x->taus[i - 1]) die("fixed: tau must be strictly increasing");
    }
    *h = x;
    return 0;
}
static void destroy(hint_t *h) { free(h); }
static uint32_t on_admit(hint_t *h, const hint_admit_t *a) { return class_of_taus(h->taus, h->n, a->size); }
static void on_hit(hint_t *h, uint64_t t, uint32_t s, uint32_t c) { (void)h; (void)t; (void)s; (void)c; }
static void on_evict(hint_t *h, uint64_t t, uint32_t s, uint32_t c, uint32_t f, uint64_t r) { (void)h; (void)t; (void)s; (void)c; (void)f; (void)r; }
static uint32_t epoch(const hint_t *h) { (void)h; return 0; }
static uint32_t maxc(const hint_t *h) { return h->n + 1; }
static uint32_t bounds(const hint_t *h, int64_t *out, uint32_t max) {
    uint32_t n = h->n < max ? h->n : max;
    memcpy(out, h->taus, n * sizeof(int64_t));
    return n;
}

const hint_ops_t hint_none_ops  = {"none",  P_NONE,  none_create,  destroy, on_admit, on_hit, on_evict, epoch, bounds, maxc, NULL, NULL, NULL, NULL};
const hint_ops_t hint_fixed_ops = {"fixed", P_FIXED, fixed_create, destroy, on_admit, on_hit, on_evict, epoch, bounds, maxc, NULL, NULL, NULL, NULL};
