/* hint_split_threshold.c — split_threshold（§9.4）と st_recursive（§9.7）。
 * split_threshold は st_recursive の depth = 1 と同じ処理（最上位は C 版の threshold をそのまま使う）。
 * τ は「生のサイズ」で持つ: s + size_add > thr ⇔ s > thr − size_add。 */
#include "../plugin.h"
#include "st_wrap.h"

struct hint { stw_t w; int depth; uint32_t kmax, n, ep; int64_t taus[KMAX_LIMIT]; hint_log_t *log; };
static const param_spec_t P_ST[] = {ST_PARAM_SPECS, {NULL}};
static const param_spec_t P_REC[] = {{"depth", P_UINT, "2", NULL, "再帰の深さ（最大 2^depth 分類）"}, ST_PARAM_SPECS, {NULL}};

static int mk(hint_t **h, const param_vals_t *v, const hint_env_t *env, int depth) {
    hint_t *x = xcalloc(1, sizeof(*x));
    stw_init(&x->w, v);
    x->depth = depth; x->kmax = env->k_max; x->log = env->log;
    if (depth < 1) die("st_recursive: depth must be >= 1");
    *h = x;
    return 0;
}
static int st_create(hint_t **h, const param_vals_t *v, const hint_env_t *env) { return mk(h, v, env, 1); }
static int rec_create(hint_t **h, const param_vals_t *v, const hint_env_t *env) { return mk(h, v, env, (int)pv_int(v, "depth")); }
static void destroy(hint_t *h) { free(h); }

static uint32_t on_admit(hint_t *h, const hint_admit_t *a) {
    int64_t st[6], nt[KMAX_LIMIT];
    if (stw_admit(&h->w, (uint64_t)a->size + h->w.add, st)) {
        uint32_t n = (uint32_t)st_split_taus(&h->w.s, h->w.thr, h->depth, (int)h->kmax, nt);
        for (uint32_t i = 0; i < n; i++) nt[i] -= (int64_t)h->w.add;
        int changed = n != h->n || memcmp(nt, h->taus, n * sizeof(int64_t));
        if (changed) { h->ep++; h->n = n; memcpy(h->taus, nt, n * sizeof(int64_t)); }
        hint_log_event(h->log, a->t, h->w.s.n_obs, h->ep, changed, h->taus, h->n, NULL, st, NAN, NAN, "");
    }
    return class_of_taus(h->taus, h->n, a->size);
}
static void on_hit(hint_t *h, uint64_t t, uint32_t s, uint32_t c) { (void)h; (void)t; (void)s; (void)c; }
static void on_evict(hint_t *h, uint64_t t, uint32_t s, uint32_t c, uint32_t freq, uint64_t r) {
    (void)t; (void)c; (void)r;
    sst_on_evict(&h->w.s, (uint64_t)s + h->w.add, freq);
}
static uint32_t epoch(const hint_t *h) { return h->ep; }
static uint32_t maxc(const hint_t *h) {
    uint32_t m = h->depth >= 6 ? 64 : 1u << h->depth;
    return m < h->kmax ? m : h->kmax;
}
static uint32_t bounds(const hint_t *h, int64_t *out, uint32_t max) {
    uint32_t n = h->n < max ? h->n : max;
    memcpy(out, h->taus, n * sizeof(int64_t));
    return n;
}

const hint_ops_t hint_split_threshold_ops = {"split_threshold", P_ST, st_create, destroy, on_admit, on_hit, on_evict, epoch, bounds, maxc, NULL, NULL, NULL, NULL};
const hint_ops_t hint_st_recursive_ops = {"st_recursive", P_REC, rec_create, destroy, on_admit, on_hit, on_evict, epoch, bounds, maxc, NULL, NULL, NULL, NULL};
