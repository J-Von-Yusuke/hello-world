#include "segment.h"

typedef struct { double W[HS_NB + 1], S[HS_NB + 1], Q[HS_NB + 1]; } pre_t;

static void prefix(const double *x, const double *w, int l, int r, pre_t *p) {
    p->W[0] = p->S[0] = p->Q[0] = 0;
    for (int i = 0; i <= r - l; i++) {
        double wi = w[l + i], xi = x[l + i];
        p->W[i + 1] = p->W[i] + wi; p->S[i + 1] = p->S[i] + wi * xi; p->Q[i + 1] = p->Q[i] + wi * xi * xi;
    }
}
/* 区間 [a, b]（相対添字、両端含む）の重み付き SSE */
static double cost(const pre_t *p, int a, int b) {
    double W = p->W[b + 1] - p->W[a];
    if (W <= 0) return 0;
    double S = p->S[b + 1] - p->S[a], c = (p->Q[b + 1] - p->Q[a]) - S * S / W;
    return c > 0 ? c : 0;
}

void seg_run(const double *x, const double *w, int l, int r, int jmax, double min_share, seg_t *o) {
    pre_t p; int n = r - l + 1;
    o->l = l; o->r = r; o->jmax = jmax < n ? jmax : n;
    for (int j = 0; j <= HS_NB; j++) o->sse[j] = INFINITY;
    if (n <= 0) { o->jmax = 0; return; }
    prefix(x, w, l, r, &p);
    double wmin = min_share * p.W[n] * (1 - 1e-12);
    static double dp[HS_NB + 1][HS_NB]; static int arg[HS_NB + 1][HS_NB];
    for (int e = 0; e < n; e++) dp[1][e] = p.W[e + 1] >= wmin ? cost(&p, 0, e) : INFINITY;
    for (int j = 2; j <= o->jmax; j++)
        for (int e = 0; e < n; e++) {
            dp[j][e] = INFINITY; arg[j][e] = -1;
            for (int s = j - 1; s <= e; s++) {
                if (dp[j - 1][s - 1] == INFINITY || p.W[e + 1] - p.W[s] < wmin) continue;
                double v = dp[j - 1][s - 1] + cost(&p, s, e);
                if (v < dp[j][e]) { dp[j][e] = v; arg[j][e] = s; }
            }
        }
    for (int j = 1; j <= o->jmax; j++) {
        o->sse[j] = dp[j][n - 1];
        if (o->sse[j] == INFINITY) continue;
        int e = n - 1;
        for (int i = j - 1; i >= 1; i--) { int s = arg[i + 1][e]; o->start[j][i] = l + s; e = s - 1; }
        o->start[j][0] = l;
    }
}

int seg_elbow(const seg_t *o, double eps) {
    if (o->jmax < 1) return 0;
    if (!(o->sse[1] > 0)) return 1;
    int j = 1;
    while (j < o->jmax && o->sse[j + 1] < INFINITY && (o->sse[j] - o->sse[j + 1]) / o->sse[1] >= eps) j++;
    return j;
}

double seg_sse_cuts(const double *x, const double *w, int l, int r, const int *cuts, int ncut) {
    pre_t p; double s = 0; int a = 0;
    if (r < l) return 0;
    prefix(x, w, l, r, &p);
    for (int i = 0; i <= ncut; i++) {
        int b = i < ncut ? cuts[i] - l - 1 : r - l;
        if (b >= a) s += cost(&p, a, b);
        a = b + 1;
    }
    return s;
}
