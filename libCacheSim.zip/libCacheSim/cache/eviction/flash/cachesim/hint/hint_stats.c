#include "hint_stats.h"

void hs_admit(hint_stats_t *h, uint32_t s) { int b = hs_bucket(s); h->admit_n[b] += 1; h->admit_bytes[b] += s; }
void hs_hit(hint_stats_t *h, uint32_t s) { int b = hs_bucket(s); h->hit_n[b] += 1; h->hit_bytes[b] += s; }
void hs_evict(hint_stats_t *h, uint32_t s, uint32_t freq, uint64_t res) {
    int b = hs_bucket(s);
    h->evict_n[b] += 1; h->evict_bytes[b] += s; h->res_sum[b] += (double)res;
    if (freq <= 1) { h->cold_n[b] += 1; h->cold_bytes[b] += s; }
}
void hs_decay(hint_stats_t *h, double f) {
    double *p = (double *)h;
    for (size_t i = 0; i < sizeof(*h) / sizeof(double); i++) p[i] *= f;
}

void hs_derive(const hint_stats_t *h, int stat, int weight, double min_obs, double eps_log,
               double *statv, double *x, double *w, uint8_t *valid) {
    for (int b = 0; b < HS_NB; b++) {
        double v = NAN;
        int ok = h->admit_n[b] >= min_obs && h->evict_n[b] >= min_obs && h->evict_n[b] > 0;
        if (ok) {
            if (stat == HS_HD) {
                double rbar = h->res_sum[b] / h->evict_n[b], den = h->admit_bytes[b] * rbar;
                if (den > 0) v = h->hit_n[b] / den; else ok = 0;
            } else if (stat == HS_REUSE) v = h->hit_n[b] / h->admit_n[b];
            else v = 1.0 - h->cold_n[b] / h->evict_n[b];
        }
        statv[b] = v; valid[b] = (uint8_t)ok;
        x[b] = ok ? (stat == HS_USEFUL ? v : log(v + eps_log)) : 0;
        w[b] = ok ? (weight == HS_W_BYTES ? h->admit_bytes[b] : h->admit_n[b]) : 0;
    }
}
int hs_parse_stat(const char *s) { return !strcmp(s, "hd") ? HS_HD : !strcmp(s, "reuse") ? HS_REUSE : HS_USEFUL; }
int hs_parse_weight(const char *s) { return !strcmp(s, "count") ? HS_W_COUNT : HS_W_BYTES; }
