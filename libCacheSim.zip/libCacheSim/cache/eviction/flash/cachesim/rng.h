/* rng.h — 乱数は xoshiro256** のみ、ハッシュは splitmix64 のみ（DESIGN.md §13） */
#ifndef RNG_H
#define RNG_H
#include <stdint.h>

static inline uint64_t splitmix64(uint64_t x) {
    x += 0x9e3779b97f4a7c15ULL;
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
    x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
    return x ^ (x >> 31);
}

typedef struct { uint64_t s[4]; } rng_t;

static inline void rng_seed(rng_t *r, uint64_t seed) {
    for (int i = 0; i < 4; i++) r->s[i] = splitmix64(seed + 0x632be59bd9b4e019ULL * (uint64_t)(i + 1));
}
static inline uint64_t rng_rotl(uint64_t x, int k) { return (x << k) | (x >> (64 - k)); }
static inline uint64_t rng_next(rng_t *r) {
    uint64_t *s = r->s, res = rng_rotl(s[1] * 5, 7) * 9, t = s[1] << 17;
    s[2] ^= s[0]; s[3] ^= s[1]; s[1] ^= s[2]; s[0] ^= s[3]; s[2] ^= t; s[3] = rng_rotl(s[3], 45);
    return res;
}
static inline double rng_double(rng_t *r) { return (double)(rng_next(r) >> 11) * 0x1.0p-53; }
static inline uint64_t rng_below(rng_t *r, uint64_t n) {
    return (uint64_t)(((unsigned __int128)rng_next(r) * n) >> 64);
}
#endif
