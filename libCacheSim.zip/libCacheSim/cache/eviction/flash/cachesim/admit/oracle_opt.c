/* oracle_opt.c — Baleen（Wong ほか, FAST 2024）の OPT（エピソードによる近似最適の受け入れ。§8.2）。2 パス。
 * 1 パス目（log=PATH）: SSD 参照（DRAM ミス）の列 (t, id, size) をファイルに書き、すべて受け入れる。SSD 参照の列は
 *   SSD の受け入れに依らない（DRAM にはミスでも SSD ヒットでも入る）ので、同じトレース・同じ DRAM 構成なら 2 パス目と一致する。
 * 2 パス目（episodes=PATH）: 物ごとの参照を、間隔が退去年齢 E 以下なら同じエピソードにまとめる（サイズが変われば切る）。
 *   ヒットが 1 回以上あり SSD に入るエピソードを、得点 = 便益 ÷ サイズ（便益は ohr ならヒット数、bhr ならヒットのバイト）の
 *   大きい順に並べ、書き込み予算 budget（0 = 無制限）を超えない限り上から採る。E は Little の法則による占有
 *   Σ size·(t_last − t_first + E) ÷ 期間 が SSD 容量に等しくなるよう log E の二分法で決める（eage > 0 なら固定）。
 *   実行中は、採ったエピソードの最初の参照から最後の参照までのあいだ、受け入れの時点で残りの参照があれば受け入れる。
 * 未来の情報を使うので oracle_ を名乗る。ログの (t, id) の列のハッシュを 2 パス目でも計算し、一致を報告する。 */
#include "../plugin.h"
#include "../hashmap.h"

typedef struct { double score; uint64_t t0, t1; uint32_t o, size, n; } ep_t;
struct admission {
    int opt, bhr; FILE *log; double cap, maxobj, budget, eage, occ, plan_w, plan_h;
    uint64_t n, h, nlog, hlog, neps, nadm;
    hmap_t adm, cur;                                      /* (id, t_first) の混ぜ値 → t_last、id → 今のエピソードの t_last */
};
static const param_spec_t P[] = {
    {"log", P_STRING, "", NULL, "1 パス目: SSD 参照の列を書くファイル"},
    {"episodes", P_STRING, "", NULL, "2 パス目: 1 パス目のファイル"},
    {"budget", P_BYTES, "0", NULL, "書き込み予算（0 = 無制限）"},
    {"benefit", P_ENUM, "ohr", "ohr|bhr", "便益（ヒット数 / ヒットのバイト）"},
    {"eage", P_DOUBLE, "0", NULL, "退去年齢 E（要求数。0 = 占有が容量に等しくなるよう決める）"},
    {NULL}};
static const char MAGIC[8] = {'C', 'S', 'L', 'O', 'O', 'K', '0', '1'};

static uint64_t mixk(uint64_t id, uint64_t t) { return splitmix64(id ^ splitmix64(t + 0x9e3779b97f4a7c15ULL)); }

static int cmp_ep(const void *x, const void *y) {
    const ep_t *p = x, *q = y;
    if (p->score != q->score) return p->score > q->score ? -1 : 1;
    if (p->t0 != q->t0) return p->t0 < q->t0 ? -1 : 1;
    return p->o < q->o ? -1 : p->o > q->o;
}
typedef struct { uint64_t *t; uint32_t *o, *s; uint64_t nr, no, *ids; double span; } logv_t;
typedef struct { uint64_t t0, t1; uint32_t n, s; } st_t;      /* 物ごとの作りかけのエピソード */
typedef struct { ep_t *ep; uint64_t cap, m; st_t *st; } work_t;
static void close_ep(const admission_t *a, work_t *W, uint32_t o) {
    st_t *x = &W->st[o];
    if (x->n >= 2 && x->s <= a->maxobj) {
        GROW(W->ep, W->cap, W->m + 1);
        double hits = x->n - 1;
        W->ep[W->m++] = (ep_t){a->bhr ? hits : hits / x->s, x->t0, x->t1, o, x->s, x->n};
    }
    x->n = 0;
}
/* 退去年齢 E でエピソードを作って並べ、予算まで採る。占有（容量に対する比）を返し、*ne に採った数を入れる */
static double episodes(admission_t *a, const logv_t *L, double E, work_t *W, uint64_t *ne) {
    W->m = 0;
    memset(W->st, 0, L->no * sizeof(st_t));
    for (uint64_t i = 0; i < L->nr; i++) {
        st_t *x = &W->st[L->o[i]];
        if (x->n && (double)(L->t[i] - x->t1) <= E && L->s[i] == x->s) { x->n++; x->t1 = L->t[i]; continue; }
        close_ep(a, W, L->o[i]);
        *x = (st_t){L->t[i], L->t[i], 1, L->s[i]};
    }
    for (uint64_t o = 0; o < L->no; o++) close_ep(a, W, (uint32_t)o);
    qsort(W->ep, (size_t)W->m, sizeof(ep_t), cmp_ep);
    double w = 0, occ = 0, hits = 0;
    uint64_t k = 0;
    for (; k < W->m; k++) {
        const ep_t *e = &W->ep[k];
        if (a->budget > 0 && w + e->size > a->budget) break;
        w += e->size; hits += e->n - 1;
        occ += (double)e->size * ((double)(e->t1 - e->t0) + E);
    }
    *ne = k; a->plan_w = w; a->plan_h = hits;
    return occ / L->span / a->cap;
}

static void build(admission_t *a, const char *path) {
    FILE *f = fopen(path, "rb");
    char mg[8];
    if (!f || fread(mg, 1, 8, f) != 8 || memcmp(mg, MAGIC, 8)) die("oracle_opt: cannot read lookup log %s", path);
    logv_t L = {0};
    uint64_t icap = 0, nrec;
    if (fseek(f, 0, SEEK_END) || (nrec = ((uint64_t)ftell(f) - 8) / 20, fseek(f, 8, SEEK_SET))) die("oracle_opt: cannot seek %s", path);
    L.t = xmalloc(nrec * 8 + 8); L.o = xmalloc(nrec * 4 + 4); L.s = xmalloc(nrec * 4 + 4);   /* 記録の数ちょうど（重いトレースで倍増の分を持たない） */
    hmap_t dense; hm_init(&dense, 1 << 16);
    unsigned char rec[20];
    while (L.nr < nrec && fread(rec, 1, 20, f) == 20) {
        uint64_t t, id; uint32_t s;
        memcpy(&t, rec, 8); memcpy(&id, rec + 8, 8); memcpy(&s, rec + 16, 4);
        a->hlog = splitmix64(a->hlog + mixk(id, t)); a->nlog++;
        uint64_t *p = hm_get(&dense, id);
        uint32_t o;
        if (p) o = (uint32_t)*p;
        else { GROW(L.ids, icap, L.no + 1); L.ids[L.no] = id; o = (uint32_t)L.no; hm_put(&dense, id, L.no++); }
        L.t[L.nr] = t; L.o[L.nr] = o; L.s[L.nr++] = s;
    }
    fclose(f); hm_free(&dense);
    if (!L.nr) die("oracle_opt: empty lookup log %s", path);
    L.span = (double)(L.t[L.nr - 1] - L.t[0] + 1);
    work_t W = {NULL, 0, 0, xmalloc(L.no * sizeof(st_t))};
    uint64_t ne = 0;
    double E = a->eage;
    if (!(E > 0)) {                                          /* 占有 = 容量 となる E（大きい E ほど占有が増える） */
        double lo = 0, hi = log(L.span);
        if (episodes(a, &L, L.span, &W, &ne) <= 1) lo = hi;
        for (int it = 0; it < 30 && hi - lo > 1e-3; it++) {
            double mid = 0.5 * (lo + hi);
            if (episodes(a, &L, exp(mid), &W, &ne) > 1) hi = mid; else lo = mid;
        }
        E = exp(lo);
    }
    a->occ = episodes(a, &L, E, &W, &ne);
    a->eage = E; a->neps = W.m; a->nadm = ne;
    hm_init(&a->adm, ne * 2 + 16); hm_init(&a->cur, 1024);
    for (uint64_t k = 0; k < ne; k++) hm_put(&a->adm, mixk(L.ids[W.ep[k].o], W.ep[k].t0), W.ep[k].t1);
    free(W.ep); free(W.st); free(L.t); free(L.o); free(L.s); free(L.ids);
}

static int create(admission_t **out, const param_vals_t *v, const admission_env_t *e) {
    admission_t *a = xcalloc(1, sizeof *a);
    const char *lg = pv_str(v, "log"), *eps = pv_str(v, "episodes");
    a->cap = (double)e->ssd_bytes; a->maxobj = (double)e->ssd_max_obj; a->budget = (double)pv_int(v, "budget");
    a->bhr = !strcmp(pv_str(v, "benefit"), "bhr"); a->eage = pv_dbl(v, "eage");
    if (!*lg == !*eps) die("oracle_opt: give exactly one of log=PATH (pass 1) or episodes=PATH (pass 2)");
    if (*lg) {
        if (!(a->log = fopen(lg, "wb")) || fwrite(MAGIC, 1, 8, a->log) != 8) die("oracle_opt: cannot write %s", lg);
    } else {
        if (!(a->cap > 0) || !(a->eage >= 0)) die("oracle_opt: pass 2 needs an SSD and eage >= 0");
        a->opt = 1; build(a, eps);
    }
    *out = a;
    return 0;
}
static void destroy(admission_t *a) {
    if (a->log && fclose(a->log)) die("oracle_opt: error writing the lookup log");
    if (a->opt) { hm_free(&a->adm); hm_free(&a->cur); }
    free(a);
}

static void on_lookup(admission_t *a, uint64_t t, uint64_t id, uint32_t size) {
    uint64_t k = mixk(id, t);
    a->h = splitmix64(a->h + k); a->n++;
    if (!a->opt) {
        unsigned char rec[20];
        memcpy(rec, &t, 8); memcpy(rec + 8, &id, 8); memcpy(rec + 16, &size, 4);
        if (fwrite(rec, 1, 20, a->log) != 20) die("oracle_opt: error writing the lookup log");
        return;
    }
    uint64_t *x = hm_get(&a->cur, id);
    if (x && t >= *x) hm_del(&a->cur, id);                 /* エピソードの最後の参照 */
    uint64_t *v = hm_get(&a->adm, k);
    if (v) hm_put(&a->cur, id, *v);                        /* 採ったエピソードの最初の参照 */
}
static int accept(admission_t *a, const admit_info_t *in) {
    if (!a->opt) return 1;
    uint64_t *x = hm_get(&a->cur, in->id);
    return x && in->t < *x;
}
static void report(admission_t *a, FILE *f) {
    fprintf(f, "{ \"name\": \"oracle_opt\", \"pass\": %d, \"lookups\": %lu", a->opt ? 2 : 1, (unsigned long)a->n);
    if (a->opt)
        fprintf(f, ", \"log_match\": %s, \"budget\": %.0f, \"eage\": %.6g, \"episodes\": %lu, \"admitted\": %lu, "
                   "\"plan_write_bytes\": %.0f, \"plan_hits\": %.0f, \"plan_occupancy\": %.6f",
                a->n == a->nlog && a->h == a->hlog ? "true" : "false", a->budget, a->eage, (unsigned long)a->neps,
                (unsigned long)a->nadm, a->plan_w, a->plan_h, a->occ);
    fputs(" }", f);
}

const admission_ops_t adm_oracle_opt_ops = {"oracle_opt", P, create, destroy, accept, NULL, on_lookup, report};
