/* adaptsize.c — AdaptSize（Berger, Sitaraman, Harchol-Balter, NSDI 2017）の受け入れ（§8.2）。
 * 受け入れ確率は exp(−s/c)（sizeexp と同じ式）で、c を SSD 参照（DRAM ミス）interval 回ごとに候補
 * log2 c = hi, hi − step, …, lo から選び直す（同点なら大きい c）。SSD 参照の列は SSD の受け入れに依らない
 * （DRAM にはミスでも SSD ヒットでも入る）ので、どちらの調整器もこの列だけを見る。
 * tuner=sim（既定）: 物 id のハッシュで割合 sample の物だけを取り出し、容量 sample × SSD 容量の物単位 LRU を候補ごとに
 *   並行して模擬する（小型模擬。乱数は候補で共通なので受け入れる物の集合は c について入れ子）。各候補の窓ごとのヒット率
 *   （objective=bhr ならバイトヒット率）を重み alpha で指数移動平均し、最大の候補を採る。
 * tuner=model: 元の AdaptSize の Markov 近似。窓の物ごとの参照回数とサイズを（log2 サイズ, log2 回数）の 1/4 オクターブの表に
 *   まとめて指数移動平均し、SSD を LRU とみた特性時間 μ を Σ m s P = 容量 から決め、予測 OHR = Σ m r P / Σ m r が最大の c を採る。
 *   窓は参照 interval 回以上かつ異なる物のバイトが win × 容量以上。回数を率とみなす代入推定は窓が μ より十分長くないと
 *   占有を過小に見積もり OHR を過大に予測する。また定常の式（horizon=0）は c → 0 で OHR を過大に予測する（§8.2 の注）。
 * 配列は倍増でだけ伸ばす（要求ごとの確保なし）。 */
#include "../plugin.h"
#include "../hashmap.h"

#define SB 172                                              /* model: 4·log2 サイズ（2^43 未満） */
#define RB 120                                              /* model: 4·log2 回数（2^30 未満） */
typedef struct { uint64_t cnt; uint32_t size; } ob_t;
typedef struct { double m, s, r; } cell_t;
typedef struct { uint64_t key; uint32_t sz, prv, nxt; } nd_t;
typedef struct {                                            /* sim: 候補 1 つ分の物単位 LRU（nd の添字の双方向リスト） */
    hmap_t m; nd_t *nd; uint64_t ncap, nn; uint32_t head, tail, fre; double used, h;
} mc_t;
struct admission {
    rng_t *rng, mr; int model, bhr; double c, cap, maxobj, alpha, lo, hi, step, win, hz, sample, look;
    uint64_t interval, n, nw, tunes, thr; double ubytes, wlen;
    int ncand; double *score, *curve; mc_t *mc;             /* 候補ごと: 指数移動平均の評価値、最後の評価値、sim の LRU */
    hmap_t idx; ob_t *ob; uint64_t ocap, nobj;              /* model: 窓の物（idx は id → ob の添字） */
    double *H, *Hn; cell_t *cell;                           /* model: 表 [SB][RB][3] = 物の数, サイズの和, 率の和 */
    double sum_lc, min_lc, max_lc, sum_best;
    double *tr; uint64_t tcap, tn;                          /* 報告用の記録: (SSD 参照の通し番号, log2 c, 評価値) */
};
static const param_spec_t P[] = {
    {"tuner", P_ENUM, "sim", "sim|model", "c の調整器"},
    {"interval", P_UINT, "1000000", NULL, "調整の間隔（SSD 参照の回数。model は窓の最小の長さ）"},
    {"alpha", P_DOUBLE, "0.5", NULL, "新しい窓の重み（指数移動平均）"},
    {"lo", P_DOUBLE, "8", NULL, "候補 log2 c の下限"},
    {"hi", P_DOUBLE, "40", NULL, "候補 log2 c の上限"},
    {"step", P_DOUBLE, "1", NULL, "候補の刻み（log2）"},
    {"c0", P_BYTES, "1T", NULL, "最初の調整までの c"},
    {"sample", P_DOUBLE, "0.01", NULL, "sim: 模擬する物の割合（容量も同じ割合に縮める）"},
    {"objective", P_ENUM, "ohr", "ohr|bhr", "sim: 最大にする指標"},
    {"win", P_DOUBLE, "2", NULL, "model: 窓の異なる物のバイト数（SSD 容量の何倍か）"},
    {"horizon", P_DOUBLE, "0", NULL, "model: 期間（窓の長さの何倍か）。0 = 定常（元の AdaptSize）"},
    {NULL}};

static int create(admission_t **out, const param_vals_t *v, const admission_env_t *e) {
    admission_t *a = xcalloc(1, sizeof *a);
    a->rng = e->rng; a->cap = (double)e->ssd_bytes; a->maxobj = (double)e->ssd_max_obj;
    a->model = !strcmp(pv_str(v, "tuner"), "model"); a->bhr = !strcmp(pv_str(v, "objective"), "bhr");
    a->c = (double)pv_int(v, "c0"); a->interval = (uint64_t)pv_int(v, "interval"); a->alpha = pv_dbl(v, "alpha");
    a->lo = pv_dbl(v, "lo"); a->hi = pv_dbl(v, "hi"); a->step = pv_dbl(v, "step");
    a->sample = pv_dbl(v, "sample"); a->win = pv_dbl(v, "win"); a->hz = pv_dbl(v, "horizon");
    if (!a->interval || !(a->alpha > 0 && a->alpha <= 1) || !(a->c > 0) || !(a->step > 0) || a->hi < a->lo || !(a->cap > 0)
        || !(a->sample > 0 && a->sample <= 1) || !(a->win > 0) || !(a->hz >= 0))
        die("adaptsize: need interval > 0, 0 < alpha <= 1, c0 > 0, step > 0, lo <= hi, 0 < sample <= 1, win > 0, horizon >= 0 and an SSD");
    a->ncand = (int)floor((a->hi - a->lo) / a->step + 1e-9) + 1;
    a->score = xcalloc((size_t)a->ncand, 8); a->curve = xcalloc((size_t)a->ncand, 8);
    a->min_lc = INFINITY; a->max_lc = -INFINITY;
    if (a->model) {
        hm_init(&a->idx, 1024);
        a->H = xcalloc((size_t)SB * RB * 3, 8); a->Hn = xcalloc((size_t)SB * RB * 3, 8); a->cell = xmalloc((size_t)SB * RB * sizeof(cell_t));
    } else {
        rng_seed(&a->mr, rng_next(e->rng));
        a->thr = a->sample >= 1 ? UINT64_MAX : (uint64_t)(a->sample * 0x1.0p64);
        a->mc = xcalloc((size_t)a->ncand, sizeof(mc_t));
        for (int j = 0; j < a->ncand; j++) { hm_init(&a->mc[j].m, 1024); a->mc[j].head = a->mc[j].tail = a->mc[j].fre = NONE32; }
    }
    *out = a;
    return 0;
}
static void destroy(admission_t *a) {
    for (int j = 0; a->mc && j < a->ncand; j++) { hm_free(&a->mc[j].m); free(a->mc[j].nd); }
    if (a->model) hm_free(&a->idx);
    free(a->mc); free(a->ob); free(a->H); free(a->Hn); free(a->cell); free(a->tr); free(a->score); free(a->curve); free(a);
}

/* ---- sim: 物単位 LRU ---- */
static void mc_unlink(mc_t *m, uint32_t i) {
    nd_t *x = &m->nd[i];
    if (x->prv != NONE32) m->nd[x->prv].nxt = x->nxt; else m->head = x->nxt;
    if (x->nxt != NONE32) m->nd[x->nxt].prv = x->prv; else m->tail = x->prv;
}
static void mc_front(mc_t *m, uint32_t i) {
    m->nd[i].prv = NONE32; m->nd[i].nxt = m->head;
    if (m->head != NONE32) m->nd[m->head].prv = i; else m->tail = i;
    m->head = i;
}
static void mc_remove(mc_t *m, uint32_t i) {
    mc_unlink(m, i); hm_del(&m->m, m->nd[i].key); m->used -= m->nd[i].sz;
    m->nd[i].nxt = m->fre; m->fre = i;
}
static void sim_lookup(admission_t *a, uint64_t id, uint32_t size) {
    double u = rng_double(&a->mr), cap = a->cap * a->sample;
    a->look += a->bhr ? size : 1;
    for (int j = 0; j < a->ncand; j++) {
        mc_t *m = &a->mc[j];
        uint64_t *p = hm_get(&m->m, id);
        if (p) {
            uint32_t i = (uint32_t)*p;
            if (m->nd[i].sz == size) { m->h += a->bhr ? size : 1; mc_unlink(m, i); mc_front(m, i); continue; }
            mc_remove(m, i);                                 /* サイズが変わった: 別の物として扱う */
        }
        if (size > a->maxobj || size > cap || !(u < exp(-(double)size / exp2(a->hi - j * a->step)))) continue;
        uint32_t i = m->fre;
        if (i != NONE32) m->fre = m->nd[i].nxt;
        else { GROW(m->nd, m->ncap, m->nn + 1); i = (uint32_t)m->nn++; }
        m->nd[i] = (nd_t){id, size, NONE32, NONE32};
        mc_front(m, i); hm_put(&m->m, id, i); m->used += size;
        while (m->used > cap) mc_remove(m, m->tail);
    }
}

/* ---- model: AdaptSize の Markov 近似 ----
 * 外→内の率 λ = r a（a = e^{−s/c}）、内→外の率 ν = r / (e^{rμ} − 1)（滞在を指数分布で近似）。
 * 定常（hz = 0）: π = λ / (λ + ν) = 1 / (1 + e^{−L})、L = ln(e^{rμ} − 1) − s/c（対数で持ち桁あふれを避ける）。
 * 有限の期間 hz（外から始める）: P = π (1 − (1 − e^{−κ hz}) / (κ hz))、κ = λ + ν（2 状態 Markov 連鎖の時間平均）。 */
static double pin(const cell_t *x, double c, double mu, double hz) {
    double rm = x->r * mu, L = (rm < 30 ? log(expm1(rm)) : rm) - x->s / c;
    double pi = L > 0 ? 1 / (1 + exp(-L)) : exp(L) / (1 + exp(L));
    if (hz <= 0) return pi;
    double k = x->r * (exp(-x->s / c) + (rm < 30 ? 1 / expm1(rm) : exp(-rm))) * hz;
    return pi * (k < 1e-4 ? k / 2 - k * k / 6 : 1 + expm1(-k) / k);
}
/* 候補 c での予測 OHR（容量の式 Σ m s P = cap を log μ について二分法で解く。μ = ∞ でも収まるならそのまま） */
static double predict(const cell_t *cl, int nc, double c, double cap, double hz) {
    double rsum = 0, occ = 0, h = 0, mu = INFINITY;
    for (int i = 0; i < nc; i++) { rsum += cl[i].m * cl[i].r; occ += cl[i].m * cl[i].s * pin(&cl[i], c, mu, hz); }
    if (rsum <= 0) return 0;
    if (occ > cap) {
        double lo = log(1e-3), hi = log(1e18);
        for (int it = 0; it < 50; it++) {
            double mid = 0.5 * (lo + hi);
            occ = 0;
            for (int i = 0; i < nc; i++) occ += cl[i].m * cl[i].s * pin(&cl[i], c, exp(mid), hz);
            if (occ > cap) hi = mid; else lo = mid;
        }
        mu = exp(0.5 * (lo + hi));
    }
    for (int i = 0; i < nc; i++) h += cl[i].m * cl[i].r * pin(&cl[i], c, mu, hz);
    return h / rsum;
}
static void model_curve(admission_t *a) {
    memset(a->Hn, 0, (size_t)SB * RB * 3 * 8);
    for (uint64_t i = 0; i < a->nobj; i++) {
        int sb = (int)floor(4 * log2(a->ob[i].size ? a->ob[i].size : 1)), rb = (int)floor(4 * log2((double)a->ob[i].cnt));
        if (sb >= SB) sb = SB - 1;
        if (rb >= RB) rb = RB - 1;
        double *x = &a->Hn[((size_t)sb * RB + (size_t)rb) * 3];
        x[0] += 1; x[1] += a->ob[i].size; x[2] += (double)a->ob[i].cnt / (double)a->nw;
    }
    for (size_t k = 0; k < (size_t)SB * RB * 3; k++) a->H[k] = a->tunes ? a->alpha * a->Hn[k] + (1 - a->alpha) * a->H[k] : a->Hn[k];
    a->wlen = a->tunes ? a->alpha * (double)a->nw + (1 - a->alpha) * a->wlen : (double)a->nw;
    hm_clear(&a->idx); a->nobj = 0; a->ubytes = 0;
    int nc = 0;
    for (size_t k = 0; k < (size_t)SB * RB; k++) {
        const double *x = &a->H[k * 3];
        if (x[0] > 1e-9) a->cell[nc++] = (cell_t){x[0], x[1] / x[0], x[2] / x[0]};
    }
    for (int j = 0; j < a->ncand; j++) a->curve[j] = a->score[j] = predict(a->cell, nc, exp2(a->hi - j * a->step), a->cap, a->hz * a->wlen);
}

static void tune(admission_t *a) {
    if (a->model) model_curve(a);
    else for (int j = 0; j < a->ncand; j++) {
        a->curve[j] = a->look > 0 ? a->mc[j].h / a->look : 0;
        a->score[j] = a->tunes ? a->alpha * a->curve[j] + (1 - a->alpha) * a->score[j] : a->curve[j];
        a->mc[j].h = 0;
    }
    a->look = 0; a->nw = 0;
    int b = 0;
    for (int j = 1; j < a->ncand; j++) if (a->score[j] > a->score[b] + 1e-12) b = j;   /* j = 0 が最大の c */
    double lc = a->hi - b * a->step;
    a->c = exp2(lc); a->tunes++;
    a->sum_lc += lc; a->sum_best += a->score[b];
    if (lc < a->min_lc) a->min_lc = lc;
    if (lc > a->max_lc) a->max_lc = lc;
    GROW(a->tr, a->tcap, a->tn + 3);
    a->tr[a->tn++] = (double)a->n; a->tr[a->tn++] = lc; a->tr[a->tn++] = a->score[b];
}

static void on_lookup(admission_t *a, uint64_t t, uint64_t id, uint32_t size) {
    (void)t;
    a->n++; a->nw++;
    if (a->model) {
        uint64_t *p = hm_get(&a->idx, id);
        if (p) a->ob[*p].cnt++;
        else {
            GROW(a->ob, a->ocap, a->nobj + 1);
            a->ob[a->nobj] = (ob_t){1, size}; hm_put(&a->idx, id, a->nobj++);
            a->ubytes += size;
        }
        if (a->nw >= a->interval && a->ubytes >= a->win * a->cap) tune(a);
    } else {
        if (splitmix64(id ^ 0xada9751ebULL) <= a->thr) sim_lookup(a, id, size);
        if (a->nw >= a->interval) tune(a);
    }
}
static int accept(admission_t *a, const admit_info_t *in) { return rng_double(a->rng) < exp(-(double)in->size / a->c); }

static void report(admission_t *a, FILE *f) {
    fprintf(f, "{ \"name\": \"adaptsize\", \"tuner\": \"%s\", \"tunes\": %lu, \"c_final\": %.0f",
            a->model ? "model" : "sim", (unsigned long)a->tunes, a->c);
    if (a->tunes) fprintf(f, ", \"log2_c_mean\": %.4f, \"log2_c_min\": %.2f, \"log2_c_max\": %.2f, \"score_mean\": %.6f",
                          a->sum_lc / (double)a->tunes, a->min_lc, a->max_lc, a->sum_best / (double)a->tunes);
    fputs(", \"last_curve\": [", f);
    for (int j = 0; a->tunes && j < a->ncand; j++) fprintf(f, "%s[%.2f, %.6f]", j ? ", " : "", a->hi - j * a->step, a->curve[j]);
    fputs("], \"trace\": [", f);
    for (uint64_t i = 0; i < a->tn; i += 3) fprintf(f, "%s[%.0f, %.2f, %.6f]", i ? ", " : "", a->tr[i], a->tr[i + 1], a->tr[i + 2]);
    fputs("] }", f);
}

const admission_ops_t adm_adaptsize_ops = {"adaptsize", P, create, destroy, accept, NULL, on_lookup, report};
