/* tinylfu.c — TinyLFU 型の受け入れ（§8.2、v0.2.6）。SSD 参照（DRAM ミス）ごとに、4 行の count-min sketch（8 ビットの
 * 飽和カウンタ、行ごとに独立なハッシュ）に id を数え、SSD 参照 window 回ごとに全カウンタを半分にする（老化）。
 * 推定回数（4 行の最小）が thr 以上なら受け入れる。元の TinyLFU は追い出し候補と頻度を比べるが、Region 方式では
 * 受け入れの時点で候補が 1 つに決まらないので、閾値と比べる形にした（flash キャッシュでの頻度による受け入れの代表）。 */
#include "../plugin.h"

struct admission { uint8_t *c; uint64_t w, mask, window, n; uint32_t thr; };
static const param_spec_t P[] = {
    {"width", P_UINT, "16777216", NULL, "1 行のカウンタ数（2 の冪）"},
    {"window", P_UINT, "10000000", NULL, "老化の間隔（SSD 参照の回数）"},
    {"thr", P_UINT, "2", NULL, "受け入れる推定回数の下限"}, {NULL}};

static int create(admission_t **out, const param_vals_t *v, const admission_env_t *e) {
    (void)e;
    admission_t *a = xcalloc(1, sizeof *a);
    a->w = (uint64_t)pv_int(v, "width"); a->window = (uint64_t)pv_int(v, "window"); a->thr = (uint32_t)pv_int(v, "thr");
    if (!a->w || (a->w & (a->w - 1)) || !a->window || !a->thr) die("tinylfu: width must be a power of two, window and thr > 0");
    a->mask = a->w - 1; a->c = xcalloc(4 * a->w, 1);
    *out = a;
    return 0;
}
static void destroy(admission_t *a) { free(a->c); free(a); }
static uint64_t slot(const admission_t *a, uint64_t id, int r) { return (uint64_t)r * a->w + (splitmix64(id + 0x9e3779b97f4a7c15ULL * (uint64_t)(r + 1)) & a->mask); }
static void on_lookup(admission_t *a, uint64_t t, uint64_t id, uint32_t size) {
    (void)t; (void)size;
    for (int r = 0; r < 4; r++) { uint8_t *x = &a->c[slot(a, id, r)]; if (*x < 255) (*x)++; }
    if (++a->n % a->window == 0) for (uint64_t i = 0; i < 4 * a->w; i++) a->c[i] >>= 1;
}
static int accept(admission_t *a, const admit_info_t *in) {
    uint32_t m = 255;
    for (int r = 0; r < 4; r++) { uint8_t x = a->c[slot(a, in->id, r)]; if (x < m) m = x; }
    return m >= a->thr;
}
static void report(admission_t *a, FILE *f) {
    fprintf(f, "{ \"name\": \"tinylfu\", \"lookups\": %lu, \"agings\": %lu }", (unsigned long)a->n, (unsigned long)(a->n / a->window));
}

const admission_ops_t adm_tinylfu_ops = {"tinylfu", P, create, destroy, accept, NULL, on_lookup, report};
