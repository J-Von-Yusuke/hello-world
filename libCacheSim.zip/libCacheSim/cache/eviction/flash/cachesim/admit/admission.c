/* admission.c — SSD 受け入れ方針 all / prob / sizemax / sizeexp / seen（§8.2） */
#include "../plugin.h"
#include "../hashmap.h"

struct admission {
    int kind; double p, c; uint64_t max; rng_t *rng;
    uint64_t *ring, m, head, len; hmap_t cnt;      /* seen: 直近 m 件の id と出現回数 */
};
enum { A_ALL, A_PROB, A_SIZEMAX, A_SIZEEXP, A_SEEN };
static const param_spec_t P_NONE[] = {{NULL}};
static const param_spec_t P_PROB[] = {{"p", P_DOUBLE, "1.0", NULL, "受け入れ確率"}, {NULL}};
static const param_spec_t P_SMAX[] = {{"max", P_BYTES, "1M", NULL, "s ≤ max なら受け入れ"}, {NULL}};
static const param_spec_t P_SEXP[] = {{"c", P_BYTES, "64K", NULL, "確率 exp(−s/c)"}, {NULL}};
static const param_spec_t P_SEEN[] = {{"m", P_UINT, "100000", NULL, "記憶する直近の件数"}, {NULL}};

static admission_t *mk(int kind, const admission_env_t *e) { admission_t *a = xcalloc(1, sizeof(*a)); a->kind = kind; a->rng = e->rng; return a; }
static int c_all(admission_t **a, const param_vals_t *v, const admission_env_t *r) { (void)v; *a = mk(A_ALL, r); return 0; }
static int c_prob(admission_t **a, const param_vals_t *v, const admission_env_t *r) { *a = mk(A_PROB, r); (*a)->p = pv_dbl(v, "p"); return 0; }
static int c_smax(admission_t **a, const param_vals_t *v, const admission_env_t *r) { *a = mk(A_SIZEMAX, r); (*a)->max = (uint64_t)pv_int(v, "max"); return 0; }
static int c_sexp(admission_t **a, const param_vals_t *v, const admission_env_t *r) {
    *a = mk(A_SIZEEXP, r); (*a)->c = (double)pv_int(v, "c");
    if ((*a)->c <= 0) die("sizeexp: c must be > 0");
    return 0;
}
static int c_seen(admission_t **a, const param_vals_t *v, const admission_env_t *r) {
    admission_t *x = mk(A_SEEN, r);
    x->m = (uint64_t)pv_int(v, "m");
    if (!x->m) die("seen: m must be > 0");
    x->ring = xmalloc(x->m * 8); hm_init(&x->cnt, x->m * 2);
    *a = x;
    return 0;
}
static void destroy(admission_t *a) { free(a->ring); if (a->cnt.cap) hm_free(&a->cnt); free(a); }

static uint64_t seen_cnt(admission_t *a, uint64_t id) { uint64_t *c = hm_get(&a->cnt, id); return c ? *c : 0; }
/* ring は (head, len) の循環バッファ。満杯なら最古を落としてから足す */
static void seen_record(admission_t *a, uint64_t id) {
    if (a->len == a->m) {
        uint64_t old = a->ring[a->head], *c = hm_get(&a->cnt, old);
        if (--*c == 0) hm_del(&a->cnt, old);
        a->head = (a->head + 1) % a->m; a->len--;
    }
    a->ring[(a->head + a->len++) % a->m] = id;
    uint64_t *c = hm_get(&a->cnt, id);
    if (c) (*c)++; else hm_put(&a->cnt, id, 1);
}

static int accept(admission_t *a, const admit_info_t *in) {
    switch (a->kind) {
    case A_PROB:    return rng_double(a->rng) < a->p;
    case A_SIZEMAX: return in->size <= a->max;
    case A_SIZEEXP: return rng_double(a->rng) < exp(-(double)in->size / a->c);
    case A_SEEN:
        /* DRAM 追い出し由来: on_dram_evict が今回の分を記録済みなので 2 回目以上で受け入れ。
         * DRAM なし（ミス由来）: ミスを記録し、記録前に 1 回以上あれば受け入れ。再挿入は常に受け入れ。 */
        if (in->source == SRC_DRAM_EVICT) return seen_cnt(a, in->id) >= 2;
        if (in->source == SRC_MISS) { int ok = seen_cnt(a, in->id) >= 1; seen_record(a, in->id); return ok; }
        return 1;
    default: return 1;
    }
}
static void on_dram_evict(admission_t *a, uint64_t id, uint32_t size) { (void)size; if (a->kind == A_SEEN) seen_record(a, id); }

const admission_ops_t adm_all_ops     = {"all",     P_NONE, c_all,  destroy, accept, NULL, NULL, NULL};
const admission_ops_t adm_prob_ops    = {"prob",    P_PROB, c_prob, destroy, accept, NULL, NULL, NULL};
const admission_ops_t adm_sizemax_ops = {"sizemax", P_SMAX, c_smax, destroy, accept, NULL, NULL, NULL};
const admission_ops_t adm_sizeexp_ops = {"sizeexp", P_SEXP, c_sexp, destroy, accept, NULL, NULL, NULL};
const admission_ops_t adm_seen_ops    = {"seen",    P_SEEN, c_seen, destroy, accept, on_dram_evict, NULL, NULL};
