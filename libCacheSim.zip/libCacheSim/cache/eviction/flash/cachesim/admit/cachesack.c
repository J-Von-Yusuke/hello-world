/* cachesack.c — CacheSack（Yang ほか, USENIX ATC 2022）の受け入れ（§8.2）。
 * 物をサイズの分類 c = ⌊log2 s ÷ oct⌋ に分け（元論文の分類は表名などのメタデータ）、分類ごとに受け入れ方
 * NeverAdmit（NA）・AdmitOnSecondMiss（AOSM、LARC）・AdmitOnMiss（AOM）を割合で混ぜる。AdmitOnWrite は
 * get だけのトレースでは AOM と同じなので持たない。flash の下のバッファキャッシュはないので、flash のミスはすべて裏へ行く。
 * 推定（元論文の付録 A.2）: SSD 参照（DRAM ミス）の列で、物ごとに直前 2 回の参照時刻を幽霊表に持ち、間隔 d_i で
 *   保持時間 D の TTL 近似（LRU）をとる。AOM: d_i > D でミスかつ書き込み、占有 s·min(d_i, D)。
 *   AOSM: max(d_{i−1}, d_i) > D でミス、d_i ≤ D < d_{i−1} で書き込み（占有 s·D）、ヒットなら占有 s·d_i。NA: すべてミス。
 *   D は格子 D_k = dmin·r^k（k < nd）。d は D_k について区分定数なので、差分配列で 1 参照 O(1) で全 D に足す。
 * 最適化（付録 A.3〜A.5）: 費用 V = ミス + w × 書き込みバイト ÷ 単位（miss=obj なら単位 = SSD 参照の平均サイズ、byte なら 1）。
 *   各 D_k で分類ごとの点 (占有, V) の下側凸包を作り、傾きが負の線分を傾きの小さい順に、容量 = SSD 容量 × 窓の長さまで取る。
 *   費用が最小の D_k を採り、そのときの割合を使う。統計は SSD 参照 interval 回ごとに重み alpha で指数移動平均する。
 * 実行: 物 id のハッシュ u ∈ [0, 1) で、u < f_NA なら NA、u < f_NA + f_AOSM なら AOSM、それ以外は AOM。
 *   サイズが変わった物は、シミュレータと同じく別の物として履歴を捨てる（元論文のブロックは不変）。
 *   AOSM は直前 2 回の参照の間隔が D* 以下なら受け入れる。最初の最適化までは AOM。幽霊表は最後の参照が 2·D* より古い物を捨てる。 */
#include "../plugin.h"
#include "../hashmap.h"

#define NCAT 64
enum { NA, AOSM, AOM, NP };
enum { Q_S_AOM, Q_W_AOM, Q_UD_AOM, Q_UC_AOM, Q_S_SM, Q_W_SM, Q_UD_SM, Q_UC_SM, Q_S_NA, NQ };   /* 差分配列 */
enum { M_S, M_W, M_U, NM };                                                                   /* 推定値 */
typedef struct { double slope, du, dv; int c, i; } seg_t;
typedef struct { double u, v; int p; } pt_t;
typedef struct { uint64_t id, last, prev; uint32_t size; } gh_t;   /* last・prev = 0 は「なし」（時刻は 1 から） */
struct admission {
    double cap, w, alpha, dmin, ratio, *D; int nd, oct, bytes;
    uint64_t interval, nw, n, tunes, t0, tnow;
    hmap_t g; gh_t *gh; uint64_t gn, gcap, gkeep; double gttl;               /* 幽霊表（id → gh の添字）。gkeep = 前回の掃除後の数 */
    double *acc, *ew, look, lookb, ewspan, ewlook, ewlookb;                  /* acc [NCAT][NQ][nd+1]、ew [NCAT][NP][NM][nd] */
    double frac[NCAT][NP]; int kstar; double pred_hit, pred_wr;
    seg_t *seg; pt_t hv[NCAT][NP]; int nh[NCAT], take[NCAT]; double part[NCAT];
    double *tr; uint64_t tcap, tn;
};
static const param_spec_t P[] = {
    {"w", P_DOUBLE, "1", NULL, "書き込みの費用（単位の書き込み 1 回 = ミス何回分か）"},
    {"miss", P_ENUM, "obj", "obj|byte", "ミスの数え方（obj = 回数、byte = バイト）"},
    {"oct", P_UINT, "1", NULL, "分類の幅（log2 サイズのオクターブ数）"},
    {"interval", P_UINT, "1000000", NULL, "最適化の間隔（SSD 参照の回数）"},
    {"alpha", P_DOUBLE, "0.5", NULL, "新しい窓の重み（指数移動平均）"},
    {"dmin", P_DOUBLE, "1000", NULL, "保持時間 D の格子の最小（要求数）"},
    {"dmax", P_DOUBLE, "1e10", NULL, "保持時間 D の格子の最大（要求数）"},
    {"nd", P_UINT, "128", NULL, "保持時間 D の格子の数（等比）"},
    {NULL}};

#define ACC(a, c, q) (&(a)->acc[((size_t)(c) * NQ + (q)) * (size_t)((a)->nd + 1)])
#define EW(a, c, p, m) (&(a)->ew[(((size_t)(c) * NP + (p)) * NM + (m)) * (size_t)(a)->nd])

static int create(admission_t **out, const param_vals_t *v, const admission_env_t *e) {
    admission_t *a = xcalloc(1, sizeof *a);
    double dmax;
    a->cap = (double)e->ssd_bytes; a->w = pv_dbl(v, "w"); a->bytes = !strcmp(pv_str(v, "miss"), "byte");
    a->oct = (int)pv_int(v, "oct"); a->interval = (uint64_t)pv_int(v, "interval"); a->alpha = pv_dbl(v, "alpha");
    a->dmin = pv_dbl(v, "dmin"); dmax = pv_dbl(v, "dmax"); a->nd = (int)pv_int(v, "nd");
    if (!(a->w >= 0) || a->oct < 1 || !a->interval || !(a->alpha > 0 && a->alpha <= 1) || !(a->dmin > 0) || !(dmax > a->dmin)
        || a->nd < 2 || !(a->cap > 0))
        die("cachesack: need w >= 0, oct >= 1, interval > 0, 0 < alpha <= 1, 0 < dmin < dmax, nd >= 2 and an SSD");
    a->ratio = pow(dmax / a->dmin, 1.0 / (a->nd - 1));
    a->D = xmalloc((size_t)a->nd * 8);
    for (int k = 0; k < a->nd; k++) a->D[k] = a->dmin * pow(a->ratio, k);
    a->acc = xcalloc((size_t)NCAT * NQ * (size_t)(a->nd + 1), 8);
    a->ew = xcalloc((size_t)NCAT * NP * NM * (size_t)a->nd, 8);
    a->seg = xmalloc((size_t)NCAT * NP * sizeof(seg_t));
    a->gttl = INFINITY; a->kstar = -1; a->gkeep = 1 << 20;
    hm_init(&a->g, 1024);
    *out = a;
    return 0;
}
static void destroy(admission_t *a) {
    hm_free(&a->g); free(a->gh); free(a->D); free(a->acc); free(a->ew); free(a->seg); free(a->tr); free(a);
}

static int cat_of(const admission_t *a, uint32_t s) { int c = ilog2_u64(s ? s : 1) / a->oct; return c < NCAT ? c : NCAT - 1; }
/* 最初の D_k ≥ x の k（x = ∞ なら nd）。D_k < x ⇔ k < idx(x) */
static int idx(const admission_t *a, double x) {
    if (!(x < INFINITY)) return a->nd;
    if (x <= a->D[0]) return 0;
    int k = (int)ceil(log(x / a->dmin) / log(a->ratio));
    if (k > a->nd) k = a->nd;
    while (k > 0 && a->D[k - 1] >= x) k--;
    while (k < a->nd && a->D[k] < x) k++;
    return k;
}
static void radd(double *d, int lo, int hi, double v) { if (lo < hi) { d[lo] += v; d[hi] -= v; } }

static int cmp_seg(const void *x, const void *y) {
    const seg_t *p = x, *q = y;
    if (p->slope != q->slope) return p->slope < q->slope ? -1 : 1;
    if (p->c != q->c) return p->c - q->c;
    return p->i - q->i;
}
/* D_k での最小費用。分類ごとに (占有, 費用) の下側凸包を作り、傾きが負の線分を傾きの小さい順に容量 ucap まで取る。
 * record なら分類ごとに取った線分の数（take）と途中の割合（part）を残す */
static double solve_k(admission_t *a, int k, double ucap, int record) {
    double base = 0, used = 0, unit = a->bytes ? 1 : (a->ewlook > 0 ? a->ewlookb / a->ewlook : 1);
    int ns = 0;
    for (int c = 0; c < NCAT; c++) {
        a->nh[c] = 0;
        if (!(EW(a, c, NA, M_S)[0] > 0)) continue;           /* 参照のない分類 */
        pt_t pt[NP];
        for (int p = 0; p < NP; p++)
            pt[p] = p == NA ? (pt_t){0, EW(a, c, NA, M_S)[0], NA}
                            : (pt_t){EW(a, c, p, M_U)[k], EW(a, c, p, M_S)[k] + a->w * EW(a, c, p, M_W)[k] / unit, p};
        for (int i = 1; i < NP; i++)                           /* (占有, 費用) の順に並べる */
            for (int j = i; j > 0 && (pt[j].u < pt[j - 1].u || (pt[j].u == pt[j - 1].u && pt[j].v < pt[j - 1].v)); j--) {
                pt_t t = pt[j]; pt[j] = pt[j - 1]; pt[j - 1] = t;
            }
        int h = 0;
        for (int i = 0; i < NP; i++) {                         /* Andrew の単調鎖（下側） */
            while (h >= 2) {
                pt_t o = a->hv[c][h - 2], b = a->hv[c][h - 1];
                if ((b.u - o.u) * (pt[i].v - o.v) - (b.v - o.v) * (pt[i].u - o.u) <= 0) h--; else break;
            }
            a->hv[c][h++] = pt[i];
        }
        a->nh[c] = h;
        base += a->hv[c][0].v; used += a->hv[c][0].u;
        for (int i = 0; i + 1 < h; i++) {
            double du = a->hv[c][i + 1].u - a->hv[c][i].u, dv = a->hv[c][i + 1].v - a->hv[c][i].v;
            if (!(du > 0) || !(dv < 0)) break;
            a->seg[ns++] = (seg_t){dv / du, du, dv, c, i};
        }
    }
    qsort(a->seg, (size_t)ns, sizeof(seg_t), cmp_seg);
    double rem = ucap - used, cost = base;
    if (record) for (int c = 0; c < NCAT; c++) { a->take[c] = 0; a->part[c] = 0; }
    for (int s = 0; s < ns && rem > 0; s++) {
        double f = a->seg[s].du <= rem ? 1 : rem / a->seg[s].du;
        cost += f * a->seg[s].dv; rem -= f * a->seg[s].du;
        if (record) { if (f >= 1) a->take[a->seg[s].c]++; else a->part[a->seg[s].c] = f; }
    }
    return cost;
}

/* 幽霊表から最後の参照が 2·D* より古い物を捨てる（添字を詰め直す）。表が前回の掃除後の 2 倍になったときだけ行う
 * （毎回だと 1 参照あたり O(表の大きさ ÷ interval) かかり、w01 では遅すぎた）。古い履歴を長く持つだけなので推定は悪くならない */
static void ghost_prune(admission_t *a) {
    if (!(a->gttl < INFINITY)) return;
    uint64_t m = 0;
    hm_clear(&a->g);
    for (uint64_t i = 0; i < a->gn; i++) {
        if ((double)(a->tnow - a->gh[i].last) > a->gttl) continue;
        a->gh[m] = a->gh[i]; hm_put(&a->g, a->gh[m].id, m); m++;
    }
    a->gn = m;
}

static void tune(admission_t *a) {
    double span = (double)(a->tnow - a->t0);
    for (int c = 0; c < NCAT; c++) {
        double run[NQ];
        for (int q = 0; q < NQ; q++) run[q] = 0;
        double fresh[NP][NM];
        for (int k = 0; k < a->nd; k++) {
            for (int q = 0; q < NQ; q++) run[q] += ACC(a, c, q)[k];
            fresh[AOM][M_S] = run[Q_S_AOM]; fresh[AOM][M_W] = run[Q_W_AOM]; fresh[AOM][M_U] = run[Q_UD_AOM] * a->D[k] + run[Q_UC_AOM];
            fresh[AOSM][M_S] = run[Q_S_SM]; fresh[AOSM][M_W] = run[Q_W_SM]; fresh[AOSM][M_U] = run[Q_UD_SM] * a->D[k] + run[Q_UC_SM];
            fresh[NA][M_S] = run[Q_S_NA]; fresh[NA][M_W] = 0; fresh[NA][M_U] = 0;
            for (int p = 0; p < NP; p++)
                for (int m = 0; m < NM; m++) {
                    double *x = &EW(a, c, p, m)[k];
                    *x = a->tunes ? a->alpha * fresh[p][m] + (1 - a->alpha) * *x : fresh[p][m];
                }
        }
    }
    memset(a->acc, 0, (size_t)NCAT * NQ * (size_t)(a->nd + 1) * 8);
    a->ewspan = a->tunes ? a->alpha * span + (1 - a->alpha) * a->ewspan : span;
    a->ewlook = a->tunes ? a->alpha * a->look + (1 - a->alpha) * a->ewlook : a->look;
    a->ewlookb = a->tunes ? a->alpha * a->lookb + (1 - a->alpha) * a->ewlookb : a->lookb;
    a->look = a->lookb = 0; a->nw = 0; a->t0 = a->tnow;
    double ucap = a->cap * a->ewspan, best = INFINITY;
    int kb = 0;
    for (int k = 0; k < a->nd; k++) { double v = solve_k(a, k, ucap, 0); if (v < best) { best = v; kb = k; } }
    solve_k(a, kb, ucap, 1);
    double S = 0, W = 0;
    for (int c = 0; c < NCAT; c++) {
        double *f = a->frac[c];
        f[NA] = f[AOSM] = 0; f[AOM] = 1;                       /* 参照のない分類は AOM */
        if (!a->nh[c]) continue;
        f[AOM] = 0;
        int i = a->take[c];
        double pf = a->part[c];
        f[a->hv[c][i].p] += 1 - pf;
        if (pf > 0) f[a->hv[c][i + 1].p] += pf;
        for (int p = 0; p < NP; p++) {
            S += f[p] * (p == NA ? EW(a, c, NA, M_S)[0] : EW(a, c, p, M_S)[kb]);
            W += f[p] * (p == NA ? 0 : EW(a, c, p, M_W)[kb]);
        }
    }
    a->kstar = kb; a->gttl = 2 * a->D[kb]; a->tunes++;
    a->pred_hit = a->ewlook > 0 && !a->bytes ? 1 - S / a->ewlook : a->ewlookb > 0 ? 1 - S / a->ewlookb : 0;
    a->pred_wr = a->ewlookb > 0 ? W / a->ewlookb : 0;
    GROW(a->tr, a->tcap, a->tn + 4);
    a->tr[a->tn++] = (double)a->n; a->tr[a->tn++] = log2(a->D[kb]); a->tr[a->tn++] = a->pred_hit; a->tr[a->tn++] = a->pred_wr;
    if (a->gn >= 2 * a->gkeep) { ghost_prune(a); if (a->gn > a->gkeep) a->gkeep = a->gn; }
}

static void on_lookup(admission_t *a, uint64_t t0, uint64_t id, uint32_t size) {
    uint64_t t = t0 + 1;                                           /* 0 を「なし」に使うので 1 から数える */
    uint64_t *p = hm_get(&a->g, id);
    gh_t *x;
    if (p) x = &a->gh[*p];
    else { GROW(a->gh, a->gcap, a->gn + 1); x = &a->gh[a->gn]; *x = (gh_t){id, 0, 0, size}; hm_put(&a->g, id, a->gn++); }
    if (x->size != size) { x->last = x->prev = 0; x->size = size; }   /* サイズが変われば別の物（シミュレータと同じ。§3.3） */
    double s = size, m = a->bytes ? s : 1;
    double d = x->last ? (double)(t - x->last) : INFINITY, dp = x->last && x->prev ? (double)(x->last - x->prev) : INFINITY;
    int c = cat_of(a, size), jd = idx(a, d), jp = idx(a, dp), jm = jd > jp ? jd : jp, nd = a->nd;
    radd(ACC(a, c, Q_S_AOM), 0, jd, m); radd(ACC(a, c, Q_W_AOM), 0, jd, s); radd(ACC(a, c, Q_UD_AOM), 0, jd, s);
    if (jd < nd) radd(ACC(a, c, Q_UC_AOM), jd, nd, s * d);
    radd(ACC(a, c, Q_S_SM), 0, jm, m); radd(ACC(a, c, Q_W_SM), jd, jp, s); radd(ACC(a, c, Q_UD_SM), jd, jp, s);
    if (jm < nd) radd(ACC(a, c, Q_UC_SM), jm, nd, s * d);
    radd(ACC(a, c, Q_S_NA), 0, nd, m);
    if (!a->n++) a->t0 = t - 1;
    x->prev = x->last; x->last = t;
    a->look++; a->lookb += s; a->tnow = t;
    if (++a->nw >= a->interval) tune(a);
}
static int accept(admission_t *a, const admit_info_t *in) {
    if (!a->tunes) return 1;
    const double *f = a->frac[cat_of(a, in->size)];
    double u = (double)(splitmix64(in->id ^ 0xcac4e5acULL) >> 11) * 0x1.0p-53;
    if (u < f[NA]) return 0;
    if (u >= f[NA] + f[AOSM]) return 1;
    uint64_t *p = hm_get(&a->g, in->id);                           /* AOSM: 直前 2 回の参照が D* 以内 */
    return p && a->gh[*p].prev && (double)(a->gh[*p].last - a->gh[*p].prev) <= a->D[a->kstar];
}

static void report(admission_t *a, FILE *f) {
    fprintf(f, "{ \"name\": \"cachesack\", \"tunes\": %lu, \"w\": %.6g, \"miss\": \"%s\"", (unsigned long)a->tunes, a->w, a->bytes ? "byte" : "obj");
    if (a->tunes) fprintf(f, ", \"d_star\": %.6g, \"pred_hit\": %.6f, \"pred_write_ratio\": %.6f, \"ghost_objs\": %lu",
                          a->D[a->kstar], a->pred_hit, a->pred_wr, (unsigned long)a->gn);
    fputs(", \"frac\": [", f);
    int first = 1;
    for (int c = 0; a->tunes && c < NCAT; c++) {
        if (!a->nh[c]) continue;
        fprintf(f, "%s[%llu, %.4f, %.4f, %.4f]", first ? "" : ", ", (unsigned long long)1 << (c * a->oct),
                a->frac[c][NA], a->frac[c][AOSM], a->frac[c][AOM]);
        first = 0;
    }
    fputs("], \"trace\": [", f);
    for (uint64_t i = 0; i < a->tn; i += 4)
        fprintf(f, "%s[%.0f, %.2f, %.6f, %.6f]", i ? ", " : "", a->tr[i], a->tr[i + 1], a->tr[i + 2], a->tr[i + 3]);
    fputs("] }", f);
}

const admission_ops_t adm_cachesack_ops = {"cachesack", P, create, destroy, accept, NULL, on_lookup, report};
