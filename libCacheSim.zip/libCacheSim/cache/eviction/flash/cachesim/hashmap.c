#include "hashmap.h"
#include "rng.h"

void hm_init(hmap_t *m, uint64_t cap_hint) {
    uint64_t c = 16;
    while (c < cap_hint) c <<= 1;
    m->cap = c; m->mask = c - 1; m->n = 0;
    m->k = xmalloc(c * 8); m->v = xmalloc(c * 8); m->u = xcalloc(c, 1);
}
void hm_free(hmap_t *m) { free(m->k); free(m->v); free(m->u); memset(m, 0, sizeof(*m)); }
void hm_clear(hmap_t *m) { memset(m->u, 0, m->cap); m->n = 0; }

static inline uint64_t home(const hmap_t *m, uint64_t key) { return splitmix64(key) & m->mask; }

uint64_t *hm_get(const hmap_t *m, uint64_t key) {
    for (uint64_t i = home(m, key);; i = (i + 1) & m->mask) {
        if (!m->u[i]) return NULL;
        if (m->k[i] == key) return &m->v[i];
    }
}

static void grow(hmap_t *m) {
    hmap_t o = *m;
    hm_init(m, o.cap * 2);
    for (uint64_t i = 0; i < o.cap; i++) if (o.u[i]) hm_put(m, o.k[i], o.v[i]);
    hm_free(&o);
}

void hm_put(hmap_t *m, uint64_t key, uint64_t val) {
    if ((m->n + 1) * 10 > m->cap * 7) grow(m);
    uint64_t i = home(m, key);
    for (; m->u[i]; i = (i + 1) & m->mask)
        if (m->k[i] == key) { m->v[i] = val; return; }
    m->u[i] = 1; m->k[i] = key; m->v[i] = val; m->n++;
}

int hm_del(hmap_t *m, uint64_t key) {
    uint64_t i = home(m, key);
    for (;; i = (i + 1) & m->mask) {
        if (!m->u[i]) return 0;
        if (m->k[i] == key) break;
    }
    /* 後方シフト: 空きスロット i を、そこへ戻れる後続要素で埋めていく */
    for (uint64_t j = (i + 1) & m->mask; m->u[j]; j = (j + 1) & m->mask) {
        uint64_t h = home(m, m->k[j]);
        if (((j - h) & m->mask) >= ((j - i) & m->mask)) {
            m->k[i] = m->k[j]; m->v[i] = m->v[j]; i = j;
        }
    }
    m->u[i] = 0; m->n--;
    return 1;
}
