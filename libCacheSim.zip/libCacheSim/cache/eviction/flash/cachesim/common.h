/* common.h — 層に共通の型と小道具（DESIGN.md §5） */
#ifndef COMMON_H
#define COMMON_H
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define NONE32       UINT32_MAX
#define NEXT_UNKNOWN INT64_MIN   /* トレースに次アクセス情報がない */
#define NEXT_NONE    (-1)        /* 次アクセスなし（--oracle-none の値もここへ正規化） */
#define KMAX_LIMIT   64          /* --k-max の上限（cls は uint8_t） */

enum { F_IN_DRAM = 1, F_SSD_VALID = 2, F_SSD_COPY_LOST = 4, F_CHUNKED = 8 };   /* F_CHUNKED: SSD 上は piece-wise */
enum { SRC_DRAM_EVICT = 0, SRC_MISS = 1, SRC_REINSERT = 2 };
enum { R_FREE = 0, R_OPEN = 1, R_SEALED = 2 };

typedef struct {
    uint64_t id;
    uint32_t size;
    uint32_t flags;          /* F_IN_DRAM, F_SSD_VALID, F_SSD_COPY_LOST */
    uint32_t ssd_loc;        /* Region を使うモード: region 添字 */
    uint32_t ssd_pos;        /* その Region の objs[] での位置（古い記録と今の記録を見分ける） */
    uint8_t  cls;            /* SSD 受け入れ時にヒント提供器が返した分類 */
    uint8_t  dram_hits;      /* DRAM に入ってからの DRAM ヒット数（飽和加算） */
    uint16_t ssd_hits;       /* SSD 受け入れ以降の SSD ヒット数（飽和加算） */
    uint32_t hint_epoch;     /* 受け入れ時のエポック */
    uint64_t ssd_admit_t;    /* SSD に入った論理時刻 */
    int64_t  next_access;    /* オラクル情報。なければ NEXT_UNKNOWN */
} obj_t;
_Static_assert(sizeof(obj_t) == 48, "obj_t must stay 48 bytes");

typedef struct {
    uint8_t  state;          /* R_FREE / R_OPEN / R_SEALED */
    uint8_t  cls;
    uint32_t epoch;          /* 開いたときのエポック */
    uint64_t used_bytes;     /* 書き込み位置（詰めたバイト数） */
    uint64_t valid_bytes;    /* 現在有効なバイト */
    uint32_t nobj, nvalid;
    uint64_t open_t, seal_t, last_touch_t;
    uint64_t touches;        /* この Region への SSD ヒット回数 */
    uint32_t *objs;          /* 書き込まれたオブジェクト添字（無効化済みも含む） */
    uint32_t objs_len, objs_cap;
} region_t;

__attribute__((noreturn, format(printf, 1, 2))) void die(const char *fmt, ...);
void *xmalloc(size_t n);
void *xcalloc(size_t n, size_t sz);
void *xrealloc(void *p, size_t n);
char *xstrdup(const char *s);

/* 配列の倍増（要求ごとの malloc を避けるための唯一の確保手段） */
#define GROW(p, cap, need) do { if ((size_t)(need) > (size_t)(cap)) {                 \
    size_t _c = (cap) ? (size_t)(cap) : 16; while (_c < (size_t)(need)) _c *= 2;       \
    (p) = xrealloc((p), _c * sizeof(*(p))); (cap) = _c; } } while (0)

static inline int ilog2_u64(uint64_t x) { return x ? 63 - __builtin_clzll(x) : 0; }

#endif
