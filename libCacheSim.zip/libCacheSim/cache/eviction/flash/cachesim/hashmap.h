/* hashmap.h — uint64 → uint64。オープンアドレス・線形探索・後方シフト削除（墓石なし）、
 * ハッシュは splitmix64、負荷率 0.7 で倍増（DESIGN.md §5.2） */
#ifndef HASHMAP_H
#define HASHMAP_H
#include "common.h"

typedef struct { uint64_t *k, *v; uint8_t *u; uint64_t cap, mask, n; } hmap_t;

void      hm_init(hmap_t *m, uint64_t cap_hint);
void      hm_free(hmap_t *m);
uint64_t *hm_get(const hmap_t *m, uint64_t key);           /* 値へのポインタ（次の put まで有効）／なければ NULL */
void      hm_put(hmap_t *m, uint64_t key, uint64_t val);   /* 挿入または上書き */
int       hm_del(hmap_t *m, uint64_t key);                 /* 1 = 消した */
void      hm_clear(hmap_t *m);                             /* 全削除（容量はそのまま） */
#endif
