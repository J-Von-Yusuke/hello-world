/* plugin.h — 4 種類のプラグイン・インターフェース（DESIGN.md §6） */
#ifndef PLUGIN_H
#define PLUGIN_H
#include "common.h"
#include "params.h"
#include "rng.h"

/* ---- §6.1 オブジェクト単位の方針（DRAM 層と SSD object モードで共用） ---- */
typedef struct obj_policy obj_policy_t;
typedef struct {
    uint64_t capacity_bytes;
    const obj_t *(*obj)(uint32_t oid);
    rng_t *rng;
} obj_policy_env_t;
typedef struct {
    const char *name;
    const param_spec_t *params;
    int      (*create)(obj_policy_t **p, const param_vals_t *v, const obj_policy_env_t *env);
    void     (*destroy)(obj_policy_t *p);
    void     (*on_pool_resize)(obj_policy_t *p, uint32_t new_cap);
    void     (*on_insert)(obj_policy_t *p, uint32_t oid, uint64_t t);
    void     (*on_hit)(obj_policy_t *p, uint32_t oid, uint64_t t);
    uint32_t (*evict)(obj_policy_t *p, uint64_t t);
    void     (*on_remove)(obj_policy_t *p, uint32_t oid);
} obj_policy_ops_t;

/* ---- §6.2 Region 追い出し方針 ---- */
typedef struct region_policy region_policy_t;
typedef struct {
    uint32_t nregions;
    uint32_t k_max;
    const region_t *(*region)(uint32_t rid);
    double (*class_mean_size)(uint32_t cls);   /* データがなければ NAN */
    rng_t *rng;
} region_policy_env_t;
typedef struct {
    const char *name;
    const param_spec_t *params;
    int      (*create)(region_policy_t **rp, const param_vals_t *v, const region_policy_env_t *env);
    void     (*destroy)(region_policy_t *rp);
    void     (*on_seal)(region_policy_t *rp, uint32_t rid, uint64_t t);
    void     (*on_touch)(region_policy_t *rp, uint32_t rid, uint64_t t);
    uint32_t (*evict)(region_policy_t *rp, uint64_t t);
} region_policy_ops_t;

/* ---- §6.3 受け入れ方針 ---- */
typedef struct admission admission_t;
typedef struct {
    uint64_t t, id;
    uint32_t size;
    uint8_t  source;
    uint8_t  dram_hits;
} admit_info_t;
typedef struct {
    rng_t   *rng;
    uint64_t ssd_bytes;      /* SSD の容量（region は N·R、log は論理容量、ideal は --ssd-size）。0 = SSD なし */
    uint64_t ssd_max_obj;    /* SSD に入る物の最大サイズ */
} admission_env_t;
typedef struct {
    const char *name;
    const param_spec_t *params;
    int  (*create)(admission_t **a, const param_vals_t *v, const admission_env_t *env);
    void (*destroy)(admission_t *a);
    int  (*accept)(admission_t *a, const admit_info_t *info);
    /* ---- 以下は任意（NULL 可） ---- */
    void (*on_dram_evict)(admission_t *a, uint64_t id, uint32_t size);
    void (*on_lookup)(admission_t *a, uint64_t t, uint64_t id, uint32_t size);   /* SSD 参照（DRAM ミス）ごと。ヒットかどうかは問わない */
    void (*report)(admission_t *a, FILE *f);                             /* summary.json の admit_result に JSON の値を 1 つ書く */
} admission_ops_t;

/* ---- §6.4 ヒント提供器 ---- */
typedef struct hint hint_t;
typedef struct hint_log hint_log_t;
struct hint_stats;
typedef struct {
    uint32_t k_max;
    uint64_t region_size;
    double   sample;
    rng_t   *rng;
    hint_log_t *log;
} hint_env_t;
typedef struct {
    uint64_t t, id;
    uint32_t size;
    uint8_t  source;
    uint8_t  dram_hits;
    int64_t  next_dist;      /* オラクル: 次のアクセスまでの要求数（元のトレースで数える）。−1 = なし、−2 = 情報なし。
                                oracle_ で始まる提供器だけが使ってよい */
} hint_admit_t;
typedef struct {
    const char *name;
    const param_spec_t *params;
    int      (*create)(hint_t **h, const param_vals_t *v, const hint_env_t *env);
    void     (*destroy)(hint_t *h);
    uint32_t (*on_admit)(hint_t *h, const hint_admit_t *a);
    void     (*on_ssd_hit)(hint_t *h, uint64_t t, uint32_t size, uint32_t cls);
    void     (*on_ssd_evict)(hint_t *h, uint64_t t, uint32_t size, uint32_t cls, uint32_t freq, uint64_t residence);
    uint32_t (*epoch)(const hint_t *h);
    uint32_t (*bounds)(const hint_t *h, int64_t *tau_out, uint32_t max);
    uint32_t (*max_classes)(const hint_t *h);        /* 返しうる分類数の上限（--k-max auto はこれを使う） */
    /* ---- 以下は任意（NULL 可） ---- */
    /* 区間 i = (τ_{i−1}, τ_i] の分類を cls_out[i] に書く（i = 0..bounds の個数）。
     * NULL なら区間 i → 分類 i（サイズの小さい順の連続区間）。ヒット率で分ける提供器は同じ分類が飛び地になりうる */
    uint32_t (*classes)(const hint_t *h, uint8_t *cls_out, uint32_t max);
    /* 全要求の結果（HINT_MISS / HINT_DRAM_HIT / HINT_SSD_HIT）。サイズ帯別ヒット率を測る提供器が使う */
    void     (*on_request)(hint_t *h, uint64_t t, uint32_t size, int outcome);
    /* 全要求（id つき）。参照の履歴を鍵にする提供器が使う（v0.2.6） */
    void     (*on_access)(hint_t *h, uint64_t t, uint64_t id, uint32_t size, int outcome);
    /* summary.json の hint_result.report に JSON の値を 1 つ書く（v0.2.6） */
    void     (*report)(hint_t *h, FILE *f);
} hint_ops_t;
enum { HINT_MISS = 0, HINT_DRAM_HIT = 1, HINT_SSD_HIT = 2 };
#define HINT_MAX_IV 128                                /* bounds の個数の上限 */

/* hint_events.csv / hint_buckets.csv への出力口（§12.8。実装は output.c）
 * st[6] = st_threshold, st_count_p50, st_byte_p50, st_cold_byte_p50, st_mid, st_min_rule（不使用は -1） */
void hint_log_event(hint_log_t *lg, uint64_t t, uint64_t obs, uint32_t epoch, int changed,
                    const int64_t *taus, uint32_t ntau, const uint8_t *map, const int64_t st[6],
                    double sse_cur, double sse_new, const char *note);   /* map = NULL は恒等 */
/* hint_hr.csv: バケット別ヒット率の 1 行（st_hitrate が更新ごとに出す） */
void hint_log_hr(hint_log_t *lg, uint64_t seq, uint64_t t, int bucket, double lookups, double hits, double rate,
                 int valid, int hr_class, int cls);
/* hint_stats を持つ提供器が create 時に登録する（hint_buckets.csv の出力元） */
void hint_log_attach_stats(hint_log_t *lg, const struct hint_stats *hs, int stat, int weight,
                           double min_obs, double eps_log);

/* 分類 = |{ j : s > τ_j }|（SplitThreshold の poolOf と同じ「より大きい」規則） */
static inline uint32_t class_of_taus(const int64_t *taus, uint32_t n, uint64_t s) {
    uint32_t c = 0;
    while (c < n && (int64_t)s > taus[c]) c++;
    return c;
}

/* registry.c */
extern const obj_policy_ops_t    *OBJ_POLICIES[];
extern const region_policy_ops_t *REGION_POLICIES[];
extern const admission_ops_t     *ADMISSIONS[];
extern const hint_ops_t          *HINTS[];
const void *registry_find(int kind, const char *name, const param_spec_t **spec);  /* kind 0..3 */
void registry_print(FILE *f);
#endif
