#include "params.h"
#include <ctype.h>
#include <errno.h>

int parse_bytes(const char *s, uint64_t *out) {
    char *e; errno = 0;
    double x = strtod(s, &e);
    if (e == s || errno || x < 0) return 0;
    double mul = 1;
    switch (toupper((unsigned char)*e)) {
    case 'K': mul = 0x1p10; e++; break;
    case 'M': mul = 0x1p20; e++; break;
    case 'G': mul = 0x1p30; e++; break;
    case 'T': mul = 0x1p40; e++; break;
    }
    if (mul > 1 && *e == 'i') e++;
    if (*e == 'B' || *e == 'b') e++;
    if (*e) return 0;
    *out = (uint64_t)llround(x * mul);
    return 1;
}

void spec_split(const char *spec, char *name, size_t nsz, const char **rest) {
    const char *c = strchr(spec, ':');
    size_t n = c ? (size_t)(c - spec) : strlen(spec);
    if (n >= nsz) n = nsz - 1;
    memcpy(name, spec, n); name[n] = 0;
    *rest = c ? c + 1 : "";
}

/* 数値（リストの要素・実数引数）: 素の数、末尾 % は ÷100（"20%" = 0.2）、K/M/G/T は 2 進の倍数（"4K" = 4096） */
int parse_num(const char *s, double *out) {
    char *e; errno = 0;
    double x = strtod(s, &e);
    if (e == s || errno) return 0;
    if (*e == '%') { x /= 100; e++; }
    else if (*e) { uint64_t b; if (!parse_bytes(s, &b)) return 0; x = (double)b; e = (char *)s + strlen(s); }
    if (*e) return 0;
    *out = x;
    return 1;
}

static int check_num(const char *s, int is_double, int allow_neg) {
    char *e; errno = 0; double d;
    if (!*s) return 0;
    if (!allow_neg && strchr(s, '-')) return 0;
    if (is_double) return parse_num(s, &d);
    (void)strtoll(s, &e, 10);
    return !*e && !errno;
}

static int check(const param_spec_t *p, const char *val, char *err, size_t errsz) {
    uint64_t b; int ok = 1;
    switch (p->type) {
    case P_INT:    ok = check_num(val, 0, 1); break;
    case P_UINT:   ok = check_num(val, 0, 0); break;
    case P_DOUBLE: ok = check_num(val, 1, 1); break;
    case P_BYTES:  ok = parse_bytes(val, &b); break;
    case P_STRING: break;
    case P_ENUM: {
        size_t n = strlen(val); ok = 0;
        for (const char *c = p->choices; c && *c;) {
            const char *bar = strchr(c, '|'); size_t m = bar ? (size_t)(bar - c) : strlen(c);
            if (m == n && !strncmp(c, val, n)) { ok = 1; break; }
            c = bar ? bar + 1 : NULL;
        }
        break;
    }
    case P_LIST: {
        char *dup = xstrdup(val), *save = NULL;
        for (char *t = strtok_r(dup, ",;", &save); t && ok; t = strtok_r(NULL, ",;", &save)) ok = check_num(t, 1, 1);
        free(dup);
        break;
    }
    }
    if (!ok) snprintf(err, errsz, "bad value '%s' for '%s'%s%s", val, p->key,
                      p->choices ? ", choices: " : "", p->choices ? p->choices : "");
    return ok;
}

/* kvs = "key=val,key=val,..."。'=' を含まない欄は直前の値にカンマで連結する（リスト "tau=1024,2048,10000"）。
 * 先頭が '=' を含まなければ、最初の P_LIST 引数の値とみなす（"fixed:1024,2048,10000"） */
int params_build(param_vals_t *v, const char *name, const param_spec_t *spec, const char *kvs,
                 char *err, size_t errsz) {
    memset(v, 0, sizeof(*v));
    v->name = xstrdup(name); v->spec = spec;
    for (; spec[v->n].key; v->n++) {
        if (v->n >= PV_MAX) die("too many params in spec of %s", name);
        v->val[v->n] = xstrdup(spec[v->n].def ? spec[v->n].def : "");
    }
    char *dup = xstrdup(kvs), *save = NULL;
    int cur = -1;
    unsigned char seen[PV_MAX] = {0};
    for (char *kv = strtok_r(dup, ",", &save); kv; kv = strtok_r(NULL, ",", &save)) {
        char *eq = strchr(kv, '=');
        if (!eq) {
            if (cur < 0) {                                   /* 位置引数: 最初の P_LIST */
                for (int i = 0; i < v->n && cur < 0; i++) if (spec[i].type == P_LIST) cur = i;
                if (cur < 0) { snprintf(err, errsz, "%s: expected key=value, got '%s'", name, kv); free(dup); return 0; }
                if (seen[cur]) { snprintf(err, errsz, "%s: '%s' given twice", name, spec[cur].key); free(dup); return 0; }
                seen[cur] = 1; free(v->val[cur]); v->val[cur] = xstrdup(kv);
                continue;
            }
            size_t n = strlen(v->val[cur]) + strlen(kv) + 2;
            char *j = xmalloc(n);
            snprintf(j, n, "%s,%s", v->val[cur], kv);
            free(v->val[cur]); v->val[cur] = j;
            continue;
        }
        *eq = 0;
        int i = 0;
        while (i < v->n && strcmp(spec[i].key, kv)) i++;
        if (i == v->n) { snprintf(err, errsz, "%s: unknown param '%s'", name, kv); free(dup); return 0; }
        if (seen[i]) { snprintf(err, errsz, "%s: '%s' given twice", name, kv); free(dup); return 0; }
        seen[i] = 1; cur = i;
        free(v->val[i]); v->val[i] = xstrdup(eq + 1);
    }
    free(dup);
    for (int i = 0; i < v->n; i++)
        if (!check(&spec[i], v->val[i], err, errsz)) return 0;
    return 1;
}

static int find(const param_vals_t *v, const char *key) {
    for (int i = 0; i < v->n; i++) if (!strcmp(v->spec[i].key, key)) return i;
    die("internal: plugin %s has no param '%s'", v->name, key);
}
int64_t pv_int(const param_vals_t *v, const char *key) {
    int i = find(v, key);
    if (v->spec[i].type == P_BYTES) { uint64_t b = 0; parse_bytes(v->val[i], &b); return (int64_t)b; }
    return strtoll(v->val[i], NULL, 10);
}
double pv_dbl(const param_vals_t *v, const char *key) { double d = 0; parse_num(v->val[find(v, key)], &d); return d; }
const char *pv_str(const param_vals_t *v, const char *key) { return v->val[find(v, key)]; }
int pv_list(const param_vals_t *v, const char *key, double *out, int max) {
    char *dup = xstrdup(v->val[find(v, key)]), *save = NULL; int n = 0;
    for (char *t = strtok_r(dup, ",;", &save); t; t = strtok_r(NULL, ",;", &save)) {
        if (n >= max) die("%s: list '%s' longer than %d", v->name, key, max);
        parse_num(t, &out[n++]);
    }
    free(dup);
    return n;
}

void pv_json(FILE *f, const param_vals_t *v) {
    fprintf(f, "{ \"name\": \"%s\", \"params\": {", v->name);
    for (int i = 0; i < v->n; i++) {
        const param_spec_t *p = &v->spec[i];
        fprintf(f, "%s\"%s\": ", i ? ", " : "", p->key);
        if (p->type == P_INT || p->type == P_UINT) fprintf(f, "%lld", (long long)pv_int(v, p->key));   /* 4K・20% も数値で */
        else if (p->type == P_DOUBLE) fprintf(f, "%.17g", pv_dbl(v, p->key));
        else if (p->type == P_BYTES) fprintf(f, "%lld", (long long)pv_int(v, p->key));
        else if (p->type == P_LIST) {
            double a[256]; int n = pv_list(v, p->key, a, 256);
            fputc('[', f);
            for (int j = 0; j < n; j++) fprintf(f, "%s%.17g", j ? ", " : "", a[j]);
            fputc(']', f);
        } else fprintf(f, "\"%s\"", v->val[i]);
    }
    fputs("} }", f);
}

void params_print_spec(FILE *f, const param_spec_t *spec) {
    static const char *tn[] = {"int", "uint", "double", "bytes", "enum", "string", "list"};
    if (!spec[0].key) { fputs("      (no params)\n", f); return; }
    for (; spec->key; spec++)
        fprintf(f, "      %-20s %-7s default=%-10s %s%s%s%s\n", spec->key, tn[spec->type], spec->def ? spec->def : "",
                spec->help ? spec->help : "", spec->choices ? "  {" : "", spec->choices ? spec->choices : "",
                spec->choices ? "}" : "");
}
