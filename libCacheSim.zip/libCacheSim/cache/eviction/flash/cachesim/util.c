#include "common.h"
#include <stdarg.h>

void die(const char *fmt, ...) {
    va_list ap; va_start(ap, fmt);
    fputs("cachesim: error: ", stderr); vfprintf(stderr, fmt, ap); fputc('\n', stderr);
    va_end(ap); exit(2);
}
void *xmalloc(size_t n) { void *p = malloc(n ? n : 1); if (!p) die("out of memory (%zu bytes)", n); return p; }
void *xcalloc(size_t n, size_t sz) { void *p = calloc(n ? n : 1, sz ? sz : 1); if (!p) die("out of memory"); return p; }
void *xrealloc(void *p, size_t n) { p = realloc(p, n ? n : 1); if (!p) die("out of memory (%zu bytes)", n); return p; }
char *xstrdup(const char *s) { size_t n = strlen(s) + 1; return memcpy(xmalloc(n), s, n); }
