/* params.h — プラグイン引数 NAME:key=val,... の解析と型検査（DESIGN.md §6.0） */
#ifndef PARAMS_H
#define PARAMS_H
#include "common.h"

typedef enum { P_INT, P_UINT, P_DOUBLE, P_BYTES, P_ENUM, P_STRING, P_LIST } param_type_t;
typedef struct {
    const char  *key;
    param_type_t type;
    const char  *def;        /* 既定値の文字列表現 */
    const char  *choices;    /* P_ENUM のとき "a|b|c" */
    const char  *help;
} param_spec_t;              /* 配列の末尾は { NULL } */

#define PV_MAX 48
typedef struct {
    const char *name;
    const param_spec_t *spec;
    int n;
    char *val[PV_MAX];       /* spec と同じ順。既定値で補完済み */
} param_vals_t;

int  parse_bytes(const char *s, uint64_t *out);              /* K/M/G/T（2 進）接尾辞。成功 = 1 */
int  parse_num(const char *s, double *out);                  /* 数・20%・4K。成功 = 1 */
void spec_split(const char *spec, char *name, size_t nsz, const char **rest);
/* 失敗時は err に理由を書いて 0 を返す */
int  params_build(param_vals_t *v, const char *name, const param_spec_t *spec, const char *kvs,
                  char *err, size_t errsz);
int64_t     pv_int(const param_vals_t *v, const char *key);   /* P_INT / P_UINT / P_BYTES */
double      pv_dbl(const param_vals_t *v, const char *key);
const char *pv_str(const param_vals_t *v, const char *key);
int         pv_list(const param_vals_t *v, const char *key, double *out, int max);
void        pv_json(FILE *f, const param_vals_t *v);
void        params_print_spec(FILE *f, const param_spec_t *spec);
#endif
