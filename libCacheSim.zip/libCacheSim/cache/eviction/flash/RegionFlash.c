//
//  RegionFlash.c — DRAM (object unit) + SSD two-tier flash cache, ported from
//  cachesim (docs/re-DESIGN.md §1, §6).
//
//  - DRAM: any libCacheSim algorithm (dram-algo, default lru). A DRAM hit does
//          not touch the SSD. Every object leaving DRAM is a victim for the SSD.
//  - SSD, ssd-mode=region: N = floor(cache_size / R) regions, FREE -> OPEN ->
//          SEALED -> FREE. One OPEN region per hint class (write stream). A
//          sealed region is written whole (R bytes). OPEN regions are never
//          evicted. region-evict: fifo | lru | beta, or any libCacheSim
//          algorithm applied to the sealed regions as objects of R bytes.
//          Optional piece-wise writes (chunk) and FDP device model (ru-size).
//  - SSD, ssd-mode=object: any libCacheSim algorithm (ssd-algo) on objects.
//          The flash write is the admitted bytes (ideal: no device GC).
//  - hint / admit: at the DRAM->SSD write, admit accept -> hint on_insert ->
//          class (write stream). The hint sees the cache's operations
//          (regionflash_hint.h: on_get, on_find, on_insert, on_evict).
//          hint=NAME[:k=v/..]: split_threshold_req (hint/), or cachesim's
//          providers, run unmodified (cachesim/, re-DESIGN.md §2): none, fixed,
//          split_threshold, st_*, profile, key, oracle_*, ...
//          admit=NAME[:k=v/..] (cachesim's: all, sizemax, sizeexp, seen,
//          cachesack, tinylfu, oracle_opt, ...). Lists inside use '/' too:
//          hint=fixed:4K/64K.
//
//  An inner libCacheSim cache reports its removals through
//  cache_set_remove_hook; a removal is a victim only if find() no longer sees
//  the object (composite algorithms also remove on internal moves). Victims are
//  handled after each evict() call, so they reach the SSD in eviction order.
//  After every request the bytes RegionFlash tracks must equal the inner
//  cache's occupied bytes, otherwise the algorithm is rejected.
//
//  Params (-e): dram-size, dram-algo (alias dram-policy), dram-params,
//  inclusion=cachelib|exclusive|inclusive, ssd-mode=region|object, ssd-algo,
//  ssd-params, region-size, region-evict, region-params, beta, chunk,
//  seal-on-repartition=none|inactive|all (default none), hint,
//  admit, seed, taus / st-lambda (old spellings of fixed:... /
//  split_threshold:lambda=...), warmup-req, ru-size, ruh, fdp-iso=ii|pi,
//  fdp-op, fdp-trim, reinsert, interval, out (alias prefix: the path prefix of
//  every report file; give each parallel run its own). Inner lists use '/' for ',' (the CLI
//  turns ';' into ','): dram-params=small-size-ratio=0.1/move-to-main-threshold=2,
//  reinsert=hits:n=1/max_frac=0.5/mode=ii. The positional cache size is the
//  SSD size. Admission (-a) applies to SSD writes before admit=; its
//  update() is called on every SSD lookup.
//
//  Reports (with out=P): P.json, P.class.csv and P.sizebin.csv at the end
//  (counted after the warm-up); with interval=N (requests, default 1000000)
//  also P.interval.csv, P.interval.class.csv and P.interval.sizebin.csv, one
//  "interval" row (that interval only, warm-up included) and one "cumulative"
//  row (after the warm-up, so far) per interval. Requests, hits and size bins
//  count whole objects, also when they are written piece-wise.
//

#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdarg.h>
#include <strings.h>
#include <sys/stat.h>

#include "dataStructure/hashtable/hashtable.h"
#include "libCacheSim/evictionAlgo.h"
#include "regionflash_hint.h"
#include "regionflash_stats.h"

#ifdef __cplusplus
extern "C" {
#endif

#define RF_KMAX KMAX_LIMIT
#define RF_WMAX 64
#define RF_NONE UINT32_MAX
#define MD(o) ((o)->RegionFlash)

enum { RF_DRAM = 1, RF_SSD = 2, RF_LOST = 4, RF_CHUNK = 8 };
enum { INC_CACHELIB, INC_EXCLUSIVE, INC_INCLUSIVE };
enum { REV_FIFO, REV_LRU, REV_BETA, REV_LCS };
enum { SSD_REGION, SSD_OBJECT };
enum { SEAL_NONE, SEAL_INACTIVE, SEAL_ALL };
enum { T_DRAM, T_SSD, T_REG, T_N };  // inner libCacheSim caches
static const char *const INC_NAME[] = {"cachelib", "exclusive", "inclusive"};
static const char *const REV_NAME[] = {"fifo", "lru", "beta"};
static const char *const SSD_NAME[] = {"region", "object"};
static const char *const SEAL_NAME[] = {"none", "inactive", "all"};
static const char *const TIER_NAME[] = {"dram-algo", "ssd-algo", "region-evict"};

/* counters: kept for the total and for each hint class, after the warm-up
 * (tot, cls) and per interval (win, cwin) */
#define RF_CTRS(X)                                                             \
  X(reqs) X(req_bytes) X(dram_hits) X(ssd_lookups) X(ssd_hits) X(hit_bytes)    \
  X(dram_hit_bytes) X(ssd_lookup_bytes) X(ssd_hit_bytes)                       \
  X(misses) X(miss_bytes) X(size_change_misses) X(dram_evict_objs)             \
  X(clean_skip_objs) X(ssd_copy_lost_rewrites) X(too_large_objs)               \
  X(too_large_bytes) X(admit_reject_objs) X(ssd_admit_objs) X(ssd_admit_bytes) \
  X(ssd_evict_objs) X(ssd_evict_bytes) X(res_sum) X(dead_evict_objs)           \
  X(dead_evict_bytes) X(oracle_reused_bytes) X(oracle_never_bytes)             \
  X(regions_sealed) X(regions_evicted) X(pad_bytes)                            \
  X(flash_region_write_bytes) X(repartition_seals) X(chunk_objs)               \
  X(chunk_pieces) X(chunk_write_aborts) X(chunk_loss_head)                     \
  X(chunk_loss_other) X(chunk_orphan_bytes) X(fdp_gc_copy_bytes)              \
  X(fdp_ru_erases) X(nand_write_bytes) X(reinsert_objs) X(reinsert_bytes)

typedef struct {
#define X(n) uint64_t n;
  RF_CTRS(X)
#undef X
} rf_ctr_t;

typedef struct {
  cache_obj_t *o;  // NULL once the entry is no longer valid
  uint32_t piece;  // RF_NONE: the whole object
} rf_ent_t;

typedef struct {
  rf_ent_t *ent;
  uint32_t n_ent, cap_ent, touches;
  uint64_t used, valid, seq;  // seq: order among equal keys (newer = larger)
  uint64_t oid;               // region-evict=<algorithm>: id in the inner cache
  int64_t open_t, seal_t, last_touch_t;
  uint8_t state, cls;
} rf_region_t;

typedef struct {
  cache_obj_t *o;
  uint32_t region, pos, next, size;
  bool valid;
} rf_piece_t;

/* an inner libCacheSim cache and the removals it reported (candidates) */
typedef struct {
  cache_t *c;
  cache_evict_func_ptr evict0;  // the algorithm's own evict()
  obj_id_t *cand;
  uint32_t ncand, cap_cand;
  obj_id_t cur;  // the object being accessed: not a victim while it is
  char algo[64];
} rf_tier_t;

/* FDP device: n_ru Reclaim Units of spr region slots each. Destinations
 * 0..n_ruh-1 are the host RUHs; GC writes to destination n_ruh (initially
 * isolated: one shared GC stream) or n_ruh + ruh (persistently isolated). */
typedef struct {
  uint64_t ru_size;
  double op;
  uint32_t spr, n_ru, n_ruh, n_dest, gcres, n_free;
  bool pi, trim, in_gc;
  uint32_t *slot_reg;  // host region in the slot, RF_NONE if invalid / empty
  uint8_t *slot_cls;
  uint32_t *ru_valid, *ru_fill, *ru_tag, *free_ru, *dest_ru, *reg_slot;
  uint64_t *ruh_host, *ruh_gc;  // [n_ruh + 1], the last is the shared GC pool
} rf_fdp_t;

typedef struct {
  cache_t *cache;
  request_t *req_local, *req_tmp, *req_ssd, *req_reg, *req_re;
  /* config */
  uint64_t R, chunk, dram_cap, ssd_cap, ssd_max_obj;
  uint32_t N, kmax, khint, ntau;  // kmax = khint (+1: the hot class of re ii)
  int64_t warmup;
  int inclusion, rev, ssd_mode, seal_rep;
  bool fdp_on;
  /* reinsertion (cachesim --reinsert hits:..., CacheLib Navy's hits- and
   * percentage-based policies): an object on an evicted region (or an
   * object-mode victim) with >= re_n SSD hits since it was written is
   * written again with probability re_p */
  bool re_on, re_ii, re_hint, re_reclass;
  uint32_t re_n;
  uint64_t re_max_size;
  double re_p, re_frac;
  cache_obj_t **rebuf;  // candidates of the region evictions in progress
  uint32_t nre, cap_re;
  double beta;
  char out[256], params[T_N][256], spec[2][256], taus_s[256], lambda_s[32];
  /* cachesim plugins (re-DESIGN.md §2): [0] admission, [1] hint */
  const admission_ops_t *aops;
  admission_t *adm;
  const rf_hint_ops_t *hops;  // regionflash_hint.h
  rf_hint_t *hint;
  param_vals_t pv[2];
  rng_t rng_a, rng_h, rng_re;  // cachesim seed*6+4, +5, +6
  uint64_t seed;
  uint32_t epoch;
  int64_t taus[HINT_MAX_IV];       // the hint's bounds
  uint8_t ivcls[HINT_MAX_IV + 1];  // class of each interval
  uint8_t act[RF_KMAX];            // classes the mapping uses
  /* state */
  int64_t t, n_obj;
  bool counting;
  int active;  // the tier whose removals the hook records, -1: none
  /* piece-wise writes in progress (a reinsertion may start one inside another) */
  cache_obj_t *wobj[RF_WMAX];
  bool wab[RF_WMAX];  // aborted: one of its own pieces was evicted
  uint32_t nw;
  uint64_t dram_used, ssd_used, seq, n_rc;
  rf_tier_t tier[T_N];
  rf_region_t *reg;
  uint32_t *rfree, nfree, open[RF_KMAX];
  uint32_t *pend, npend, cap_pend;  // regions the algorithm dropped by itself
  rf_piece_t *pc;
  uint32_t npc, cap_pc, *pcfree, npcfree, cap_pcfree;
  uint64_t admit_n[RF_KMAX], admit_b[RF_KMAX];  // all-time, for beta
  rf_fdp_t fdp;
  rf_ctr_t tot, cls[RF_KMAX], win, cwin[RF_KMAX];
  /* per object-size bin (regionflash_stats.h): after the warm-up, the
   * interval in progress, the last completed interval */
  rf_sb_ctr_t sb_cum[RF_SB_N], sb_cur[RF_SB_N], sb_last[RF_SB_N];
  uint64_t interval, n_ival, ival_start;
  FILE *f_iv, *f_ivc, *f_ivs;  // P.interval*.csv
} rf_params_t;

#define CNT(p, f, c, v)                                   \
  do {                                                    \
    uint64_t v_ = (uint64_t)(v);                          \
    uint32_t c_ = (uint32_t)(c);                          \
    (p)->win.f += v_;                                     \
    if (c_ < RF_KMAX) (p)->cwin[c_].f += v_;              \
    if ((p)->counting) {                                  \
      (p)->tot.f += v_;                                   \
      if (c_ < RF_KMAX) (p)->cls[c_].f += v_;             \
    }                                                     \
  } while (0)

/* per object-size bin: s is the whole object's size */
#define SB(p, f, s, v)                         \
  do {                                         \
    uint32_t b_ = rf_size_bin(s);              \
    uint64_t w_ = (uint64_t)(v);               \
    (p)->sb_cur[b_].f += w_;                   \
    if ((p)->counting) (p)->sb_cum[b_].f += w_; \
  } while (0)

/* sizes for cachesim's plugins are uint32_t: saturate, never wrap */
static inline uint32_t rf_u32(uint64_t s) {
  return s > UINT32_MAX ? UINT32_MAX : (uint32_t)s;
}

#define RF_GROW(ptr, cap, need)                                  \
  do {                                                           \
    if ((need) > (cap)) {                                        \
      (cap) = (cap) ? (cap) * 2 : 16;                            \
      if ((cap) < (need)) (cap) = (need);                        \
      (ptr) = realloc((ptr), sizeof(*(ptr)) * (size_t)(cap));    \
      if ((ptr) == NULL) rf_die("RegionFlash: out of memory\n"); \
    }                                                            \
  } while (0)

__attribute__((format(printf, 1, 2), noreturn)) static void rf_die(
    const char *fmt, ...) {
  va_list ap;
  va_start(ap, fmt);
  vfprintf(stderr, fmt, ap);
  va_end(ap);
  exit(1);
}

static void rf_region_evict(rf_params_t *p);
static uint32_t rf_reg_collect(rf_params_t *p);
static void rf_reg_flush(rf_params_t *p);
static void rf_victim(rf_params_t *p, cache_obj_t *v);
static void rf_evict_account(rf_params_t *p, cache_obj_t *o);
static bool rf_obj_reinsert(rf_params_t *p, cache_obj_t *o);
static void rf_interval_end(rf_params_t *p);

// ***********************************************************************
// ****              inner libCacheSim caches (tiers)                 ****
// ***********************************************************************
/* the RegionFlash whose get() is running in this thread (for the evict
 * wrappers, which only receive the inner cache) */
static _Thread_local rf_params_t *rf_cur = NULL;

static void rf_on_remove(void *ctx, obj_id_t id, int64_t size) {
  rf_params_t *p = (rf_params_t *)ctx;
  if (p->active < 0) return;
  rf_tier_t *x = &p->tier[p->active];
  RF_GROW(x->cand, x->cap_cand, x->ncand + 1);
  x->cand[x->ncand++] = id;
}

static bool rf_resident(rf_params_t *p, int t, obj_id_t id, int64_t size) {
  int prev = p->active;
  p->active = -1;
  p->req_tmp->obj_id = id;
  p->req_tmp->obj_size = size;
  bool r = p->tier[t].c->find(p->tier[t].c, p->req_tmp, false) != NULL;
  p->active = prev;
  return r;
}

/* candidates that find() no longer sees are victims (not internal moves) */
static void rf_drain(rf_params_t *p, int t) {
  rf_tier_t *x = &p->tier[t];
  if (t == T_REG) {
    rf_reg_collect(p);
    return;
  }
  for (uint32_t i = 0; i < x->ncand; i++) {  // may grow while victims are handled
    obj_id_t id = x->cand[i];
    if (id == x->cur) continue;
    cache_obj_t *o = hashtable_find_obj_id(p->cache->hashtable, id);
    uint8_t f = t == T_DRAM ? RF_DRAM : RF_SSD;
    if (o == NULL || !(MD(o).flags & f) || rf_resident(p, t, id, o->obj_size)) continue;
    MD(o).flags &= ~f;
    if (t == T_DRAM) {
      p->dram_used -= (uint64_t)o->obj_size;
      rf_victim(p, o);
    } else if (!rf_obj_reinsert(p, o)) {
      p->ssd_used -= (uint64_t)o->obj_size;
      rf_evict_account(p, o);
    }
  }
  x->ncand = 0;
}

/* installed as the inner cache's evict(): one eviction, then its victims */
static void rf_dram_evict(cache_t *c, const request_t *req) {
  rf_cur->tier[T_DRAM].evict0(c, req);
  rf_drain(rf_cur, T_DRAM);
}

static void rf_ssd_evict(cache_t *c, const request_t *req) {
  rf_cur->tier[T_SSD].evict0(c, req);
  rf_drain(rf_cur, T_SSD);
}

/* one access (get) to an inner cache; returns hit */
static bool rf_tier_get(rf_params_t *p, int t, const request_t *req) {
  rf_tier_t *x = &p->tier[t];
  int prev = p->active;
  obj_id_t prev_cur = x->cur;
  p->active = t;
  x->cur = req->obj_id;
  bool hit = x->c->get(x->c, req);
  p->active = prev;
  rf_drain(p, t);  // removals outside evict()
  x->cur = prev_cur;
  return hit;
}

static void rf_tier_remove(rf_params_t *p, int t, obj_id_t id) {
  int prev = p->active;
  p->active = -1;
  p->tier[t].c->remove(p->tier[t].c, id);
  p->active = prev;
}

static void rf_tier_init(rf_params_t *p, int t, const char *algo,
                         common_cache_params_t cp, uint64_t size) {
  rf_tier_t *x = &p->tier[t];
  if (strcasecmp(algo, "RegionFlash") == 0)
    rf_die("RegionFlash: %s cannot be RegionFlash\n", TIER_NAME[t]);
  char buf[256];
  snprintf(buf, sizeof(buf), "%s", p->params[t]);
  for (char *q = buf; *q; q++)
    if (*q == '/') *q = ',';
  cp.cache_size = size;
  cp.consider_obj_metadata = false;
  x->c = create_cache_by_name(algo, cp, buf[0] ? buf : NULL);
  if (x->c == NULL) rf_die("RegionFlash: unknown %s %s\n", TIER_NAME[t], algo);
  snprintf(x->algo, sizeof(x->algo), "%s", algo);
  x->evict0 = x->c->evict;
  if (t == T_DRAM) x->c->evict = rf_dram_evict;
  if (t == T_SSD) x->c->evict = rf_ssd_evict;
  x->cur = (obj_id_t)-1;
}

/* the bytes RegionFlash tracks must be what the inner cache holds */
static void rf_check(const rf_params_t *p) {
  const uint64_t want[T_N] = {p->dram_used, p->ssd_used, p->n_rc * p->R};
  for (int t = 0; t < T_N; t++) {
    const rf_tier_t *x = &p->tier[t];
    if (x->c == NULL) continue;
    int64_t got = x->c->get_occupied_byte(x->c);
    if (got != (int64_t)want[t])
      rf_die("RegionFlash: %s %s holds %lld B but %llu B are tracked; its "
             "evictions are not observable\n",
             TIER_NAME[t], x->algo, (long long)got, (unsigned long long)want[t]);
  }
}

// ***********************************************************************
// ****                       FDP device model                        ****
// ***********************************************************************
static void fdp_gc(rf_params_t *p);

static uint32_t fdp_alloc(rf_params_t *p) {
  rf_fdp_t *f = &p->fdp;
  for (uint32_t guard = 0; !f->in_gc && f->n_free <= f->gcres; guard++) {
    if (guard > f->n_ru) rf_die("FDP: GC cannot free RUs (raise fdp-op)\n");
    fdp_gc(p);
  }
  if (f->n_free == 0) rf_die("FDP: no free RU during GC (raise fdp-op)\n");
  return f->free_ru[--f->n_free];
}

/* the host region's previous copy becomes invalid (overwrite or trim) */
static void fdp_kill(rf_fdp_t *f, uint32_t r) {
  uint32_t s = f->reg_slot[r];
  if (s == RF_NONE) return;
  f->slot_reg[s] = RF_NONE;
  f->ru_valid[s / f->spr]--;
  f->reg_slot[r] = RF_NONE;
}

static void fdp_place(rf_params_t *p, uint32_t d, uint32_t r, uint8_t c) {
  rf_fdp_t *f = &p->fdp;
  uint32_t u = f->dest_ru[d];
  if (u == RF_NONE) {
    u = fdp_alloc(p);
    f->dest_ru[d] = u;
    f->ru_tag[u] = d < f->n_ruh ? d : (f->pi ? d - f->n_ruh : f->n_ruh);
  }
  uint32_t s = u * f->spr + f->ru_fill[u]++;
  f->slot_reg[s] = r;
  f->slot_cls[s] = c;
  f->ru_valid[u]++;
  f->reg_slot[r] = s;
  if (f->ru_fill[u] == f->spr) f->dest_ru[d] = RF_NONE;
}

/* greedy GC: relocate the valid slots of the full RU with the fewest */
static void fdp_gc(rf_params_t *p) {
  rf_fdp_t *f = &p->fdp;
  uint32_t v = RF_NONE;
  for (uint32_t u = 0; u < f->n_ru; u++)
    if (f->ru_fill[u] == f->spr && (v == RF_NONE || f->ru_valid[u] < f->ru_valid[v]))
      v = u;
  if (v == RF_NONE || f->ru_valid[v] == f->spr)
    rf_die("FDP: no reclaimable RU (raise fdp-op)\n");
  uint32_t tag = f->ru_tag[v];
  f->in_gc = true;
  for (uint32_t i = 0; i < f->spr; i++) {
    uint32_t s = v * f->spr + i, r = f->slot_reg[s];
    if (r == RF_NONE) continue;
    uint8_t c = f->slot_cls[s];
    fdp_kill(f, r);
    fdp_place(p, f->pi ? f->n_ruh + tag : f->n_ruh, r, c);
    CNT(p, fdp_gc_copy_bytes, c, p->R);
    CNT(p, nand_write_bytes, c, p->R);
    if (p->counting) f->ruh_gc[tag] += p->R;
  }
  f->in_gc = false;
  f->ru_fill[v] = 0;
  f->free_ru[f->n_free++] = v;
  CNT(p, fdp_ru_erases, RF_NONE, 1);
}

static void fdp_host_write(rf_params_t *p, uint32_t r, uint8_t c) {
  rf_fdp_t *f = &p->fdp;
  uint32_t d = c % f->n_ruh;
  fdp_kill(f, r);
  fdp_place(p, d, r, c);
  CNT(p, nand_write_bytes, c, p->R);
  if (p->counting) f->ruh_host[d] += p->R;
}

static void fdp_init(rf_params_t *p) {
  rf_fdp_t *f = &p->fdp;
  if (f->ru_size % p->R) rf_die("FDP: ru-size must be a multiple of region-size\n");
  if (f->n_ruh == 0) rf_die("FDP: ruh must be >= 1\n");
  f->spr = (uint32_t)(f->ru_size / p->R);
  f->n_ru = (uint32_t)floor((double)p->N * (double)p->R * (1 + f->op) /
                            (double)f->ru_size);
  f->n_dest = f->n_ruh + (f->pi ? f->n_ruh : 1);
  f->gcres = f->pi ? f->n_ruh : 1;
  uint32_t need = (p->N + f->spr - 1) / f->spr + f->n_dest + f->gcres + 1;
  if (f->n_ru < need)
    rf_die("FDP: %u RUs < %u needed (N=%u, %u slots/RU); raise fdp-op\n",
           f->n_ru, need, p->N, f->spr);
  if (p->kmax > f->n_ruh)
    WARN("FDP: %u classes share %u RUHs (class %% ruh)\n", p->kmax, f->n_ruh);
  size_t ns = (size_t)f->n_ru * f->spr;
  f->slot_reg = malloc(ns * sizeof(uint32_t));
  f->slot_cls = calloc(ns, 1);
  f->ru_valid = calloc(f->n_ru, sizeof(uint32_t));
  f->ru_fill = calloc(f->n_ru, sizeof(uint32_t));
  f->ru_tag = calloc(f->n_ru, sizeof(uint32_t));
  f->free_ru = malloc(f->n_ru * sizeof(uint32_t));
  f->dest_ru = malloc(f->n_dest * sizeof(uint32_t));
  f->reg_slot = malloc(p->N * sizeof(uint32_t));
  f->ruh_host = calloc(f->n_ruh + 1, sizeof(uint64_t));
  f->ruh_gc = calloc(f->n_ruh + 1, sizeof(uint64_t));
  for (size_t s = 0; s < ns; s++) f->slot_reg[s] = RF_NONE;
  for (uint32_t u = 0; u < f->n_ru; u++) f->free_ru[u] = f->n_ru - 1 - u;
  for (uint32_t d = 0; d < f->n_dest; d++) f->dest_ru[d] = RF_NONE;
  for (uint32_t r = 0; r < p->N; r++) f->reg_slot[r] = RF_NONE;
  f->n_free = f->n_ru;
}

// ***********************************************************************
// ****                          hint                                 ****
// ***********************************************************************
static uint32_t rf_class_of(const rf_params_t *p, uint64_t s) {
  return p->ivcls[class_of_taus(p->taus, p->ntau, s)];
}

static void rf_free_region(rf_params_t *p, uint32_t r);
static void rf_seal(rf_params_t *p, uint32_t r);

/* RegionFlash's own hint providers (regionflash_hint.h, hint/) */
extern const rf_hint_ops_t rf_hint_split_threshold_req_ops;
static const rf_hint_ops_t *const RF_HINTS[] = {&rf_hint_split_threshold_req_ops, NULL};

/* spec "name:k=v/k=v" -> the ops of an admission policy (kind 0, cachesim's)
 * or a hint provider (kind 1: RF_HINTS, *native, or cachesim's), and its
 * parameters in pv (cachesim main.c mkplug) */
static const void *rf_plugin(int kind, const char *spec, param_vals_t *pv, bool *native) {
  typedef struct { const char *name; const param_spec_t *params; } head_t;
  const void *const *tabs[2] = {
      kind ? (const void *const *)RF_HINTS : NULL,
      kind ? (const void *const *)HINTS : (const void *const *)ADMISSIONS};
  char buf[256], name[64], err[512];
  const char *rest;
  snprintf(buf, sizeof(buf), "%s", spec);
  /* '/' separates when a key= follows or between list numbers (4K/64K);
   * otherwise it stays, so paths work: profile:path=/a/b.csv/k=3 */
  for (char *q = buf + 1; *q; q++) {
    if (*q != '/') continue;
    size_t n = strspn(q + 1, "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_");
    bool key = n > 0 && q[1 + n] == '=';
    bool num = strchr("0123456789.KMGT%", q[-1]) && isdigit((unsigned char)q[1]);
    if (key || num) *q = ',';
  }
  spec_split(buf, name, sizeof(name), &rest);
  for (int k = 0; k < 2; k++)
    for (const void *const *tab = tabs[k]; tab != NULL && *tab; tab++) {
      const head_t *h = *tab;
      if (strcmp(h->name, name) != 0) continue;
      if (!params_build(pv, name, h->params, rest, err, sizeof(err)))
        rf_die("RegionFlash: %s\n", err);
      if (native != NULL) *native = k == 0;
      return *tab;
    }
  rf_die("RegionFlash: unknown %s %s\n", kind ? "hint" : "admit", name);
}

/* read the hint's intervals and their classes again (cachesim sim_refresh_map) */
static void rf_refresh_map(rf_params_t *p) {
  const char *n = p->pv[1].name;
  p->ntau = p->hops->bounds(p->hint, p->taus, HINT_MAX_IV);
  for (uint32_t i = 1; i < p->ntau; i++)
    if (p->taus[i] <= p->taus[i - 1])
      rf_die("RegionFlash: hint %s: bounds not strictly increasing\n", n);
  uint32_t nc = p->hops->classes ? p->hops->classes(p->hint, p->ivcls, HINT_MAX_IV + 1) : 0;
  if (nc == 0)
    for (uint32_t i = 0; i <= p->ntau; i++) p->ivcls[i] = (uint8_t)i;
  else if (nc != p->ntau + 1)
    rf_die("RegionFlash: hint %s: classes() size mismatch\n", n);
  memset(p->act, 0, sizeof(p->act));
  for (uint32_t i = 0; i <= p->ntau; i++) {
    if (p->ivcls[i] >= p->khint)
      rf_die("RegionFlash: hint %s maps an interval to class %u >= %u\n", n,
             p->ivcls[i], p->khint);
    p->act[p->ivcls[i]] = 1;
  }
}

/* the partition changed (cachesim seal-on-repartition): none (default) keeps
 * writing every OPEN region, as an FDP device appends to its RU anyway;
 * inactive seals (or frees, if empty) the OPEN region of every class the new
 * mapping no longer uses; all seals every OPEN region */
static void rf_repartition(rf_params_t *p) {
  if (p->seal_rep == SEAL_NONE) return;
  for (uint32_t c = 0; c < p->kmax; c++) {
    uint32_t r = p->open[c];
    if (r == RF_NONE || (p->re_ii && c == p->khint)) continue;
    if (p->seal_rep == SEAL_INACTIVE && p->act[c]) continue;
    if (p->reg[r].used == 0) {
      p->open[c] = RF_NONE;
      rf_free_region(p, r);
      continue;
    }
    rf_seal(p, r);
    CNT(p, repartition_seals, c, 1);
  }
}

static void rf_epoch_check(rf_params_t *p) {
  uint32_t e = p->hops->epoch(p->hint);
  if (e == p->epoch) return;
  p->epoch = e;
  rf_refresh_map(p);
  if (p->ssd_mode == SSD_REGION) rf_repartition(p);
}

/* hint on_insert: the class of an SSD write of o; src: SRC_DRAM_EVICT |
 * SRC_MISS | SRC_REINSERT. next_dist counts requests from now (t + 1, as
 * libCacheSim's oracle vtime) */
static uint32_t rf_hint_insert(rf_params_t *p, const cache_obj_t *o, int src) {
  int64_t na = o->next_access_vtime, now = p->t + 1;
  int64_t nd = na == -2 ? -2
               : (na == -1 || na == MAX_REUSE_DISTANCE) ? -1
               : na > now ? na - now : 0;
  rf_hint_ev_t e = {.t = (uint64_t)p->t, .id = o->obj_id, .size = (uint64_t)o->obj_size,
                    .cls = MD(o).cls, .source = (uint8_t)src,
                    .dram_hits = MD(o).dram_hits, .next_dist = nd};
  uint32_t c = p->hops->on_insert(p->hint, &e);
  rf_epoch_check(p);
  if (c >= p->khint)
    rf_die("RegionFlash: hint %s returned class %u >= %u\n", p->pv[1].name, c,
           p->khint);
  return c;
}

/* hint on_get / on_find: a request for id (size s, class c) */
static void rf_hint_req(rf_params_t *p, void (*fn)(rf_hint_t *, const rf_hint_ev_t *),
                        uint64_t id, uint64_t s, uint32_t c, int outcome) {
  if (fn == NULL) return;
  rf_hint_ev_t e = {.t = (uint64_t)p->t, .id = id, .size = s, .cls = c,
                    .outcome = (uint8_t)outcome};
  fn(p->hint, &e);
}

// ***********************************************************************
// ****                        SSD regions                            ****
// ***********************************************************************
/* region-evict=<algorithm>: a sealed region is an object of R bytes */
static request_t *rf_reg_req(rf_params_t *p, uint64_t oid) {
  p->req_reg->obj_id = oid;
  p->req_reg->obj_size = (int64_t)p->R;
  p->req_reg->clock_time = p->req_local->clock_time;
  return p->req_reg;
}

static void rf_seal(rf_params_t *p, uint32_t r) {
  rf_region_t *g = &p->reg[r];
  if (g->cls >= RF_KMAX) rf_die("RegionFlash: region %u has class %u\n", r, g->cls);
  g->state = R_SEALED;
  g->seal_t = p->t;
  g->seq = ++p->seq;
  CNT(p, pad_bytes, g->cls, p->R - g->used);
  CNT(p, flash_region_write_bytes, g->cls, p->R);  // written whole
  CNT(p, regions_sealed, g->cls, 1);
  p->open[g->cls] = RF_NONE;
  if (p->fdp_on)
    fdp_host_write(p, r, g->cls);
  else
    CNT(p, nand_write_bytes, g->cls, p->R);  // no device GC (DLWA = 1)
  if (p->rev == REV_LCS) {
    g->oid = g->seq * p->N + r;  // unique per seal, region = oid % N
    if (rf_tier_get(p, T_REG, rf_reg_req(p, g->oid)))
      rf_die("RegionFlash: region-evict %s already held a new region\n",
             p->tier[T_REG].algo);
    if (rf_resident(p, T_REG, g->oid, (int64_t)p->R)) {
      p->n_rc++;
    } else {  // declined (admission inside the algorithm): evict it next
      g->oid = 0;
      RF_GROW(p->pend, p->cap_pend, p->npend + 1);
      p->pend[p->npend++] = r;
    }
  }
}

static void rf_free_region(rf_params_t *p, uint32_t r) {
  rf_region_t *g = &p->reg[r];
  g->state = R_FREE;
  g->n_ent = g->touches = 0;
  g->used = g->valid = 0;
  p->rfree[p->nfree++] = r;
  if (p->fdp_on && p->fdp.trim) fdp_kill(&p->fdp, r);
}

static void rf_touch(rf_params_t *p, uint32_t r) {
  rf_region_t *g = &p->reg[r];
  g->touches++;
  g->last_touch_t = p->t;
  if (g->state != R_SEALED) return;
  if (p->rev == REV_LCS) {
    if (g->oid == 0) return;  // pending eviction
    if (!rf_tier_get(p, T_REG, rf_reg_req(p, g->oid)))
      rf_die("RegionFlash: region-evict %s lost a sealed region\n",
             p->tier[T_REG].algo);
  } else if (p->rev != REV_FIFO) {
    g->seq = ++p->seq;
  }
}

/* is region a older than b in the eviction order */
static bool rf_older(const rf_params_t *p, const rf_region_t *a,
                     const rf_region_t *b) {
  if (p->rev == REV_FIFO) return a->seq < b->seq;
  return a->last_touch_t < b->last_touch_t ||
         (a->last_touch_t == b->last_touch_t && a->seq < b->seq);
}

static double rf_class_mean(const rf_params_t *p, uint32_t c) {
  return p->admit_n[c] ? (double)p->admit_b[c] / (double)p->admit_n[c] : NAN;
}

/* fifo: first sealed; lru: least recently touched (write or SSD hit);
 * beta: per-class LRU tail with max (t - last_touch) * (s_ref / mean_c)^beta */
static uint32_t rf_pick(const rf_params_t *p) {
  uint32_t tail[RF_KMAX];
  for (uint32_t c = 0; c < RF_KMAX; c++) tail[c] = RF_NONE;
  for (uint32_t r = 0; r < p->N; r++) {
    const rf_region_t *g = &p->reg[r];
    if (g->state != R_SEALED) continue;
    uint32_t c = p->rev == REV_BETA ? g->cls : 0;
    if (tail[c] == RF_NONE || rf_older(p, g, &p->reg[tail[c]])) tail[c] = r;
  }
  if (p->rev != REV_BETA) return tail[0];
  double sref = INFINITY, best_score = -INFINITY;
  uint32_t best = RF_NONE;
  for (uint32_t c = 0; c < p->kmax; c++) {
    double m = rf_class_mean(p, c);
    if (m == m && m < sref) sref = m;
  }
  for (uint32_t c = 0; c < p->kmax; c++) {
    if (tail[c] == RF_NONE) continue;
    double m = rf_class_mean(p, c);
    double w = (m == m && sref < INFINITY) ? pow(sref / m, p->beta) : 1.0;
    double score = (double)(p->t - p->reg[tail[c]].last_touch_t) * w;
    if (score > best_score) {
      best_score = score;
      best = tail[c];
    }
  }
  return best;
}

static void rf_drop(rf_params_t *p, uint32_t r, uint32_t pos, uint64_t s) {
  p->reg[r].valid -= s;
  p->reg[r].ent[pos].o = NULL;
  p->ssd_used -= s;
}

/* append an entry of s bytes to the OPEN region of class c */
static uint32_t rf_place(rf_params_t *p, cache_obj_t *o, uint32_t piece,
                         uint64_t s, uint32_t c, uint32_t *pos) {
  uint32_t r;
  rf_reg_flush(p);
  for (;;) {  // making space may change the OPEN region, so look again
    r = p->open[c];
    if (r != RF_NONE) {
      if (p->reg[r].used + s <= p->R) break;
      rf_seal(p, r);  // does not fit: seal, the tail is padding
      continue;
    }
    if (p->nfree == 0) {
      rf_region_evict(p);
      continue;
    }
    r = p->rfree[--p->nfree];
    rf_region_t *ng = &p->reg[r];
    ng->state = R_OPEN;
    ng->cls = (uint8_t)c;
    ng->open_t = ng->last_touch_t = p->t;
    ng->seal_t = 0;
    p->open[c] = r;
    break;
  }
  rf_region_t *g = &p->reg[r];
  RF_GROW(g->ent, g->cap_ent, g->n_ent + 1);
  g->ent[g->n_ent].o = o;
  g->ent[g->n_ent].piece = piece;
  *pos = g->n_ent++;
  g->used += s;
  g->valid += s;
  g->last_touch_t = p->t;  // a write is a touch
  p->ssd_used += s;
  if (g->used == p->R) rf_seal(p, r);
  return r;
}

static uint32_t rf_piece_alloc(rf_params_t *p) {
  if (p->npcfree) return p->pcfree[--p->npcfree];
  RF_GROW(p->pc, p->cap_pc, p->npc + 1);
  return p->npc++;
}

static void rf_piece_free(rf_params_t *p, uint32_t q) {
  RF_GROW(p->pcfree, p->cap_pcfree, p->npcfree + 1);
  p->pcfree[p->npcfree++] = q;
}

/* piece-wise: an object larger than chunk is written as chunk-sized pieces
 * (it may span regions). Losing one piece drops the whole object. If one of
 * its own pieces is evicted while it is being written, the write aborts. */
static bool rf_append(rf_params_t *p, cache_obj_t *o, uint32_t c) {
  uint64_t s = (uint64_t)o->obj_size;
  uint32_t pos, r;
  if (!p->chunk || s <= p->chunk) {
    r = rf_place(p, o, RF_NONE, s, c, &pos);
    MD(o).loc = r;
    MD(o).pos = pos;
    MD(o).flags = (MD(o).flags | RF_SSD) & ~RF_CHUNK;
    return true;
  }
  uint32_t n = (uint32_t)((s + p->chunk - 1) / p->chunk), head = RF_NONE,
           prev = RF_NONE;
  if (p->nw == RF_WMAX) rf_die("RegionFlash: piece-wise writes nested too deep\n");
  uint32_t w = p->nw++;
  p->wobj[w] = o;
  p->wab[w] = false;
  for (uint32_t k = 0; k < n && !p->wab[w]; k++) {
    uint64_t psz = k + 1 < n ? p->chunk : s - p->chunk * (n - 1);
    uint32_t q = rf_piece_alloc(p);
    p->pc[q] = (rf_piece_t){o, RF_NONE, 0, RF_NONE, (uint32_t)psz, false};
    r = rf_place(p, o, q, psz, c, &pos);
    p->pc[q].region = r;
    p->pc[q].pos = pos;
    p->pc[q].valid = true;
    if (prev == RF_NONE)
      head = q;
    else
      p->pc[prev].next = q;
    prev = q;
  }
  bool aborted = p->wab[w];
  p->nw--;  // nested writes have finished: w is the top
  CNT(p, chunk_objs, c, 1);
  CNT(p, chunk_pieces, c, n);
  if (aborted) {
    for (uint32_t q = head; q != RF_NONE;) {
      uint32_t nx = p->pc[q].next;
      if (p->pc[q].valid) rf_drop(p, p->pc[q].region, p->pc[q].pos, p->pc[q].size);
      rf_piece_free(p, q);
      q = nx;
    }
    MD(o).flags &= ~(RF_SSD | RF_CHUNK);
    CNT(p, chunk_write_aborts, c, 1);
    return false;
  }
  MD(o).loc = head;
  MD(o).flags |= RF_SSD | RF_CHUNK;
  return true;
}

static void rf_ssd_invalidate(rf_params_t *p, cache_obj_t *o) {
  if (p->ssd_mode == SSD_OBJECT) {
    rf_tier_remove(p, T_SSD, o->obj_id);
    p->ssd_used -= (uint64_t)o->obj_size;
  } else if (MD(o).flags & RF_CHUNK) {
    for (uint32_t q = MD(o).loc; q != RF_NONE;) {
      uint32_t nx = p->pc[q].next;
      if (p->pc[q].valid) rf_drop(p, p->pc[q].region, p->pc[q].pos, p->pc[q].size);
      p->pc[q].valid = false;
      rf_piece_free(p, q);
      q = nx;
    }
  } else {
    rf_drop(p, MD(o).loc, MD(o).pos, (uint64_t)o->obj_size);
  }
  MD(o).flags &= ~(RF_SSD | RF_CHUNK);
}

/* SSD hit: read every piece, touching its region in order */
static void rf_ssd_hit(rf_params_t *p, cache_obj_t *o) {
  if (p->ssd_mode == SSD_OBJECT) {
    if (!rf_tier_get(p, T_SSD, p->req_local))
      rf_die("RegionFlash: ssd-algo %s lost an object\n", p->tier[T_SSD].algo);
  } else if (!(MD(o).flags & RF_CHUNK)) {
    rf_touch(p, MD(o).loc);
  } else {
    for (uint32_t q = MD(o).loc; q != RF_NONE; q = p->pc[q].next)
      rf_touch(p, p->pc[q].region);
  }
}

static void rf_obj_delete(rf_params_t *p, cache_obj_t *o) {
  hashtable_delete(p->cache->hashtable, o);
  p->n_obj--;
}

static void rf_evict_account(rf_params_t *p, cache_obj_t *o) {
  uint32_t c = MD(o).cls;
  uint64_t s = (uint64_t)o->obj_size;
  int64_t next = o->next_access_vtime;
  CNT(p, ssd_evict_objs, c, 1);
  CNT(p, ssd_evict_bytes, c, s);
  CNT(p, res_sum, c, (uint64_t)(p->t - MD(o).admit_t));
  if (MD(o).ssd_hits == 0) {
    CNT(p, dead_evict_objs, c, 1);
    CNT(p, dead_evict_bytes, c, s);
  }
  if (next == -1 || next == MAX_REUSE_DISTANCE)
    CNT(p, oracle_never_bytes, c, s);
  else if (next >= 0)
    CNT(p, oracle_reused_bytes, c, s);
  if (p->hops->on_evict) {
    rf_hint_ev_t e = {.t = (uint64_t)p->t, .id = o->obj_id, .size = s, .cls = c,
                      .freq = (uint32_t)MD(o).ssd_hits + 1,
                      .residence = (uint64_t)(p->t - MD(o).admit_t)};
    p->hops->on_evict(p->hint, &e);
  }
  if (MD(o).flags & RF_DRAM)
    MD(o).flags |= RF_LOST;  // keep the DRAM copy
  else
    rf_obj_delete(p, o);
}

/* reinsertion: enough SSD hits since written, not too large, then a coin */
static bool rf_reinsert_ok(rf_params_t *p, const cache_obj_t *o) {
  if (!p->re_on || MD(o).ssd_hits < p->re_n) return false;
  if (p->re_max_size && (uint64_t)o->obj_size > p->re_max_size) return false;
  return p->re_p >= 1 || rng_double(&p->rng_re) < p->re_p;  // cachesim reinsert_ok
}

/* ssd-mode=object: a victim the policy keeps goes straight back in, while the
 * algorithm is still making space (cachesim obj_reinsert; an LRU/FIFO puts it
 * at the head again). True if it is in again. */
static bool rf_obj_reinsert(rf_params_t *p, cache_obj_t *o) {
  if (!rf_reinsert_ok(p, o)) return false;
  if (p->re_hint) rf_hint_insert(p, o, SRC_REINSERT);  // for its statistics only
  rf_tier_t *x = &p->tier[T_SSD];
  request_t *q = p->req_re;  // req_ssd is still in use by the get that evicts
  q->obj_id = o->obj_id;
  q->obj_size = o->obj_size;
  q->next_access_vtime = o->next_access_vtime;
  q->clock_time = p->req_local->clock_time;
  int prev = p->active;
  p->active = T_SSD;
  x->c->insert(x->c, q);
  p->active = prev;
  if (!rf_resident(p, T_SSD, o->obj_id, o->obj_size)) return false;
  MD(o).flags |= RF_SSD;
  MD(o).ssd_hits = 0;
  CNT(p, reinsert_objs, MD(o).cls, 1);
  CNT(p, reinsert_bytes, MD(o).cls, (uint64_t)o->obj_size);
  CNT(p, nand_write_bytes, MD(o).cls, (uint64_t)o->obj_size);
  return true;
}

/* write an object of an evicted region again: its own class (or what the
 * hint says now, class=reclassify), or the one hot class (mode=ii) */
static void rf_reinsert(rf_params_t *p, cache_obj_t *o) {
  uint32_t c = MD(o).cls;
  if (p->re_hint) {
    uint32_t nc = rf_hint_insert(p, o, SRC_REINSERT);
    if (p->re_reclass) c = nc;
  }
  if (p->re_ii) c = p->khint;
  MD(o).cls = (uint8_t)c;
  MD(o).ssd_hits = 0;  // admit_t is kept
  bool ok = rf_append(p, o, c);
  CNT(p, reinsert_objs, c, 1);
  CNT(p, reinsert_bytes, c, (uint64_t)o->obj_size);
  if (!ok) rf_evict_account(p, o);  // the piece-wise write aborted
}

static void rf_evict_region(rf_params_t *p, uint32_t r) {
  rf_region_t *g = &p->reg[r];
  uint32_t base = p->nre;  // candidates of this eviction: rebuf[base, end)
  uint64_t budget = p->re_on ? (uint64_t)((double)p->R * p->re_frac) : 0;
  CNT(p, regions_evicted, g->cls, 1);
  for (uint32_t i = 0; i < g->n_ent; i++) {
    cache_obj_t *o = g->ent[i].o;
    uint32_t piece = g->ent[i].piece;
    if (o == NULL) continue;
    if (piece != RF_NONE) {
      uint32_t w = p->nw;
      while (w > 0 && p->wobj[w - 1] != o) w--;
      if (w > 0) {  // a piece of an object being written: abort that write
        rf_drop(p, r, i, p->pc[piece].size);
        p->pc[piece].valid = false;
        p->wab[w - 1] = true;
        continue;
      }
      uint64_t orphan = 0;
      for (uint32_t q = MD(o).loc; q != RF_NONE; q = p->pc[q].next)
        if (p->pc[q].valid && p->pc[q].region != r) orphan += p->pc[q].size;
      if (p->pc[MD(o).loc].region == r)
        CNT(p, chunk_loss_head, MD(o).cls, 1);
      else
        CNT(p, chunk_loss_other, MD(o).cls, 1);
      CNT(p, chunk_orphan_bytes, MD(o).cls, orphan);
    }
    rf_ssd_invalidate(p, o);
    if ((uint64_t)o->obj_size <= budget && rf_reinsert_ok(p, o)) {  // in write order
      budget -= (uint64_t)o->obj_size;
      RF_GROW(p->rebuf, p->cap_re, p->nre + 1);
      p->rebuf[p->nre++] = o;
      continue;
    }
    rf_evict_account(p, o);
  }
  uint32_t end = p->nre;
  rf_free_region(p, r);
  for (uint32_t k = base; k < end; k++) rf_reinsert(p, p->rebuf[k]);
  p->nre = base;
}

static void rf_region_evict(rf_params_t *p) {
  if (p->rev != REV_LCS) {
    uint32_t r = rf_pick(p);
    if (r == RF_NONE) rf_die("RegionFlash: no sealed region to evict\n");
    rf_evict_region(p, r);
    return;
  }
  /* the algorithm picks: every sealed region it no longer holds is evicted */
  rf_tier_t *x = &p->tier[T_REG];
  for (uint64_t k = 0; p->npend == 0; k++) {  // an evict() may only move one
    if (k > p->N) rf_die("RegionFlash: region-evict %s evicts no region\n", x->algo);
    int prev = p->active;
    p->active = T_REG;
    x->evict0(x->c, rf_reg_req(p, 0));
    p->active = prev;
    rf_reg_collect(p);
  }
  rf_reg_flush(p);
}

/* region-evict=<algorithm>: the sealed regions it reported and no longer
 * holds become pending evictions (it may drop some on an insert or a hit) */
static uint32_t rf_reg_collect(rf_params_t *p) {
  rf_tier_t *x = &p->tier[T_REG];
  uint32_t n = 0;
  for (uint32_t i = 0; i < x->ncand; i++) {
    uint64_t id = x->cand[i];
    rf_region_t *g = &p->reg[id % p->N];
    if (g->state != R_SEALED || g->oid != id || rf_resident(p, T_REG, id, (int64_t)p->R))
      continue;
    g->oid = 0;  // no longer in the algorithm (0 is never a seal id)
    p->n_rc--;
    RF_GROW(p->pend, p->cap_pend, p->npend + 1);
    p->pend[p->npend++] = (uint32_t)(id % p->N);
    n++;
  }
  x->ncand = 0;
  return n;
}

/* evict the pending regions; called where a region may vanish: before a
 * write and at the end of a request (never inside a hit or a seal, whose
 * caller still holds the region) */
static void rf_reg_flush(rf_params_t *p) {
  for (uint32_t i = 0; i < p->npend; i++)
    if (p->reg[p->pend[i]].state == R_SEALED) rf_evict_region(p, p->pend[i]);
  p->npend = 0;
}

/* ssd-mode=object: the algorithm makes space and inserts */
static bool rf_obj_write(rf_params_t *p, cache_obj_t *o) {
  request_t *q = p->req_ssd;
  q->obj_id = o->obj_id;
  q->obj_size = o->obj_size;
  q->next_access_vtime = o->next_access_vtime;
  q->clock_time = p->req_local->clock_time;
  if (rf_tier_get(p, T_SSD, q))
    rf_die("RegionFlash: ssd-algo %s holds an object not tracked\n",
           p->tier[T_SSD].algo);
  if (!rf_resident(p, T_SSD, o->obj_id, o->obj_size)) return false;
  MD(o).flags |= RF_SSD;
  p->ssd_used += (uint64_t)o->obj_size;
  CNT(p, nand_write_bytes, MD(o).cls, (uint64_t)o->obj_size);
  return true;
}

static void rf_ssd_try_admit(rf_params_t *p, cache_obj_t *o, int src) {
  uint64_t s = (uint64_t)o->obj_size;
  if (s > p->ssd_max_obj) {
    CNT(p, too_large_objs, MD(o).cls, 1);
    CNT(p, too_large_bytes, MD(o).cls, s);
    return;
  }
  admissioner_t *a = p->cache->admissioner;
  if (a != NULL) {
    p->req_tmp->obj_id = o->obj_id;
    p->req_tmp->obj_size = o->obj_size;
    if (!a->admit(a, p->req_tmp)) {
      CNT(p, admit_reject_objs, MD(o).cls, 1);
      return;
    }
  }
  admit_info_t ai = {(uint64_t)p->t, o->obj_id, rf_u32(s), (uint8_t)src,
                     MD(o).dram_hits};
  if (!p->aops->accept(p->adm, &ai)) {
    CNT(p, admit_reject_objs, MD(o).cls, 1);
    return;
  }
  uint32_t c = rf_hint_insert(p, o, src);
  MD(o).cls = (uint8_t)c;
  MD(o).ssd_hits = 0;
  MD(o).admit_t = p->t;
  if (p->ssd_mode == SSD_OBJECT) {
    if (!rf_obj_write(p, o)) {  // the algorithm declined it
      CNT(p, admit_reject_objs, c, 1);
      return;
    }
  } else {
    rf_append(p, o, c);
  }
  CNT(p, ssd_admit_objs, c, 1);
  CNT(p, ssd_admit_bytes, c, s);
  SB(p, ssd_admit_objs, s, 1);
  SB(p, ssd_admit_bytes, s, s);
  p->admit_n[c]++;
  p->admit_b[c] += s;
}

// ***********************************************************************
// ****                            DRAM                               ****
// ***********************************************************************
/* an object leaving DRAM: skip the write if a valid SSD copy exists
 * (inclusion=cachelib), otherwise try to admit it to the SSD */
static void rf_victim(rf_params_t *p, cache_obj_t *v) {
  CNT(p, dram_evict_objs, MD(v).cls, 1);
  if (p->aops->on_dram_evict)
    p->aops->on_dram_evict(p->adm, v->obj_id, (uint32_t)v->obj_size);
  if ((MD(v).flags & RF_SSD) && p->inclusion == INC_CACHELIB) {
    CNT(p, clean_skip_objs, MD(v).cls, 1);
  } else {
    if (MD(v).flags & RF_SSD) rf_ssd_invalidate(p, v);
    rf_ssd_try_admit(p, v, SRC_DRAM_EVICT);
    if (MD(v).flags & RF_LOST) {
      if (MD(v).flags & RF_SSD) CNT(p, ssd_copy_lost_rewrites, MD(v).cls, 1);
      MD(v).flags &= ~RF_LOST;
    }
  }
  if (!(MD(v).flags & RF_SSD)) rf_obj_delete(p, v);
}

/* the requested object enters DRAM; DRAM's victims go to the SSD as they are
 * evicted. One the algorithm does not keep (too large, or declined) is a
 * victim itself. */
static void rf_dram_insert(rf_params_t *p, cache_obj_t *o) {
  MD(o).flags |= RF_DRAM;  // meanwhile, losing its SSD copy keeps the object
  if ((uint64_t)o->obj_size <= p->dram_cap) MD(o).dram_hits = 0;
  if (rf_tier_get(p, T_DRAM, p->req_local))
    rf_die("RegionFlash: dram-algo %s holds an object not tracked\n",
           p->tier[T_DRAM].algo);
  if (rf_resident(p, T_DRAM, o->obj_id, o->obj_size)) {
    p->dram_used += (uint64_t)o->obj_size;
    return;
  }
  MD(o).flags &= ~RF_DRAM;
  rf_victim(p, o);
}

static void rf_invalidate_all(rf_params_t *p, cache_obj_t *o) {
  if (MD(o).flags & RF_DRAM) {
    rf_tier_remove(p, T_DRAM, o->obj_id);
    p->dram_used -= (uint64_t)o->obj_size;
  }
  if (MD(o).flags & RF_SSD) rf_ssd_invalidate(p, o);
  rf_obj_delete(p, o);
}

// ***********************************************************************
// ****                       cache interface                         ****
// ***********************************************************************
static bool RegionFlash_get(cache_t *cache, const request_t *req) {
  rf_params_t *p = (rf_params_t *)cache->eviction_params;
  /* the CLI seeds libCacheSim's per-thread random numbers with the time
   * (bin/cachesim/sim.c), after the caches are made: reseed from `seed` so
   * that random inner algorithms (Random, LeCaR, LHD, ...) repeat */
  if (p->t == 0) set_rand_seed(p->seed * 6 + 6);
  rf_cur = p;
  cache_set_remove_hook(rf_on_remove, p);
  cache->n_req += 1;
  p->counting = p->t >= p->warmup;
  *p->req_local = *req;
  uint64_t s = req->obj_size > 0 ? (uint64_t)req->obj_size : 1;
  p->req_local->obj_size = (int64_t)s;

  bool hit = true, changed = false;
  int outcome = HINT_DRAM_HIT;
  cache_obj_t *o = hashtable_find_obj_id(cache->hashtable, req->obj_id);
  if (o != NULL && (uint64_t)o->obj_size != s) {  // size change: a new object
    rf_invalidate_all(p, o);
    o = NULL;
    changed = true;
  }
  uint32_t rc = o != NULL ? MD(o).cls : rf_class_of(p, s);
  CNT(p, reqs, rc, 1);
  CNT(p, req_bytes, rc, s);
  SB(p, reqs, s, 1);
  SB(p, req_bytes, s, s);
  if (changed) CNT(p, size_change_misses, rc, 1);

  if (o != NULL && (MD(o).flags & RF_DRAM)) {
    if (!rf_tier_get(p, T_DRAM, p->req_local))
      rf_die("RegionFlash: dram-algo %s lost an object\n", p->tier[T_DRAM].algo);
    if (MD(o).dram_hits < UINT8_MAX) MD(o).dram_hits++;
    CNT(p, dram_hits, rc, 1);
    CNT(p, hit_bytes, rc, s);
    CNT(p, dram_hit_bytes, rc, s);
    SB(p, dram_hits, s, 1);
    SB(p, dram_hit_bytes, s, s);
  } else {
    CNT(p, ssd_lookups, rc, 1);
    CNT(p, ssd_lookup_bytes, rc, s);
    SB(p, ssd_lookups, s, 1);
    SB(p, ssd_lookup_bytes, s, s);
    if (cache->admissioner != NULL && cache->admissioner->update != NULL)
      cache->admissioner->update(cache->admissioner, p->req_local, p->ssd_cap);
    if (p->aops->on_lookup)
      p->aops->on_lookup(p->adm, (uint64_t)p->t, req->obj_id, rf_u32(s));
    outcome = HINT_SSD_HIT;
    if (o != NULL && (MD(o).flags & RF_SSD)) {  // every piece is still there
      CNT(p, ssd_hits, rc, 1);
      CNT(p, hit_bytes, rc, s);
      CNT(p, ssd_hit_bytes, rc, s);
      SB(p, ssd_hits, s, 1);
      SB(p, ssd_hit_bytes, s, s);
      rf_ssd_hit(p, o);
      if (MD(o).ssd_hits < UINT16_MAX) MD(o).ssd_hits++;
      rf_hint_req(p, p->hops->on_find, req->obj_id, s, rc, HINT_SSD_HIT);
      if (p->dram_cap) {  // promote
        if (p->inclusion == INC_EXCLUSIVE) rf_ssd_invalidate(p, o);
        rf_dram_insert(p, o);
      }
    } else {
      hit = false;
      outcome = HINT_MISS;
      rf_hint_req(p, p->hops->on_find, req->obj_id, s, rc, HINT_MISS);
      CNT(p, misses, rc, 1);
      CNT(p, miss_bytes, rc, s);
      SB(p, misses, s, 1);
      SB(p, miss_bytes, s, s);
      if (o == NULL) {
        o = hashtable_insert(cache->hashtable, p->req_local);
        p->n_obj++;
        MD(o).cls = (uint8_t)rc;
        MD(o).loc = RF_NONE;
      }
      o->next_access_vtime = req->next_access_vtime;
      if (p->dram_cap) {
        rf_dram_insert(p, o);
      } else {
        rf_ssd_try_admit(p, o, SRC_MISS);
        if (!(MD(o).flags & RF_SSD)) rf_obj_delete(p, o);
      }
    }
  }
  if (p->hops->on_get) {
    rf_hint_req(p, p->hops->on_get, req->obj_id, s, rc, outcome);
    rf_epoch_check(p);
  }
  rf_reg_flush(p);
  o = hashtable_find_obj_id(cache->hashtable, req->obj_id);
  if (o != NULL) o->next_access_vtime = req->next_access_vtime;
  p->t++;
  if (p->interval && (uint64_t)p->t - p->ival_start == p->interval)
    rf_interval_end(p);
  cache_set_remove_hook(NULL, NULL);
  rf_cur = NULL;
  rf_check(p);
  return hit;
}

static cache_obj_t *RegionFlash_find(cache_t *cache, const request_t *req,
                                     bool update_cache) {
  return hashtable_find_obj_id(cache->hashtable, req->obj_id);
}

static cache_obj_t *RegionFlash_insert(cache_t *cache, const request_t *req) {
  rf_die("RegionFlash: insert/evict/to_evict are driven by get()\n");
}

static void RegionFlash_evict(cache_t *cache, const request_t *req) {
  rf_die("RegionFlash: insert/evict/to_evict are driven by get()\n");
}

static cache_obj_t *RegionFlash_to_evict(cache_t *cache, const request_t *req) {
  rf_die("RegionFlash: insert/evict/to_evict are driven by get()\n");
}

static bool RegionFlash_remove(cache_t *cache, obj_id_t obj_id) {
  cache_obj_t *o = hashtable_find_obj_id(cache->hashtable, obj_id);
  if (o == NULL) return false;
  rf_invalidate_all((rf_params_t *)cache->eviction_params, o);
  return true;
}

static int64_t RegionFlash_get_occupied_byte(const cache_t *cache) {
  const rf_params_t *p = (const rf_params_t *)cache->eviction_params;
  return (int64_t)(p->dram_used + p->ssd_used);
}

static int64_t RegionFlash_get_n_obj(const cache_t *cache) {
  return ((const rf_params_t *)cache->eviction_params)->n_obj;
}

// ***********************************************************************
// ****                           report                              ****
// ***********************************************************************
static double rf_div(uint64_t a, uint64_t b) {
  return b ? (double)a / (double)b : NAN;
}

#define RF_DERIVED(X)                                                     \
  X(ohr, rf_div(c->dram_hits + c->ssd_hits, c->reqs))                     \
  X(bmr, rf_div(c->miss_bytes, c->req_bytes))                             \
  X(ssd_hit_ratio, rf_div(c->ssd_hits, c->ssd_lookups))                   \
  X(alwa_region, rf_div(c->flash_region_write_bytes, c->ssd_admit_bytes)) \
  X(dlwa, rf_div(c->nand_write_bytes, c->flash_region_write_bytes))       \
  X(waf_total, rf_div(c->nand_write_bytes, c->ssd_admit_bytes))           \
  X(dead_evict_byte_frac, rf_div(c->dead_evict_bytes, c->ssd_evict_bytes)) \
  X(mean_ssd_residence, rf_div(c->res_sum, c->ssd_evict_objs))             \
  RF_MISS_RATIOS(X)

/* object / byte miss ratios of the whole system, of DRAM (it sees every
 * request) and of the SSD (it sees DRAM's misses): omr = dram_omr * ssd_omr */
#define RF_MISS_RATIOS(X)                                                    \
  X(omr, rf_div(c->misses, c->reqs))                                         \
  X(dram_omr, rf_div(c->reqs - c->dram_hits, c->reqs))                       \
  X(dram_bmr, rf_div(c->req_bytes - c->dram_hit_bytes, c->req_bytes))        \
  X(ssd_omr, rf_div(c->ssd_lookups - c->ssd_hits, c->ssd_lookups))           \
  X(ssd_bmr, rf_div(c->ssd_lookup_bytes - c->ssd_hit_bytes, c->ssd_lookup_bytes))

#define RF_SB_DERIVED(X) \
  X(bmr, rf_div(c->miss_bytes, c->req_bytes)) RF_MISS_RATIOS(X)

static void rf_num(FILE *f, double v) {
  if (isfinite(v))
    fprintf(f, "%.6g", v);
  else
    fputs("null", f);
}

static void rf_csv_num(FILE *f, double v) {  // empty field for NaN
  if (isfinite(v)) fprintf(f, "%.6g", v);
}

/* the fields of one JSON object, then its closing brace */
static void rf_json_ctr(FILE *f, const rf_ctr_t *c) {
  const char *sep = "";
#define X(n)                                                           \
  fprintf(f, "%s\"%s\": %llu", sep, #n, (unsigned long long)c->n); \
  sep = ", ";
  RF_CTRS(X)
#undef X
#define X(n, e)                        \
  fprintf(f, ", \"%s\": ", #n); \
  rf_num(f, e);
  RF_DERIVED(X)
#undef X
  fputc('}', f);
}

/* CSV: the header names and the values of a row (no newline) */
static void rf_csv_head(FILE *f) {
#define X(n) fputs("," #n, f);
  RF_CTRS(X)
#undef X
#define X(n, e) fputs("," #n, f);
  RF_DERIVED(X)
#undef X
}

static void rf_csv_ctr(FILE *f, const rf_ctr_t *c) {
#define X(n) fprintf(f, ",%llu", (unsigned long long)c->n);
  RF_CTRS(X)
#undef X
#define X(n, e)  \
  fputc(',', f); \
  rf_csv_num(f, e);
  RF_DERIVED(X)
#undef X
}

static void rf_csv_sb_head(FILE *f) {
#define X(n) fputs("," #n, f);
  RF_SB_CTRS(X)
#undef X
#define X(n, e) fputs("," #n, f);
  RF_SB_DERIVED(X)
#undef X
}

static void rf_csv_sb(FILE *f, const rf_sb_ctr_t *c) {
#define X(n) fprintf(f, ",%llu", (unsigned long long)c->n);
  RF_SB_CTRS(X)
#undef X
#define X(n, e)  \
  fputc(',', f); \
  rf_csv_num(f, e);
  RF_SB_DERIVED(X)
#undef X
}

/* the (lo, hi] a hint class covers under the current bounds */
static void rf_csv_span(FILE *f, const rf_params_t *p, uint32_t c) {
  int64_t lo = 0, hi = 0;
  bool any = false, inf = false;
  for (uint32_t i = 0; i <= p->ntau; i++) {
    if (p->ivcls[i] != c) continue;
    int64_t l = i ? p->taus[i - 1] : 0;
    if (!any || l < lo) lo = l;
    if (i == p->ntau)
      inf = true;
    else if (!any || p->taus[i] > hi)
      hi = p->taus[i];
    any = true;
  }
  if (!any)
    fputs(",,", f);  // not used now (the hot class of reinsert mode=ii, ...)
  else if (inf)
    fprintf(f, ",%lld,inf", (long long)lo);
  else
    fprintf(f, ",%lld,%lld", (long long)lo, (long long)hi);
}

/* the directories of the path prefix (parallel runs: out=runs/a/x, ...) */
static void rf_mkdirs(const char *prefix) {
  char d[300];
  snprintf(d, sizeof(d), "%s", prefix);
  for (char *q = d + 1; *q; q++) {
    if (*q != '/') continue;
    *q = '\0';
    if (mkdir(d, 0755) != 0 && errno != EEXIST)
      rf_die("RegionFlash: cannot make %s: %s\n", d, strerror(errno));
    *q = '/';
  }
}

static FILE *rf_open(const rf_params_t *p, const char *suffix) {
  char path[320];
  snprintf(path, sizeof(path), "%s%s", p->out, suffix);
  FILE *f = fopen(path, "w");
  if (f == NULL) rf_die("RegionFlash: cannot open %s: %s\n", path, strerror(errno));
  return f;
}

static void rf_interval_open(rf_params_t *p) {
  p->f_iv = rf_open(p, ".interval.csv");
  fputs("interval,kind,phase,t_start,t_end,clock_time", p->f_iv);
  rf_csv_head(p->f_iv);
  fputs(",ssd_valid_bytes,dram_bytes,free_regions,hint_epoch,n_bounds\n", p->f_iv);
  p->f_ivc = rf_open(p, ".interval.class.csv");
  fputs("interval,kind,phase,t_end,class,lo,hi", p->f_ivc);
  rf_csv_head(p->f_ivc);
  fputc('\n', p->f_ivc);
  p->f_ivs = rf_open(p, ".interval.sizebin.csv");
  fputs("interval,kind,phase,t_end,bin,lo,hi", p->f_ivs);
  rf_csv_sb_head(p->f_ivs);
  fputc('\n', p->f_ivs);
}

/* an interval ended: one "interval" row (its own counts, warm-up included)
 * and one "cumulative" row (after the warm-up, so far) per scope */
static void rf_interval_end(rf_params_t *p) {
  const char *ph = p->t - 1 < p->warmup ? "warmup" : "measure";
  unsigned long long n = (unsigned long long)p->n_ival;
  long long t = (long long)p->t;
  for (int k = 0; p->f_iv != NULL && k < 2; k++) {
    const char *kind = k ? "cumulative" : "interval";
    fprintf(p->f_iv, "%llu,%s,%s,%llu,%lld,%lld", n, kind, ph,
            (unsigned long long)p->ival_start, t, (long long)p->req_local->clock_time);
    rf_csv_ctr(p->f_iv, k ? &p->tot : &p->win);
    fprintf(p->f_iv, ",%llu,%llu,%u,%u,%u\n", (unsigned long long)p->ssd_used,
            (unsigned long long)p->dram_used, p->nfree, p->epoch, p->ntau);
    for (uint32_t c = 0; c < p->kmax; c++) {
      fprintf(p->f_ivc, "%llu,%s,%s,%lld,%u", n, kind, ph, t, c);
      rf_csv_span(p->f_ivc, p, c);
      rf_csv_ctr(p->f_ivc, k ? &p->cls[c] : &p->cwin[c]);
      fputc('\n', p->f_ivc);
    }
    for (uint32_t b = 0; b < RF_SB_N; b++) {
      fprintf(p->f_ivs, "%llu,%s,%s,%lld,%u,%llu,%llu", n, kind, ph, t, b,
              (unsigned long long)rf_size_bin_lo(b), (unsigned long long)rf_size_bin_hi(b));
      rf_csv_sb(p->f_ivs, k ? &p->sb_cum[b] : &p->sb_cur[b]);
      fputc('\n', p->f_ivs);
    }
  }
  memcpy(p->sb_last, p->sb_cur, sizeof(p->sb_last));
  memset(p->sb_cur, 0, sizeof(p->sb_cur));
  memset(&p->win, 0, sizeof(p->win));
  memset(p->cwin, 0, sizeof(p->cwin));
  p->n_ival++;
  p->ival_start = (uint64_t)p->t;
}

/* regionflash_stats.h */
static void rf_size_view_fill(const rf_params_t *p, rf_size_view_t *v) {
  v->t = (uint64_t)p->t;
  v->interval = p->interval;
  v->n_interval = p->n_ival;
  v->measuring = p->t >= p->warmup;
  v->cum = p->sb_cum;
  v->cur = p->sb_cur;
  v->last = p->sb_last;
}

bool regionflash_size_view(rf_size_view_t *v) {
  if (rf_cur == NULL) return false;
  rf_size_view_fill(rf_cur, v);
  return true;
}

bool regionflash_size_view_of(const cache_t *cache, rf_size_view_t *v) {
  if (cache == NULL || cache->cache_init != RegionFlash_init) return false;
  rf_size_view_fill((const rf_params_t *)cache->eviction_params, v);
  return true;
}

/* "fifo", "beta", ... or "lcs:<algorithm>" */
static const char *rf_rev_name(const rf_params_t *p, char *buf, size_t n) {
  if (p->rev != REV_LCS) return REV_NAME[p->rev];
  snprintf(buf, n, "lcs:%s", p->tier[T_REG].algo);
  return buf;
}

static void rf_report(const rf_params_t *p) {
  const rf_fdp_t *fd = &p->fdp;
  char rev[80];
  const char *dram = p->dram_cap ? p->tier[T_DRAM].algo : "none";
  const char *ssd = p->ssd_mode == SSD_OBJECT ? p->tier[T_SSD].algo
                                               : rf_rev_name(p, rev, sizeof(rev));
  printf("[RegionFlash] SSD %llu B (%s, %s; %u regions x %llu B), DRAM %llu B "
         "(%s), %s, hint %s (k=%u), chunk %llu, FDP %s, admit %s\n",
         (unsigned long long)p->ssd_cap, SSD_NAME[p->ssd_mode], ssd, p->N,
         (unsigned long long)p->R, (unsigned long long)p->dram_cap, dram,
         INC_NAME[p->inclusion], p->spec[1], p->kmax,
         (unsigned long long)p->chunk, p->fdp_on ? "on" : "off", p->spec[0]);
  printf("%6s %12s %8s %8s %8s %8s %16s %16s %16s %8s\n", "class", "reqs", "OMR",
         "BMR", "DRAM_OMR", "SSD_OMR", "ssd_admit_B", "region_write_B",
         "nand_write_B", "DLWA");
  for (uint32_t k = 0; k <= p->kmax; k++) {
    const rf_ctr_t *c = k == 0 ? &p->tot : &p->cls[k - 1];
    char name[16] = "total";
    if (k > 0) snprintf(name, sizeof(name), "%u", k - 1);
    printf("%6s %12llu %8.4f %8.4f %8.4f %8.4f %16llu %16llu %16llu %8.4f\n", name,
           (unsigned long long)c->reqs, rf_div(c->misses, c->reqs),
           rf_div(c->miss_bytes, c->req_bytes), rf_div(c->reqs - c->dram_hits, c->reqs),
           rf_div(c->ssd_lookups - c->ssd_hits, c->ssd_lookups),
           (unsigned long long)c->ssd_admit_bytes,
           (unsigned long long)c->flash_region_write_bytes,
           (unsigned long long)c->nand_write_bytes,
           rf_div(c->nand_write_bytes, c->flash_region_write_bytes));
  }
  if (p->out[0] == '\0') return;

  char re[160] = "none";
  if (p->re_on)
    snprintf(re, sizeof(re),
             "hits:n=%u,max_size=%llu,p=%g,max_frac=%g,mode=%s,class=%s,hint_on_reinsert=%s",
             p->re_n, (unsigned long long)p->re_max_size, p->re_p, p->re_frac,
             p->re_ii ? "ii" : "pi", p->re_reclass ? "reclassify" : "keep",
             p->re_hint ? "yes" : "no");
  FILE *f = rf_open(p, ".json");
  fprintf(f,
          "{\"config\": {\"ssd_size\": %llu, \"ssd_mode\": \"%s\", "
          "\"ssd_algo\": \"%s\", \"region_size\": %llu, \"n_regions\": %u, "
          "\"k\": %u, \"dram_size\": %llu, \"dram_policy\": \"%s\", "
          "\"inclusion\": \"%s\", \"region_evict\": \"%s\", \"beta\": %g, "
          "\"chunk\": %llu, \"seal_on_repartition\": \"%s\", \"hint\": \"%s\", \"warmup_req\": %lld, "
          "\"interval_req\": %llu, \"reinsert\": \"%s\", \"taus\": [",
          (unsigned long long)p->ssd_cap, SSD_NAME[p->ssd_mode],
          p->ssd_mode == SSD_OBJECT ? p->tier[T_SSD].algo : "", (unsigned long long)p->R,
          p->N, p->kmax, (unsigned long long)p->dram_cap, dram,
          INC_NAME[p->inclusion], rf_rev_name(p, rev, sizeof(rev)), p->beta,
          (unsigned long long)p->chunk, SEAL_NAME[p->seal_rep], p->pv[1].name, (long long)p->warmup,
          (unsigned long long)p->interval, re);
  for (uint32_t i = 0; i < p->ntau; i++)
    fprintf(f, "%s%lld", i ? ", " : "", (long long)p->taus[i]);
  fputs("], \"fdp\": ", f);
  if (p->fdp_on)
    fprintf(f,
            "{\"ru_size\": %llu, \"n_ru\": %u, \"slots_per_ru\": %u, "
            "\"n_ruh\": %u, \"isolation\": \"%s\", \"op\": %g, \"trim\": %s}",
            (unsigned long long)fd->ru_size, fd->n_ru, fd->spr, fd->n_ruh,
            fd->pi ? "pi" : "ii", fd->op, fd->trim ? "true" : "false");
  else
    fputs("null", f);
  fputs("},\n\"total\": {", f);
  rf_json_ctr(f, &p->tot);
  fputs(",\n\"class\": [", f);
  for (uint32_t c = 0; c < p->kmax; c++) {
    fprintf(f, "%s\n{\"class\": %u, ", c ? "," : "", c);
    rf_json_ctr(f, &p->cls[c]);
  }
  fputs("],\n\"ruh\": [", f);
  for (uint32_t d = 0; p->fdp_on && d <= fd->n_ruh; d++)
    fprintf(f, "%s\n{\"ruh\": %d, \"host_write_bytes\": %llu, "
               "\"gc_write_bytes\": %llu}",
            d ? "," : "", d < fd->n_ruh ? (int)d : -1,
            (unsigned long long)fd->ruh_host[d],
            (unsigned long long)fd->ruh_gc[d]);
  fputs("],\n\"sizebin\": [", f);  // whole-object sizes, (lo, hi]
  for (uint32_t b = 0; b < RF_SB_N; b++) {
    const rf_sb_ctr_t *c = &p->sb_cum[b];
    fprintf(f, "%s\n{\"bin\": %u, \"lo\": %llu, \"hi\": %llu", b ? "," : "", b,
            (unsigned long long)rf_size_bin_lo(b), (unsigned long long)rf_size_bin_hi(b));
#define X(n) fprintf(f, ", \"%s\": %llu", #n, (unsigned long long)c->n);
    RF_SB_CTRS(X)
#undef X
#define X(n, e)                 \
  fprintf(f, ", \"%s\": ", #n); \
  rf_num(f, e);
    RF_SB_DERIVED(X)
#undef X
    fputc('}', f);
  }
  fputs("],\n\"admit\": ", f);  // as cachesim summary.json: params, report()
  pv_json(f, &p->pv[0]);
  fputs(",\n\"admit_result\": ", f);
  if (p->aops->report) p->aops->report(p->adm, f); else fputs("null", f);
  fputs(",\n\"hint\": ", f);
  pv_json(f, &p->pv[1]);
  fputs(",\n\"hint_result\": ", f);
  if (p->hops->report) p->hops->report(p->hint, f); else fputs("null", f);
  fputs("}\n", f);
  fclose(f);

  f = rf_open(p, ".class.csv");
  fputs("class,lo,hi", f);
  rf_csv_head(f);
  fputs("\ntotal,,", f);
  rf_csv_ctr(f, &p->tot);
  fputc('\n', f);
  for (uint32_t c = 0; c < p->kmax; c++) {
    fprintf(f, "%u", c);
    rf_csv_span(f, p, c);
    rf_csv_ctr(f, &p->cls[c]);
    fputc('\n', f);
  }
  fclose(f);

  f = rf_open(p, ".sizebin.csv");
  fputs("bin,lo,hi", f);
  rf_csv_sb_head(f);
  fputc('\n', f);
  for (uint32_t b = 0; b < RF_SB_N; b++) {
    fprintf(f, "%u,%llu,%llu", b, (unsigned long long)rf_size_bin_lo(b),
            (unsigned long long)rf_size_bin_hi(b));
    rf_csv_sb(f, &p->sb_cum[b]);
    fputc('\n', f);
  }
  fclose(f);
}

static void RegionFlash_free(cache_t *cache) {
  rf_params_t *p = (rf_params_t *)cache->eviction_params;
  rf_fdp_t *f = &p->fdp;
  if (p->interval && (uint64_t)p->t > p->ival_start) rf_interval_end(p);  // the last, shorter one
  if (p->f_iv != NULL) {
    fclose(p->f_iv);
    fclose(p->f_ivc);
    fclose(p->f_ivs);
  }
  rf_report(p);
  p->hops->destroy(p->hint);
  p->aops->destroy(p->adm);
  for (int k = 0; k < 2; k++) {
    for (int i = 0; i < p->pv[k].n; i++) free(p->pv[k].val[i]);
    free((char *)p->pv[k].name);
  }
  for (int t = 0; t < T_N; t++) {
    rf_tier_t *x = &p->tier[t];
    if (x->c != NULL) {
      x->c->evict = x->evict0;
      x->c->cache_free(x->c);
    }
    free(x->cand);
  }
  for (uint32_t r = 0; r < p->N; r++) free(p->reg[r].ent);
  free(p->reg);
  free(p->rfree);
  free(p->pend);
  free(p->pc);
  free(p->pcfree);
  free(f->slot_reg);
  free(f->slot_cls);
  free(f->ru_valid);
  free(f->ru_fill);
  free(f->ru_tag);
  free(f->free_ru);
  free(f->dest_ru);
  free(f->reg_slot);
  free(f->ruh_host);
  free(f->ruh_gc);
  free_request(p->req_local);
  free_request(p->req_tmp);
  free_request(p->req_ssd);
  free_request(p->req_reg);
  free_request(p->req_re);
  free(p->rebuf);
  free(p);
  cache_struct_free(cache);
}

// ***********************************************************************
// ****                       parameters / init                       ****
// ***********************************************************************
/* "626M", "4G", "1.5K" -> bytes (binary units) */
static uint64_t rf_size(const char *v) {
  char *end;
  double x = strtod(v, &end);
  switch (*end) {
    case 'k': case 'K': x *= KiB; break;
    case 'm': case 'M': x *= MiB; break;
    case 'g': case 'G': x *= GiB; break;
    case 't': case 'T': x *= TiB; break;
    default: break;
  }
  if (x < 0) rf_die("RegionFlash: bad size %s\n", v);
  return (uint64_t)x;
}

static int rf_enum(const char *v, const char *const *names, int n,
                   const char *key) {
  for (int i = 0; i < n; i++)
    if (strcasecmp(v, names[i]) == 0) return i;
  rf_die("RegionFlash: bad value %s for %s\n", v, key);
}

/* reinsert=none | hits[:n=1/max_size=0/p=1/max_frac=0.5/mode=pi|ii/
 *                       class=keep|reclassify/hint_on_reinsert=no|yes]
 * (cachesim --reinsert, with '/' for ',') */
static void rf_parse_reinsert(rf_params_t *p, char *v) {
  static const char *const MODE[] = {"pi", "ii"}, *const CLS[] = {"keep", "reclassify"},
                           *const YN[] = {"no", "yes"};
  char *rest = strchr(v, ':');
  if (rest != NULL) *rest++ = '\0';
  p->re_on = rf_enum(v, (const char *const[]){"none", "hits"}, 2, "reinsert");
  for (char *kv; rest != NULL && (kv = strsep(&rest, "/")) != NULL;) {
    char *val = strchr(kv, '=');
    if (val == NULL) rf_die("RegionFlash: reinsert %s has no value\n", kv);
    *val++ = '\0';
    if (strcasecmp(kv, "n") == 0) p->re_n = (uint32_t)atoi(val);
    else if (strcasecmp(kv, "max_size") == 0) p->re_max_size = rf_size(val);
    else if (strcasecmp(kv, "p") == 0) p->re_p = strtod(val, NULL);
    else if (strcasecmp(kv, "max_frac") == 0) p->re_frac = strtod(val, NULL);
    else if (strcasecmp(kv, "mode") == 0) p->re_ii = rf_enum(val, MODE, 2, kv);
    else if (strcasecmp(kv, "class") == 0) p->re_reclass = rf_enum(val, CLS, 2, kv);
    else if (strcasecmp(kv, "hint_on_reinsert") == 0) p->re_hint = rf_enum(val, YN, 2, kv);
    else rf_die("RegionFlash: reinsert does not have parameter %s\n", kv);
  }
}

static void rf_parse(rf_params_t *p, const char *params, char algo[T_N][64]) {
  static const char *const ISO[] = {"ii", "pi"};
  char *str = strdup(params), *cur = str;
  while (cur != NULL && cur[0] != '\0') {
    char *key = strsep(&cur, "="), *value = strsep(&cur, ",");
    while (cur != NULL && *cur == ' ') cur++;
    if (value == NULL) rf_die("RegionFlash: parameter %s has no value\n", key);
    if (strcasecmp(key, "dram-size") == 0) p->dram_cap = rf_size(value);
    else if (strcasecmp(key, "dram-algo") == 0 || strcasecmp(key, "dram-policy") == 0)
      snprintf(algo[T_DRAM], 64, "%s", value);
    else if (strcasecmp(key, "dram-params") == 0) snprintf(p->params[T_DRAM], 256, "%s", value);
    else if (strcasecmp(key, "inclusion") == 0) p->inclusion = rf_enum(value, INC_NAME, 3, key);
    else if (strcasecmp(key, "ssd-mode") == 0) p->ssd_mode = rf_enum(value, SSD_NAME, 2, key);
    else if (strcasecmp(key, "ssd-algo") == 0) snprintf(algo[T_SSD], 64, "%s", value);
    else if (strcasecmp(key, "ssd-params") == 0) snprintf(p->params[T_SSD], 256, "%s", value);
    else if (strcasecmp(key, "region-size") == 0) p->R = rf_size(value);
    else if (strcasecmp(key, "region-evict") == 0) {  // built-in, or lcs:<algorithm>
      bool lcs = strncasecmp(value, "lcs:", 4) == 0;
      p->rev = REV_LCS;
      for (int i = 0; i < 3 && !lcs; i++)
        if (strcasecmp(value, REV_NAME[i]) == 0) p->rev = i;
      snprintf(algo[T_REG], 64, "%s", value + (lcs ? 4 : 0));
    } else if (strcasecmp(key, "region-params") == 0) snprintf(p->params[T_REG], 256, "%s", value);
    else if (strcasecmp(key, "beta") == 0) p->beta = strtod(value, NULL);
    else if (strcasecmp(key, "chunk") == 0) p->chunk = rf_size(value);
    else if (strcasecmp(key, "seal-on-repartition") == 0) p->seal_rep = rf_enum(value, SEAL_NAME, 3, key);
    else if (strcasecmp(key, "admit") == 0) snprintf(p->spec[0], 256, "%s", value);
    else if (strcasecmp(key, "hint") == 0) snprintf(p->spec[1], 256, "%s", value);
    else if (strcasecmp(key, "taus") == 0) snprintf(p->taus_s, 256, "%s", value);
    else if (strcasecmp(key, "st-lambda") == 0) snprintf(p->lambda_s, 32, "%s", value);
    else if (strcasecmp(key, "seed") == 0) p->seed = strtoull(value, NULL, 10);
    else if (strcasecmp(key, "warmup-req") == 0) p->warmup = atoll(value);
    else if (strcasecmp(key, "ru-size") == 0) p->fdp.ru_size = rf_size(value);
    else if (strcasecmp(key, "ruh") == 0) p->fdp.n_ruh = (uint32_t)atoi(value);
    else if (strcasecmp(key, "fdp-iso") == 0) p->fdp.pi = rf_enum(value, ISO, 2, key);
    else if (strcasecmp(key, "fdp-op") == 0) p->fdp.op = strtod(value, NULL);
    else if (strcasecmp(key, "fdp-trim") == 0) p->fdp.trim = atoi(value) != 0;
    else if (strcasecmp(key, "reinsert") == 0) rf_parse_reinsert(p, value);
    else if (strcasecmp(key, "out") == 0 || strcasecmp(key, "prefix") == 0)
      snprintf(p->out, sizeof(p->out), "%s", value);
    else if (strcasecmp(key, "interval") == 0) p->interval = strtoull(value, NULL, 10);
    else rf_die("RegionFlash does not have parameter %s\n", key);
  }
  free(str);
}

cache_t *RegionFlash_init(const common_cache_params_t ccache_params,
                          const char *cache_specific_params) {
  cache_t *cache =
      cache_struct_init("RegionFlash", ccache_params, cache_specific_params);
  cache->cache_init = RegionFlash_init;
  cache->cache_free = RegionFlash_free;
  cache->get = RegionFlash_get;
  cache->find = RegionFlash_find;
  cache->insert = RegionFlash_insert;
  cache->evict = RegionFlash_evict;
  cache->remove = RegionFlash_remove;
  cache->to_evict = RegionFlash_to_evict;
  cache->get_occupied_byte = RegionFlash_get_occupied_byte;
  cache->get_n_obj = RegionFlash_get_n_obj;
  cache->obj_md_size = 0;

  rf_params_t *p = calloc(1, sizeof(rf_params_t));
  cache->eviction_params = p;
  p->cache = cache;
  p->req_local = new_request();
  p->req_tmp = new_request();
  p->req_ssd = new_request();
  p->req_reg = new_request();
  p->req_re = new_request();
  p->active = -1;
  p->re_n = 1;
  p->re_p = 1.0;
  p->re_frac = 0.5;
  p->R = 16 * MiB;
  p->inclusion = INC_CACHELIB;
  p->rev = REV_LRU;
  snprintf(p->spec[0], 256, "all");
  snprintf(p->spec[1], 256, "none");
  p->seed = 1;  // cachesim --seed
  p->interval = 1000000;  // cachesim --window
  p->ssd_mode = SSD_REGION;
  p->fdp.n_ruh = 8;
  p->fdp.op = 0.07;
  char algo[T_N][64] = {"lru", "lru", "lru"};
  if (cache_specific_params != NULL) rf_parse(p, cache_specific_params, algo);

  if (!p->re_on) p->re_ii = p->re_reclass = p->re_hint = false;
  if (p->re_on) {  // the same checks as cachesim main.c
    if (p->re_reclass && !p->re_hint)
      rf_die("RegionFlash: reinsert class=reclassify requires hint_on_reinsert=yes\n");
    if (p->re_ii && p->re_reclass)
      rf_die("RegionFlash: reinsert mode=ii puts every reinserted object in one hot stream\n");
    if (!(p->re_frac > 0 && p->re_frac <= 1)) rf_die("RegionFlash: reinsert max_frac must be in (0, 1]\n");
    if (!(p->re_p > 0 && p->re_p <= 1)) rf_die("RegionFlash: reinsert p must be in (0, 1]\n");
    /* n=0 with p=1 rewrites every evicted object that fits the budget, every
     * time: with the padding of the regions it fills, an eviction may free
     * nothing and never end. n >= 1 cannot loop (ssd_hits is reset to 0) */
    if (p->re_n == 0 && p->re_p >= 1)
      rf_die("RegionFlash: reinsert n=0 needs p < 1 (CacheLib's percentage policy)\n");
    if (p->ssd_mode == SSD_OBJECT && (p->re_ii || p->re_reclass || p->re_n == 0))
      rf_die("RegionFlash: ssd-mode=object reinserts in place: mode=ii and class=reclassify "
             "need ssd-mode=region, and n must be >= 1\n");
  }
  p->ssd_cap = ccache_params.cache_size;
  p->fdp_on = p->fdp.ru_size > 0;

  /* the hint decides k (cachesim --k-max auto); its rng streams as cachesim's */
  char spec[300];
  snprintf(spec, sizeof(spec), "%s", p->spec[1]);
  if (strcmp(spec, "fixed") == 0 && p->taus_s[0])  // old spellings
    snprintf(spec, sizeof(spec), "fixed:%s", p->taus_s);
  if (strcmp(spec, "split_threshold") == 0 && p->lambda_s[0])
    snprintf(spec, sizeof(spec), "split_threshold:lambda=%s", p->lambda_s);
  rng_seed(&p->rng_a, p->seed * 6 + 4);
  rng_seed(&p->rng_h, p->seed * 6 + 5);
  rng_seed(&p->rng_re, p->seed * 6 + 6);
  bool native;
  const void *h = rf_plugin(1, spec, &p->pv[1], &native);
  uint32_t envk = RF_KMAX - (p->re_ii ? 1 : 0);
  hint_env_t he = {envk, p->ssd_mode == SSD_REGION ? p->R : 0, 1.0, &p->rng_h, NULL};
  p->hops = native ? h : &rf_hint_cachesim_ops;
  if (native ? p->hops->create(&p->hint, &p->pv[1], &he) != 0
             : (p->hint = rf_hint_cachesim(h, &p->pv[1], &he)) == NULL)
    rf_die("RegionFlash: cannot create hint\n");
  p->khint = p->hops->max_classes(p->hint);
  if (p->khint < 1 || p->khint > envk)
    rf_die("RegionFlash: hint %s needs %u classes, %u available\n", p->pv[1].name, p->khint, envk);
  p->kmax = p->khint + (p->re_ii ? 1 : 0);  // ii: one more stream, the hot class
  p->epoch = p->hops->epoch(p->hint);
  rf_refresh_map(p);
  if (p->dram_cap) rf_tier_init(p, T_DRAM, algo[T_DRAM], ccache_params, p->dram_cap);

  if (p->ssd_mode == SSD_OBJECT) {
    if (p->chunk || p->fdp_on || p->rev != REV_LRU)
      rf_die("RegionFlash: chunk, ru-size and region-evict need ssd-mode=region\n");
    p->ssd_max_obj = p->ssd_cap;
    rf_tier_init(p, T_SSD, algo[T_SSD], ccache_params, p->ssd_cap);
  } else {
    if (p->R == 0 || p->ssd_cap / p->R > UINT32_MAX)
      rf_die("RegionFlash: bad region-size\n");
    if (p->chunk > p->R)  // a piece must fit in one region (cachesim main.c)
      rf_die("RegionFlash: chunk must be <= region-size\n");
    p->N = (uint32_t)(p->ssd_cap / p->R);
    if (p->N < p->kmax + 2)
      rf_die("RegionFlash: N = %u regions < k + 2 = %u\n", p->N, p->kmax + 2);
    p->ssd_max_obj = p->chunk ? (uint64_t)(p->N - p->kmax - 1) * p->R : p->R;
    p->reg = calloc(p->N, sizeof(rf_region_t));
    p->rfree = malloc(p->N * sizeof(uint32_t));
    for (uint32_t r = 0; r < p->N; r++) p->rfree[r] = p->N - 1 - r;  // 0 first
    p->nfree = p->N;
    if (p->fdp_on) fdp_init(p);
    if (p->rev == REV_LCS) {
      common_cache_params_t cp = ccache_params;
      cp.hashpower = 4;
      while (cp.hashpower < 30 && (1u << cp.hashpower) < p->N) cp.hashpower++;
      rf_tier_init(p, T_REG, algo[T_REG], cp, (uint64_t)p->N * p->R);
    }
  }
  admission_env_t ae = {&p->rng_a, p->ssd_mode == SSD_REGION ? (uint64_t)p->N * p->R : p->ssd_cap,
                        p->ssd_mode == SSD_REGION ? p->R : p->ssd_cap};  // before chunk (cachesim)
  p->aops = rf_plugin(0, p->spec[0], &p->pv[0], NULL);
  if (p->aops->create(&p->adm, &p->pv[0], &ae)) rf_die("RegionFlash: cannot create admit\n");
  for (uint32_t c = 0; c < RF_KMAX; c++) p->open[c] = RF_NONE;
  if (p->out[0] != '\0') {
    rf_mkdirs(p->out);
    if (p->interval) rf_interval_open(p);
  }

  char rev[80];
  snprintf(cache->cache_name, CACHE_NAME_ARRAY_LEN, "RegionFlash-%.20s-%.24s%s",
           p->dram_cap ? algo[T_DRAM] : "none",
           p->ssd_mode == SSD_OBJECT ? algo[T_SSD] : rf_rev_name(p, rev, sizeof(rev)),
           p->fdp_on ? "-fdp" : "");
  return cache;
}

#ifdef __cplusplus
}
#endif
