//
//  split_threshold_req.c — SplitThreshold counted per request: the hint
//  split_threshold_req (with depth > 1, as st_recursive).
//
//  cachesim's split_threshold observes objects: count[b] and all_bytes[b]
//  add each object written to the SSD (on_insert), cold_bytes[b] each one
//  that leaves the SSD without a hit (on_evict, freq <= 1), so its medians
//  describe what is written. This one observes requests (on_get): count[b]
//  and all_bytes[b] add every request (scope=all) or every request that
//  reaches the SSD, a DRAM miss (scope=ssd), and cold_bytes[b] the requests
//  among them that missed. Its medians are weighted by popularity: count_p50
//  is the median requested size, byte_p50 the size below which half of the
//  requested bytes are. b = floor(log2(size + size_add)), size the whole
//  object's. The rules (split_threshold.h, unmodified), the decay, the
//  hysteresis and depth are cachesim's (st_wrap.h, st_range.h); recalc
//  counts requests in scope. on_insert only maps a size to its class.
//

#include "../regionflash_hint.h"
#include "../cachesim/hint/st_wrap.h"

struct rf_hint {
  stw_t w;
  int depth, ssd_only;
  uint32_t kmax, n, ep;
  int64_t taus[KMAX_LIMIT];
};

static const param_spec_t P[] = {
    {"scope", P_ENUM, "all", "all|ssd", "requests observed: all, or the DRAM misses"},
    {"depth", P_UINT, "1", NULL, "recursion depth, up to 2^depth classes (1: split_threshold)"},
    ST_PARAM_SPECS,
    {NULL}};

static int create(rf_hint_t **h, const param_vals_t *v, const hint_env_t *env) {
  rf_hint_t *x = xcalloc(1, sizeof(*x));
  stw_init(&x->w, v);
  x->depth = (int)pv_int(v, "depth");
  x->ssd_only = strcmp(pv_str(v, "scope"), "ssd") == 0;
  x->kmax = env->k_max;
  if (x->depth < 1) die("split_threshold_req: depth must be >= 1");
  *h = x;
  return 0;
}

static void destroy(rf_hint_t *h) { free(h); }

/* a request in scope is one observation; a miss is also cold (no hit, as
 * freq <= 1 at an eviction) */
static void on_get(rf_hint_t *h, const rf_hint_ev_t *e) {
  if (h->ssd_only && e->outcome == HINT_DRAM_HIT) return;
  uint64_t sz = e->size + h->w.add;
  int64_t st[6], nt[KMAX_LIMIT];
  if (e->outcome == HINT_MISS) sst_on_evict(&h->w.s, sz, 0);
  if (!stw_admit(&h->w, sz, st)) return;  // recomputed: the thresholds again
  uint32_t n = (uint32_t)st_split_taus(&h->w.s, h->w.thr, h->depth, (int)h->kmax, nt);
  for (uint32_t i = 0; i < n; i++) nt[i] -= (int64_t)h->w.add;
  if (n != h->n || memcmp(nt, h->taus, n * sizeof(int64_t))) {
    h->ep++;
    h->n = n;
    memcpy(h->taus, nt, n * sizeof(int64_t));
  }
}

static uint32_t on_insert(rf_hint_t *h, const rf_hint_ev_t *e) {
  return class_of_taus(h->taus, h->n, e->size);
}

static uint32_t epoch(const rf_hint_t *h) { return h->ep; }

static uint32_t bounds(const rf_hint_t *h, int64_t *out, uint32_t max) {
  uint32_t n = h->n < max ? h->n : max;
  memcpy(out, h->taus, n * sizeof(int64_t));
  return n;
}

static uint32_t max_classes(const rf_hint_t *h) {
  uint32_t m = h->depth >= 6 ? 64 : 1u << h->depth;
  return m < h->kmax ? m : h->kmax;
}

/* the histograms' sums now (decayed): with recalc beyond the run, count =
 * the requests in scope, bytes = their bytes (+ size_add), cold = missed */
static void report(rf_hint_t *h, FILE *f) {
  unsigned long long c = 0, b = 0, k = 0;
  for (int i = 0; i < SST_NBUCKET; i++) {
    c += h->w.s.count[i];
    b += h->w.s.all_bytes[i];
    k += h->w.s.cold_bytes[i];
  }
  fprintf(f, "{\"obs\": %llu, \"epoch\": %u, \"threshold\": %lld, \"count\": %llu, "
             "\"bytes\": %llu, \"cold_bytes\": %llu}",
          (unsigned long long)h->w.s.n_obs, h->ep, (long long)h->w.thr, c, b, k);
}

const rf_hint_ops_t rf_hint_split_threshold_req_ops = {
    "split_threshold_req", P,      create, destroy, on_get,      NULL,  on_insert,
    NULL,                  epoch,  bounds, NULL,    max_classes, report};
